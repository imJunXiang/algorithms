//
//  UIImage+MDFoundation.m
//  Touramigo
//
//  Created by MisterDeng on 2018/6/13.
//  Copyright © 2018年 touramigo. All rights reserved.
//

#import "UIImage+MDFoundation.h"

@implementation UIImage (MDFoundation)

+ (UIImage *)getCircleImg:(UIImage *)image size:(CGSize)size {
    UIGraphicsBeginImageContext(size);
    UIBezierPath *path =[UIBezierPath bezierPathWithOvalInRect:CGRectMake( 0, 0, size.width, size.height)];
    [path addClip];
    [image drawAtPoint:CGPointZero];
    image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

@end
