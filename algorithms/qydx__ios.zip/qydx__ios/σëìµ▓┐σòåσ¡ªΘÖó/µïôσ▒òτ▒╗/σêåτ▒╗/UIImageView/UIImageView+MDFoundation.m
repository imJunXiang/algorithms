//
//  UIImageView+MDFoundation.m
//  前沿商学院
//
//  Created by 邓壮壮 on 2016/12/1.
//  Copyright © 2016年 edu268. All rights reserved.
//

#import "UIImageView+MDFoundation.h"

@implementation UIImageView (MDFoundation)

#pragma mark 颜色转换为图片

+ (UIImage *)imageWithColor:(UIColor *)color {
    CGRect rect = CGRectMake(0.0f, 0.0f, 1.0f, 1.0f); //宽高 1.0只要有值就够了
    UIGraphicsBeginImageContext(rect.size); //在这个范围内开启一段上下文
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSetFillColorWithColor(context, [color CGColor]);//在这段上下文中获取到颜色UIColor
    CGContextFillRect(context, rect);//用这个颜色填充这个上下文
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();//从这段上下文中获取Image属性,,,结束
    UIGraphicsEndImageContext();
    
    return image;
}


- (void)addCircleView:(UIColor *)color {
    CGRect rect = self.bounds;
    CGFloat cornerRadius = self.width * .5;
    self.layer.masksToBounds = YES;
    self.layer.cornerRadius = cornerRadius;
    
    CGFloat pad = 10.0;
    cornerRadius += pad;
    CALayer *cicleLayer = [[CALayer alloc] init];
    cicleLayer.frame = CGRectMake(rect.origin.x - pad, rect.origin.y - pad, cornerRadius * 2, cornerRadius * 2);
    cicleLayer.backgroundColor = [UIColor blackColor].CGColor;
    cicleLayer.cornerRadius = cornerRadius;
    
    cicleLayer.borderWidth = pad * .5;
    cicleLayer.borderColor = [UIColor blueColor].CGColor;
    
    [self.layer addSublayer:cicleLayer];
}

// 画水印
- (UIImage *) imageWithWaterMask:(UIImage*)mask inRect:(CGRect)rect
{

    UIGraphicsBeginImageContextWithOptions(self.frame.size, NO, 0.0); // 0.0 for scale means "scale for device's main screen".
    
    //原图
    [self.image drawInRect:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
    //水印图
    [mask drawInRect:rect];
    UIImage *newPic = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newPic; 
}

@end
