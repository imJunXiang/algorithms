//
//  CutImageView.h
//  前沿商学院
//
//  Created by 邓壮壮 on 2016/11/30.
//  Copyright © 2016年 edu268. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CutImageView : UIImageView

@end
