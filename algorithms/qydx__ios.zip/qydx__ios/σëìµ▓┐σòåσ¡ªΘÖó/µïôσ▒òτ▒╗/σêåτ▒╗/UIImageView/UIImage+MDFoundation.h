//
//  UIImage+MDFoundation.h
//  Touramigo
//
//  Created by MisterDeng on 2018/6/13.
//  Copyright © 2018年 touramigo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (MDFoundation)
+ (UIImage *)getCircleImg:(UIImage *)image size:(CGSize)size;
@end
