//
//  CutImageView.m
//  前沿商学院
//
//  Created by 邓壮壮 on 2016/11/30.
//  Copyright © 2016年 edu268. All rights reserved.
//

#import "CutImageView.h"

@implementation CutImageView

- (void)awakeFromNib {
    [super awakeFromNib];
    self.contentMode = UIViewContentModeScaleAspectFill;
    self.clipsToBounds = YES;
    [self setContentScaleFactor:[[UIScreen mainScreen] scale]];
}

- (instancetype)initWithImage:(UIImage *)image {
    self = [super initWithImage:image];
    self.contentMode = UIViewContentModeScaleAspectFill;
    self.clipsToBounds = YES;
    [self setContentScaleFactor:[[UIScreen mainScreen] scale]];
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    self.contentMode = UIViewContentModeScaleAspectFill;
    self.clipsToBounds = YES;
    [self setContentScaleFactor:[[UIScreen mainScreen] scale]];
    return self;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        self.contentMode = UIViewContentModeScaleAspectFill;
        self.clipsToBounds = YES;
        [self setContentScaleFactor:[[UIScreen mainScreen] scale]];
    }
    return self;
}

@end
