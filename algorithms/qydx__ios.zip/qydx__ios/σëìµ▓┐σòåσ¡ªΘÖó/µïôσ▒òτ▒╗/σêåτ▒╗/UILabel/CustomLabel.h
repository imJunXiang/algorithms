//
//  CustomLabel.h
//  前沿商学院
//
//  Created by 邓壮壮 on 2017/3/24.
//  Copyright © 2017年 edu268. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomLabel : UILabel
@property (nonatomic, assign) UIEdgeInsets textInsets; // 控制字体与控件边界的间隙
- (CGSize)getSize;
@end
