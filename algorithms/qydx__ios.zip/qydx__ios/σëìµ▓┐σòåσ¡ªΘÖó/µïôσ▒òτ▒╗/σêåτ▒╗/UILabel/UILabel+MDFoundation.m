//
//  UILabel+MDFoundation.m
//  前沿商学院
//
//  Created by 邓壮壮 on 2017/6/14.
//  Copyright © 2017年 edu268. All rights reserved.
//

#import "UILabel+MDFoundation.h"

@implementation UILabel (MDFoundation)
- (CGSize)getSize {
    return [self.text sizeWithAttributes:@{NSFontAttributeName: [UIFont fontWithName:self.font.fontName size:self.font.pointSize]}];
}





@end
