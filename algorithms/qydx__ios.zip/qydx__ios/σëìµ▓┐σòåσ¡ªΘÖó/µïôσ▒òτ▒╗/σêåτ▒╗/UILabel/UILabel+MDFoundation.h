//
//  UILabel+MDFoundation.h
//  前沿商学院
//
//  Created by 邓壮壮 on 2017/6/14.
//  Copyright © 2017年 edu268. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (MDFoundation)
- (CGSize)getSize;

@end
