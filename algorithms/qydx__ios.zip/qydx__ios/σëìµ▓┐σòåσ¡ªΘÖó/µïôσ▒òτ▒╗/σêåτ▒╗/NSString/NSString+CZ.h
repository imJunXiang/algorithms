//
//  NSString+CZ.h
//
//  Created by Vincent_Guo on 14-6-28.
//  Copyright (c) 2014年 vgios. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (CZ)


/**
 *  返回分与秒的字符串 如:01:60
 */
+(NSString *)getMinuteSecondWithSecond:(NSTimeInterval)time;


+ (NSString *)readFromCachesDirectory:(NSString*)filename;
+ (NSString *)deletSpaceInString:(NSString *)text;

/** * 返回用户名 */
+ (NSString *)userNameString;



- (CGSize)sizeWithFont:(UIFont *)font maxW:(CGFloat)maxW;
- (CGSize)sizeWithFont:(UIFont *)font;

#pragma mark - 解析HTML
+ (NSString *)flattenHTML:(NSString *)html trimWhiteSpace:(BOOL)trim;

+ (NSString *)cutOutStringWithPeriod:(NSString *)string;

/**  * 数字格式， 超过1k  进万 */
+ (NSString *)setCount:(int)count title:(NSString *)title;

+ (NSString *)createTime:(NSString *)createTime;


@end
