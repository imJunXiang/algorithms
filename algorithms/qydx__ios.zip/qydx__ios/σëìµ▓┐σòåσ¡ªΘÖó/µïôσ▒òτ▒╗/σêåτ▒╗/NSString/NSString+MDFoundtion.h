//
//  NSString+MDFoundtion.h
//  前沿商学院
//
//  Created by 邓壮壮 on 2016/12/9.
//  Copyright © 2016年 edu268. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (MDFoundtion)
+ ( NSString *)md5String:( NSString *)str;

// 字符串是否空
- (BOOL)isEmptyString;

+ (NSString *)flattenHTML:(NSString *)html;

- (NSURL *)getURL;

//身份证匹配
+ (BOOL)validateIDCardNumber:(NSString *)value;
//数字匹配
+ (BOOL) validateUserAge:(NSString *)str;
//检验邮箱
+ (BOOL) validateUserEmail:(NSString *)str;
//检验手机号
+ (BOOL)checkTelNumber:(NSString*) telNumber;
//验证是否为正数
+ (BOOL) validatePositiveNumber:(NSString *)str;
//
+ (BOOL) validateMoney:(NSString *)str;
//验证护照
+ (BOOL) isValidPassport:(NSString*)value;

// 获取设备信息
// 获取ip
+ (NSString *)getDeviceIPAddresses;

// app版本号
+ (NSString *)getAppVersion;

// 系统版本号
+ (NSString *)getSystemVersion;

// 获取设备型号
+ (NSString *)getDeviceName;

/*获取网络流量信息*/
+ (long long) getInterfaceBytes;

+ (NSString *)stringWithObject:(NSObject *)object;

+ (NSString *)stringNoSpace:(NSString *)str;


#pragma mark - 富文本操作

/**
 *  单纯改变一句话中的某些字的颜色（一种颜色）
 *
 *  @param color    需要改变成的颜色
 *  @param totalStr 总的字符串
 *  @param subArray 需要改变颜色的文字数组(要是有相同的 只取第一个)
 *
 *  @return 生成的富文本
 */
+ (NSMutableAttributedString *)ls_changeCorlorWithColor:(UIColor *)color TotalString:(NSString *)totalStr SubStringArray:(NSArray *)subArray;

/**
 *  单纯改变一句话中的一些字的颜色
 *
 *  @param color    需要改变成的颜色
 *  @param totalStr 总的字符串
 *  @param subArray 需要改变颜色的文字
 *
 *  @return 生成的富文本
 */
+ (NSMutableAttributedString *)ls_changeCorlorWithColor:(UIColor *)color TotalString:(NSString *)totalStr subString:(NSString *)subString;
    
/**
 *  单纯改变句子的字间距（需要 <CoreText/CoreText.h>）
 *
 *  @param totalString 需要更改的字符串
 *  @param space       字间距
 *
 *  @return 生成的富文本
 */
+ (NSMutableAttributedString *)ls_changeSpaceWithTotalString:(NSString *)totalString Space:(CGFloat)space;

/**
 *  单纯改变段落的行间距
 *
 *  @param totalString 需要更改的字符串
 *  @param lineSpace   行间距
 *
 *  @return 生成的富文本
 */
+ (NSMutableAttributedString *)ls_changeLineSpaceWithTotalString:(NSString *)totalString LineSpace:(CGFloat)lineSpace;

/**
 *  同时更改行间距和字间距
 *
 *  @param totalString 需要改变的字符串
 *  @param lineSpace   行间距
 *  @param textSpace   字间距
 *
 *  @return 生成的富文本
 */
+ (NSMutableAttributedString *)ls_changeLineAndTextSpaceWithTotalString:(NSString *)totalString LineSpace:(CGFloat)lineSpace textSpace:(CGFloat)textSpace;
/**
 *  改变某些文字的颜色 并单独设置其字体
 *
 *  @param font        设置的字体
 *  @param color       颜色
 *  @param totalString 总的字符串
 *  @param subArray    想要变色的字符数组
 *
 *  @return 生成的富文本
 */
+ (NSMutableAttributedString *)ls_changeFontAndColor:(UIFont *)font Color:(UIColor *)color TotalString:(NSString *)totalString SubStringArray:(NSArray *)subArray;

/**
 *  为某些文字改为链接形式
 *
 *  @param totalString 总的字符串
 *  @param subArray    需要改变颜色的文字数组(要是有相同的 只取第一个)
 *
 *  @return 生成的富文本
 */
+ (NSMutableAttributedString *)ls_addLinkWithTotalString:(NSString *)totalString SubStringArray:(NSArray *)subArray;

@end
