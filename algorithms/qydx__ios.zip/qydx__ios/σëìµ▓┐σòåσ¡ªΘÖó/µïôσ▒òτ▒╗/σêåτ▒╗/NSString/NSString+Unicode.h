//
//  NSString+Unicode.h
//  前沿商学院
//
//  Created by 邓壮壮 on 2016/11/8.
//  Copyright © 2016年 edu268. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Unicode)
// Unicode转中文
+ (NSString *)replaceUnicodeDic:(NSDictionary *)dic;
// 中文转Unicode
@end
