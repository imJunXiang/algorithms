//
//  NSString+CZ.m
//
//  Created by Vincent_Guo on 14-6-28.
//  Copyright (c) 2014年 vgios. All rights reserved.
//

#import "NSString+CZ.h"
#import "NSDate+Extension.h"
@implementation NSString (CZ)

+(NSString *)getMinuteSecondWithSecond:(NSTimeInterval)time{
    
    int minute = (int)time / 60;
    int second = (int)time % 60;
    
    if (second > 9) { //2:10
        return [NSString stringWithFormat:@"%d:%d",minute,second];
    }
    
    //2:09
    return [NSString stringWithFormat:@"%d:0%d",minute,second];
}


+ (NSString *)readFromCachesDirectory:(NSString*)filename
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    
    NSString *CachesDirectory = [paths objectAtIndex:0];
    
    NSString *path = [CachesDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@",filename]];
    //    NSData *data = [NSData dataWithContentsOfFile:path];
    
    //    NSArray *array = [NSKeyedUnarchiver unarchiveObjectWithData:data];
    
    
    return path;
}


+ (NSString *)deletSpaceInString:(NSString *)text
{
    NSString *content = [text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]; // 去首尾空格
    NSString *replace = [content stringByReplacingOccurrencesOfString:@" " withString:@""];// 去全部空格
    //    NSString *replacePoint = [replace stringByReplacingOccurrencesOfString:@"." withString:@""];// 去全部空格
    
    return replace;
}


+ (NSString *)userNameString
{
    NSString *nameString;
    
    if ([USERID intValue])

    {
        if ([[USER_DEF objectForKey:@"nickname"] length])
        {
            nameString = [USER_DEF objectForKey:@"nickname"];
        }
        
        else if ([[USER_DEF objectForKey:@"mobile"] length])
        {
            nameString = [USER_DEF objectForKey:@"mobile"];
        }
        
        else if ([[USER_DEF objectForKey:@"email"] length])
        {
            nameString = [USER_DEF objectForKey:@"email"];
        }
    }
    
    else
    {
        nameString=[NSString stringWithFormat:@"未登录%@",@""];
    }
    return nameString;
}



+ (NSString *)cutOutStringWithPeriod:(NSString *)string
{
    NSArray *strings = [string componentsSeparatedByCharactersInSet: [NSCharacterSet characterSetWithCharactersInString:@"。."]];

    NSString *periodString = [strings firstObject];

    return periodString;
}

- (CGSize)sizeWithFont:(UIFont *)font maxW:(CGFloat)maxW
{
    NSMutableDictionary *attrs = [NSMutableDictionary dictionary];
    attrs[NSFontAttributeName] = font;
    CGSize maxSize = CGSizeMake(maxW, MAXFLOAT);
    
    // 获得系统版本
    if (iOS7)
    {
        return [self boundingRectWithSize:maxSize options:NSStringDrawingUsesLineFragmentOrigin attributes:attrs context:nil].size;
    }
    else
    {
        return [self boundingRectWithSize:maxSize options:NSStringDrawingUsesLineFragmentOrigin attributes:attrs context:nil].size;
        
        //        return [self sizeWithFont:font constrainedToSize:maxSize];
        
    }
}

- (CGSize)sizeWithFont:(UIFont *)font
{
    return [self sizeWithFont:font maxW:MAXFLOAT];
}

#pragma mark - 解析HTML
+ (NSString *)flattenHTML:(NSString *)html trimWhiteSpace:(BOOL)trim
{
    NSScanner *theScanner = [NSScanner scannerWithString:html];
    NSString *text = nil;
    
    while ([theScanner isAtEnd] == NO)
    {
        // find start of tag
        [theScanner scanUpToString:@"<" intoString:NULL] ;
        // find end of tag
        [theScanner scanUpToString:@">" intoString:&text] ;
        // replace the found tag with a space
        //(you can filter multi-spaces out later if you wish)
        html = [html stringByReplacingOccurrencesOfString:[ NSString stringWithFormat:@"%@>", text] withString:@""];
        
        if ([html containsString:@"&nbsp;"])
        {
            NSString *replace = [html stringByReplacingOccurrencesOfString:@"&nbsp;" withString:@" "];
            html = replace;
        }
        
    }
    return trim ? [html stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] : html;
}



+ (NSString *)setCount:(int)count title:(NSString *)title
{
    // 数字不为0
        if (count < 10000)
        { // 不足10000：直接显示数字，比如786、7986
            title = [title stringByAppendingString:[NSString stringWithFormat:@" %d", count]];
        }
        else
        { // 达到10000：显示xx.x万，不要有.0的情况
            double wan = count / 10000.0;
            title = [title stringByAppendingString:[NSString stringWithFormat:@" %.1f万", wan]];
            // 将字符串里面的.0去掉
            title = [title stringByReplacingOccurrencesOfString:@" .0" withString:@""];
        }
    
    return title;
}


/**
 1.今年
 1> 今天
 * 1分内： 刚刚
 * 1分~59分内：xx分钟前
 * 大于60分钟：xx小时前
 
 2> 昨天
 * 昨天 xx:xx
 
 3> 其他
 * xx-xx xx:xx
 
 2.非今年
 1> xxxx-xx-xx xx:xx
 */

+ (NSString *)createTime:(NSString *)createTime
{
    NSString *returnTime = [NSString stringWithFormat:@"%@", createTime];
    NSDateFormatter *fmt = [[NSDateFormatter alloc] init];
    // 如果是真机调试，转换这种欧美时间，需要设置locale
    fmt.locale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
    
    // 设置日期格式（声明字符串里面每个数字和单词的含义）
    // E:星期几
    // M:月份
    // d:几号(这个月的第几天)
    // H:24小时制的小时
    // m:分钟
    // s:秒
    // y:年
    fmt.dateFormat = @"EEE MMM dd HH:mm:ss Z yyyy";
    //    _created_at = @"Tue Sep 30 17:06:25 +0600 2014";
    
    // 微博的创建日期
    NSDate *createDate = [fmt dateFromString:returnTime];
    // 当前时间
    NSDate *now = [NSDate date];
    
    // 日历对象（方便比较两个日期之间的差距）
    NSCalendar *calendar = [NSCalendar currentCalendar];
    // NSCalendarUnit枚举代表想获得哪些差值
    NSCalendarUnit unit = NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond;
    // 计算两个日期之间的差值
    NSDateComponents *cmps = [calendar components:unit fromDate:createDate toDate:now options:0];
    
    if ([createDate isThisYear])
    { // 今年
        if ([createDate isYesterday])
        { // 昨天
            fmt.dateFormat = @"昨天 HH:mm";
            return [fmt stringFromDate:createDate];
        }
        
        else if ([createDate isToday])
        { // 今天
            if (cmps.hour >= 1)
            {
                return [NSString stringWithFormat:@"%d小时前", (int)cmps.hour];
            }
            
            else if (cmps.minute >= 1)
            {
                return [NSString stringWithFormat:@"%d分钟前", (int)cmps.minute];
            }
            
            else
            {
                return @"刚刚";
            }
        }
        else
        { // 今年的其他日子
            fmt.dateFormat = @"MM-dd HH:mm";
            return [fmt stringFromDate:createDate];
        }
    }
    
    else
    {
        // 非今年
        fmt.dateFormat = @"yyyy-MM-dd HH:mm";
        return [fmt stringFromDate:createDate];
    }
}




@end
