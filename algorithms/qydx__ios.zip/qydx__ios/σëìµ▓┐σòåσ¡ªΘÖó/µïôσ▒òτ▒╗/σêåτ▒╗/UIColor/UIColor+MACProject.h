//
//  UIColor+MACProject.h
//  MACProject
//
//  Created by MacKun on 15/12/14.
//  Copyright © 2015年 MacKun. All rights reserved.
//

#import <UIKit/UIKit.h>
/**
 *  颜色规范
 */
@interface UIColor(MACProject)


/**
 *  蓝色 突出文字 (按钮icon颜色)
 */
+ (UIColor *)appBlueColor;

/**
 *  红色 错误提示
 */
+ (UIColor *)appRedColor;

/**
 *  黑色 重要文字信息、标题
 */
+ (UIColor *)appBlackColor;

/**
 *  灰色 背景色
 */
+ (UIColor *)appBackGroundColor;

/**
 *  灰色 分割线
 */
+ (UIColor *)appLineColor;

/**
 *  黑色 普通正文消息
 */
+ (UIColor *)appTextColor;

/**
 *  灰色 文字消息
 */
+ (UIColor *)appGrayTextColor;

/**
 *  灰色 辅助次要性文字
 */
+ (UIColor *)appLightTextColor;

/**
 *  白色 背景色
 */
+ (UIColor *)appWhiteTextColor;

/**
 *  重要 少数重要标题
 */
+ (UIFont *)appBigFont;

/**
 *  重要 正文
 */
+ (UIFont *)appNormalFont;

/**
 *  重要 辅助文字
 */
+ (UIFont *)appSmallFont;

@end
