//
//  UIColor+MACProject
//  MACProject
//
//  Created by MacKun on 15/12/14.
//  Copyright © 2015年 MacKun. All rights reserved.
//

#import "UIColor+MACProject.h"
#import "UIColor+Mac.h"

@implementation UIColor(MACProject)

/**
 *  蓝色 突出文字 (按钮icon颜色)
 */
+ (UIColor *)appBlueColor {
    return [UIColor colorWithMacHexString:@"#6079ff"];
}

/**
 *  红色 错误提示
 */
+ (UIColor *)appRedColor {
    return [UIColor colorWithMacHexString:@"d90101"];
}

/**
 *  灰色 背景色
 */
+ (UIColor *)appBackGroundColor {
    return [UIColor colorWithMacHexString:@"f7f7f7"];
}

/**
 *  黑色 重要文字信息、标题
 */
+ (UIColor *)appBlackColor {
    return [UIColor colorWithMacHexString:@"333333"];
}

/**
 *  灰色 分割线
 */
+ (UIColor *)appLineColor {
    return [UIColor colorWithMacHexString:@"d2d2d2"];
}

/**
 *  黑色 普通正文消息
 */
+ (UIColor *)appTextColor {
    return [UIColor colorWithMacHexString:@"333333"];
}

/**
 *  灰色 文字消息
 */
+ (UIColor *)appGrayTextColor {
    return [UIColor colorWithMacHexString:@"666666"];
}

/**
 *  灰色 辅助次要性文字
 */
+ (UIColor *)appLightTextColor {
    return [UIColor colorWithMacHexString:@"999999"];
}

/**
 *  白色 背景色
 */
+ (UIColor *)appWhiteTextColor {
    return [UIColor colorWithMacHexString:@"ffffff"];
}

/**
 *  重要 少数重要标题
 */
+ (UIFont *)appBigFont {
    return [UIFont systemFontOfSize:21];
}

/**
 *  重要 正文
 */
+ (UIFont *)appNormalFont {
    return [UIFont systemFontOfSize:14];
}

/**
 *  重要 辅助文字
 */
+ (UIFont *)appSmallFont {
    return [UIFont systemFontOfSize:11];
}

@end
