//
//  NSDate+Extension.h
//  黑马微博2期
//
//  Created by apple on 14-10-18.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (Extension)
/**
 *  判断某个时间是否为今年
 */
- (BOOL)isThisYear;
/**
 *  判断某个时间是否为昨天
 */
- (BOOL)isYesterday;
/**
 *  判断某个时间是否为今天
 */
- (BOOL)isToday;

- (NSString *)weiboDateHandle;

#pragma mark - 返回日期
/**
 *  返回一个只有年月日的时间
 */
- (NSString *)dateWithYMD;
- (NSString *)dateWithYMDHM;
+ (NSString *)dateWithyMd:(NSString *)dateStr;

// 返回2017年8月9日
+ (NSString *)dateWithChineseMdHm:(NSString *)dateStr;

// 返回 MM.dd HH:mm 时间格式
- (NSString *)dateWithMdHm;

+ (NSString *)dateWithMdHm:(NSString *)dateStr;

+ (NSString *)dateTimeDifferenceWithStartTime:(NSString *)startTime endTime:(NSString *)endTime; // 比较时间差

// 判断是否到期
+ (int)compareOneDay:(NSDate *)oneDay withAnotherDay:(NSDate *)anotherDay;
// 根据str得到date
+ (NSDate *)getDateTypeWithStr:(NSString *)dateStr;

+ (NSDate *)getCurrentTime;

+ (NSString *)dateWithOriginal:(NSString *)dateStr format:(NSString *)formatStr;

// 课程date处理
+ (NSString *)dateWithStr:(NSString *)dateStr;

@end
