//
//  UIView+MDFoundation.m
//  JSShopCartModule
//
//  Created by sks on 16/6/29.
//  Copyright © 2016年 乔同新. All rights reserved.
//

#import "UIView+MDFoundation.h"
#import "DHGuidePageHUD.h"

@implementation UIView (MDFoundation)


- (UIView *)addSeparateLine {
    UIView *lineView = [[UIView alloc] init];
    lineView.backgroundColor = [UIColor colorWithMacHexString:@"#e8e8e8"];
    [self addSubview:lineView];
    lineView.sd_layout
    .leftSpaceToView(self, 0)
    .rightSpaceToView(self, 0)
    .bottomSpaceToView(self, 0)
    .heightIs(1);
    return lineView;
}

- (UIView *)addSeparateLineTop {
    UIView *lineView = [[UIView alloc] init];
    lineView.backgroundColor = [UIColor colorWithMacHexString:@"#e8e8e8"];
    [self addSubview:lineView];
    lineView.sd_layout
    .leftSpaceToView(self, 0)
    .rightSpaceToView(self, 0)
    .topSpaceToView(self, 0)
    .heightIs(1);
    return lineView;
}

- (UIView *)addSeparateLineMargin {
    UIView *lineView = [[UIView alloc] init];
    lineView.backgroundColor = [UIColor colorWithMacHexString:@"#e8e8e8"];
    [self addSubview:lineView];
    lineView.sd_layout
    .leftSpaceToView(self, 15)
    .rightSpaceToView(self, 15)
    .bottomSpaceToView(self, 0)
    .heightIs(1);
    return lineView;
}

- (UIView *)addSeparateLineTopView:(UIView *)topView {
    UIView *lineView = [[UIView alloc] init];
    lineView.backgroundColor = [UIColor colorWithMacHexString:@"#e8e8e8"];
    [self addSubview:lineView];
    lineView.sd_layout
    .leftSpaceToView(self, 0)
    .rightSpaceToView(self, 0)
    .topSpaceToView(topView, 0)
    .heightIs(0.5);
    return lineView;
}

+ (UIView *)createSeparateLine {
    UIView *lineView = [[UIView alloc] init];
    lineView.backgroundColor = [UIColor colorWithMacHexString:@"#e8e8e8"];
    return lineView;
}

- (UIView *)addMaskView {
    UIView *maskView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGTH)];
    maskView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.3];
    [self addSubview:maskView];
    return maskView;
}

- (UIImageView *)addArrowImgViewImg:(NSString *)image {
    UIImageView *arrowImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:image]];
    [self addSubview:arrowImageView];
    arrowImageView.sd_layout
    .rightSpaceToView(self, 10)
    .centerYEqualToView(self)
    .widthIs(5)
    .heightIs(10);
    return arrowImageView;
}

- (UIImageView *)addArrowImgView {
    UIImageView *arrowImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"icon_go"]];
    [self addSubview:arrowImageView];
    arrowImageView.sd_layout
    .rightSpaceToView(self, 10)
    .centerYEqualToView(self)
    .widthIs(5)
    .heightIs(10);
    return arrowImageView;
}

- (UIImageView *)addArrowImgView:(CGRect)frame {
    UIImageView *arrowImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"icon_go"]];
    arrowImageView.frame = frame;
    [self addSubview:arrowImageView];
    return arrowImageView;
}

// 动画
+ (void)startAnimation:(UIView *)view offsetY:(CGFloat)offsetY duration:(NSTimeInterval)duration {
    view.transform = CGAffineTransformMakeTranslation(0, offsetY);
    [UIView animateWithDuration:duration animations:^{
        view.transform = CGAffineTransformIdentity;
    }];
}

+ (void)setStaticGuidePage {
    NSArray *imageNameArray = @[@"welcome1",@"welcome2",@"welcome3"];
    DHGuidePageHUD *guidePage = [[DHGuidePageHUD alloc] dh_initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGTH) imageNameArray:imageNameArray buttonIsHidden:YES];
    guidePage.slideInto = YES;
    [[UIApplication sharedApplication].keyWindow addSubview:guidePage];}

// 修复collection分割线
+ (CGFloat)fixCollectionSeparateLine:(CGRect)rect colCount:(CGFloat)colCount space:(CGFloat)space {
    CGFloat totalSpace = (colCount - 1) * space;
    CGFloat itemWidth = (rect.size.width - totalSpace) / colCount;
    CGFloat fixValue = 1 / [UIScreen mainScreen].scale;
    CGFloat realItemWidth = floor(itemWidth) + fixValue;
    if (realItemWidth < itemWidth) {
        realItemWidth += fixValue;
    }
    CGFloat realWidth = colCount * realItemWidth + totalSpace;
    CGFloat pointX = (realWidth - rect.size.width) / 2;
    rect.origin.x = -pointX;
    rect.size.width = realWidth;
    return (rect.size.width - totalSpace) / colCount;
}

- (UILabel *)buildIcon:(NSString *)img label:(NSString *)name {
    UIImageView *iconImg = [[UIImageView alloc] init];
    iconImg.image = [UIImage imageNamed:img];
    [self addSubview:iconImg];
    
    UILabel *nameLB = [[UILabel alloc] init];
    nameLB.textColor = [UIColor colorWithMacHexString:@"#a7a7a7"];
    nameLB.font = [UIFont systemFontOfSize:12];
    nameLB.textAlignment = NSTextAlignmentLeft;
    nameLB.tag = 10086;
    [self addSubview:nameLB];
    nameLB.text = name;
    
    iconImg.sd_layout
    .leftSpaceToView(self, 0)
    .topSpaceToView(self, 0)
    .bottomSpaceToView(self, 0)
    .widthEqualToHeight();
    
    nameLB.sd_layout
    .leftSpaceToView(iconImg, 2)
    .topSpaceToView(self, 0)
    .bottomSpaceToView(self, 0);
    
    [nameLB setSingleLineAutoResizeWithMaxWidth:100];
    [self setupAutoWidthWithRightView:nameLB rightMargin:0];
    
    return nameLB;
}

- (UILabel *)buildSpaceLabel:(CGFloat)space fontSize:(CGFloat)fontSize {
    UILabel *nameLB = [[UILabel alloc] init];
    nameLB.textColor = [UIColor whiteColor];
    nameLB.font = [UIFont systemFontOfSize:fontSize];
    nameLB.textAlignment = NSTextAlignmentCenter;
    [self addSubview:nameLB];
    
    nameLB.sd_layout
    .topSpaceToView(self, 0)
    .leftSpaceToView(self, space)
    .bottomSpaceToView(self, 0);
    [nameLB setSingleLineAutoResizeWithMaxWidth:100];
    
    [self setupAutoWidthWithRightView:nameLB rightMargin:space];
    
    return nameLB;
}

/** 取消searchBar背景色 */
+ (UIImage *)imageWithColor:(UIColor *)color size:(CGSize)size
{
    CGRect rect = CGRectMake(0, 0, size.width, size.height);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return image;
}

+ (CGFloat)getNavBarHeight {
    return 44+[[UIApplication sharedApplication] statusBarFrame].size.height;
}

+ (CGFloat)getStatusBarHeight {
    return [[UIApplication sharedApplication] statusBarFrame].size.height;
}

@end
