//
//  UIView+MDFoundation.h
//  JSShopCartModule
//
//  Created by sks on 16/6/29.
//  Copyright © 2016年 乔同新. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (MDFoundation)

// 分割线
- (UIView *)addSeparateLine;

- (UIView *)addSeparateLineMargin;

- (UIView *)addSeparateLineTop;

+ (UIView *)createSeparateLine;

- (UIView *)addMaskView;

- (UIView *)addSeparateLineTopView:(UIView *)topView;

// 箭头
- (UIImageView *)addArrowImgView;

- (UIImageView *)addArrowImgViewImg:(NSString *)image;

- (UIImageView *)addArrowImgView:(CGRect)frame;

// 动画
+ (void)startAnimation:(UIView *)view offsetY:(CGFloat)offsetY duration:(NSTimeInterval)duration;

+ (void)setStaticGuidePage;

// 修复collection分割线
+ (CGFloat)fixCollectionSeparateLine:(CGRect)rect colCount:(CGFloat)colCount space:(CGFloat)space;

// 小图标和问题
- (UILabel *)buildIcon:(NSString *)img label:(NSString *)name;

- (UILabel *)buildSpaceLabel:(CGFloat)space fontSize:(CGFloat)fontSize;

/** 取消searchBar背景色 */
+ (UIImage *)imageWithColor:(UIColor *)color size:(CGSize)size;

// 得到导航栏高度
+ (CGFloat)getNavBarHeight;

// 得到状态栏高度
+ (CGFloat)getStatusBarHeight;

@end
