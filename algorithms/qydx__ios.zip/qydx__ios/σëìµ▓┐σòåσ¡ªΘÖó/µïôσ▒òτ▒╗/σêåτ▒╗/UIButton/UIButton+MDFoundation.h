//
//  UIButton+MDFoundation.h
//  前沿商学院
//
//  Created by 邓壮壮 on 2016/12/1.
//  Copyright © 2016年 edu268. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (MDFoundation)
- (void)setEnlargeEdgeWithTop:(CGFloat) top right:(CGFloat) right bottom:(CGFloat) bottom left:(CGFloat) left;

- (CGSize)getSize:(NSString *)str;
@end
