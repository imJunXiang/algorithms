//
//  NSArray+Log.m
//  前沿商学院
//
//  Created by 邓壮壮 on 2016/11/8.
//  Copyright © 2016年 edu268. All rights reserved.
//

#import "NSArray+Log.h"

@implementation NSArray (Log)
- (NSString *)descriptionWithLocale:(id)locale
{
    NSMutableString *strM = [NSMutableString stringWithString:@"(\n"];
    
    [self enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        
        [strM appendFormat:@"\t%@,\n", obj];
        
    }];
    
    [strM appendString:@")"];
    
    return strM;
    
}
@end
