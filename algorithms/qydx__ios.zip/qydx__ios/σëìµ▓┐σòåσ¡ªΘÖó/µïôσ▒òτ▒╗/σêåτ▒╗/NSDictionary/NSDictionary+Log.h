//
//  NSDictionary+Log.h
//  前沿商学院
//
//  Created by 邓壮壮 on 2016/11/8.
//  Copyright © 2016年 edu268. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (Log)
- (NSString*)my_description;
@end
