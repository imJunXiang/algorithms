//
//  NSDictionary+kPoint.h
//  268EDU_Demo
//
//  Created by yzla50010 on 16/5/23.
//  Copyright © 2016年 edu268. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (kPoint)

#pragma mark --- 验证播放节点 YES 可以直接播放 ---
+ (NSDictionary *)loadCheckKpointIsAbleToPlay:(NSString *)kPointId;

@end
