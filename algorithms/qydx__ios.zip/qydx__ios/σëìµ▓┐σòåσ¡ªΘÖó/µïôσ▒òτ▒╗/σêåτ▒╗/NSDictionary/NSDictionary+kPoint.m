//
//  NSDictionary+kPoint.m
//  268EDU_Demo
//
//  Created by yzla50010 on 16/5/23.
//  Copyright © 2016年 edu268. All rights reserved.
//

#import "NSDictionary+kPoint.h"

@implementation NSDictionary (kPoint)

+ (NSDictionary *)loadCheckKpointIsAbleToPlay:(NSString *)kPointId
{
    NSString *StringUrl = [NSString stringWithFormat:@"%@?kpointId=%@&userId=%@", [HTTPInterface checkKpoint], kPointId, USERID];
    
    NSURL *urlString = [NSURL URLWithString:StringUrl];
    //    /** 发送请求 */
    NSURLRequest *request = [NSURLRequest requestWithURL:urlString];
    NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    NSDictionary *dict = nil;
    if (responseData == nil)
    {
        NSString *message = @"网络异常，请检查网络！";
        
        [MBProgressHUD showMBPAlertView:message withSecond:2.0];
    }
    
    else
    {
        dict = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableLeaves error:nil];
    }
    
    return dict;
}
@end
