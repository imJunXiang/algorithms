//
//  NSDictionary+Log.m
//  前沿商学院
//
//  Created by 邓壮壮 on 2016/11/8.
//  Copyright © 2016年 edu268. All rights reserved.
//

#import "NSDictionary+Log.h"

@implementation NSDictionary (Log)
- (NSString*)my_description {
    
    NSString *desc = [self my_description];
    
    desc = [NSString stringWithCString:[desc cStringUsingEncoding:NSUTF8StringEncoding] encoding:NSNonLossyASCIIStringEncoding];
    
    return desc;
    
}

@end
