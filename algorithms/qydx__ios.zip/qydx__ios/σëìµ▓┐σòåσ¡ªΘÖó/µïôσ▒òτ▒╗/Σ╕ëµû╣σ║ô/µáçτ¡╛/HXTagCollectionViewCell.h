//
//  HXTagCollectionViewCell.h
//  黄轩 https://github.com/huangxuan518
//
//  Created by 黄轩 on 16/1/13.
//  Copyright © 2015年 IT小子. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HXTagCollectionViewCell : UICollectionViewCell

@property (nonatomic,strong) UILabel *titleLabel;

@end
