//
//  代码地址: https://github.com/iphone5solo/PYSearch
//  代码地址: http://www.code4app.com/thread-11175-1-1.html
//  Created by CoderKo1o.
//  Copyright © 2016年 iphone5solo. All rights reserved.
//

#import "PYSearchSuggestionViewController.h"
#import "PYSearchConst.h"
#import "CourseIndexCell.h"
#import "CourseDetailViewController.h"
#import "TrainIndexCell.h"

@interface PYSearchSuggestionViewController ()<UITableViewDelegate, UITableViewDataSource>
@property (nonatomic, strong) NSMutableArray *modelArr;
@property (nonatomic, assign) NSInteger page;

@end

@implementation PYSearchSuggestionViewController

+ (instancetype)searchSuggestionViewControllerWithDidSelectCellBlock:(PYSearchSuggestionDidSelectCellBlock)didSelectCellBlock
{
    PYSearchSuggestionViewController *searchSuggestionVC = [[PYSearchSuggestionViewController alloc] init];
    searchSuggestionVC.didSelectCellBlock = didSelectCellBlock;
    return searchSuggestionVC;
}

- (void)loadMyCourseData {
    NSDictionary *params = @{@"page": @(self.page),@"pageSize":PAGE_COUNT, @"title": self.searchText};
    [HWHttpTool getWeb:[ApiConst courseSearch] params:params success:^(id json) {
        NSDictionary *data = json[@"result"];
        if ([data[@"pages"] integerValue]<=self.page) {
            [self.tableView.mj_footer endRefreshingWithNoMoreData];
        }
        
        [self.modelArr addObjectsFromArray:data[@"records"]];
        [self.tableView reloadData];
    }];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.page = 2;
    self.modelArr = [NSMutableArray array];
    Weak(self);
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        wArg.page++;
        [wArg loadMyCourseData];
        [wArg.tableView.mj_footer endRefreshing];
    }];
}

- (void)setSearchSuggestions:(NSArray<NSString *> *)searchSuggestions
{
    [self.modelArr removeAllObjects];
    _searchSuggestions = [searchSuggestions copy];
    [self.modelArr addObjectsFromArray:_searchSuggestions];
    // 刷新数据
    [self.tableView reloadData];
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.modelArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *model = self.modelArr[indexPath.row];
    TrainIndexCell *cell = [TrainIndexCell cellWithTableView:tableView];
    [cell.iconImgV sd_setImageWithURL:[model[@"cover_image_url"] getURL]];
    cell.nameLb.text = model[@"title"];
    cell.desLb.text = model[@"simple_description"];
    cell.countLb.text = [NSString stringWithFormat:@"%ld人", [model[@"add_view_count"] integerValue]+[model[@"page_view_count"] integerValue]];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 116;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *model = self.modelArr[indexPath.row];
    CourseDetailViewController *vc = [[CourseDetailViewController alloc] init];
    vc.courseId = model[@"id"];
    [self.navigationController pushViewController:vc animated:YES];
}

@end
