
#import "PYSearchConst.h"

NSString *const PYSearchPlaceholderText = @"搜索内容";      // 搜索框的占位符 默认为 @"搜索内容"
NSString *const PYHotSearchText = @"热门搜索";              // 热门搜索文本 默认为 @"热门搜索"
NSString *const PYSearchHistoryText = @"搜索历史";          // 搜索历史文本 默认为 @"搜索历史"
NSString *const PYEmptySearchHistoryText = @"清空搜索历史";  // 清空搜索历史文本 默认为 @"清空搜索历史"
