//
//  NetReachability.h
//  EDU268
//
//  Created by mac on 14/12/6.
//  Copyright (c) 2014年 北京易知路科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NetReachability : NSObject
+ (BOOL) isEnableWIFI;
@end
