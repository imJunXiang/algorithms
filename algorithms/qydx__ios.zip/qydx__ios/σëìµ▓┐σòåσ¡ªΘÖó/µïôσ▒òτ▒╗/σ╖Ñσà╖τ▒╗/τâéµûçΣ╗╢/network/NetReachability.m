//
//  NetReachability.m
//  EDU268
//
//  Created by mac on 14/12/6.
//  Copyright (c) 2014年 北京易知路科技有限公司. All rights reserved.
//

#import "NetReachability.h"
#import <ifaddrs.h>
#import <net/if.h>
#import <SystemConfiguration/CaptiveNetwork.h>

@implementation NetReachability
// 是否wifi
+ (BOOL)isEnableWIFI {
    NSCountedSet *cset = [NSCountedSet new];
    struct ifaddrs *interfaces;
    
    if( ! getifaddrs(&interfaces) ) {
        for( struct ifaddrs *interface = interfaces; interface; interface = interface->ifa_next) {
            if ( (interface->ifa_flags & IFF_UP) == IFF_UP ) {
                [cset addObject:[NSString stringWithUTF8String:interface->ifa_name]];
            }
        }
    }
    
    return [cset countForObject:@"awdl0"] > 1 ? YES : NO;
}
@end
