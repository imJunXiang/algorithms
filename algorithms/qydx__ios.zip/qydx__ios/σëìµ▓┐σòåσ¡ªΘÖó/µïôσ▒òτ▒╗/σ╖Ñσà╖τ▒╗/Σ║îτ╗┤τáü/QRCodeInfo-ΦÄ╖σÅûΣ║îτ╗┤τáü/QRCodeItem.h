//
//  QRCodeItem.h
//  QRCodeDemo
//
//  Created by rkxt_ios on 15/12/23.
//  Copyright © 2015年 ST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QRCodeItem : UIButton
- (instancetype)initWithFrame:(CGRect)frame
                        title:(NSString *)title;
@end
