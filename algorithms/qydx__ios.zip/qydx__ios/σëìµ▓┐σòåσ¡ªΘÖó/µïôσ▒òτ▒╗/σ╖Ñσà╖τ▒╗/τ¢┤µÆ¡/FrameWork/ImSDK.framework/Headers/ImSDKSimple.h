//
//  ImSDKSimple.h
//  ImSDK
//
//  Created by bodeng on 30/12/15.
//  Copyright © 2015 tencent. All rights reserved.
//

#ifndef ImSDKSimple_h
#define ImSDKSimple_h

#import "TIMManager.h"
#import "TIMRelay.h"

#import "IMSdkInt.h"

#endif /* ImSDKSimple_h */
