//
//  SoundPlayView.m
//  前沿商学院
//
//  Created by 邓壮壮 on 2017/8/7.
//  Copyright © 2017年 edu268. All rights reserved.
//

#import "SoundPlayView.h"
#import "UIImage+GIF.h"
#import <MediaPlayer/MPNowPlayingInfoCenter.h>
#import <MediaPlayer/MPMediaItem.h>

static NSMutableDictionary *info=nil;

@interface SoundPlayView()<STKAudioPlayerDelegate>
@property (nonatomic, strong) UILabel *timeLB;
@property (nonatomic, strong) UISlider *sliderView;
@property (nonatomic,strong) NSTimer *timer;
@property (nonatomic, assign) double time;
@property (nonatomic, assign) BOOL isWaiting;
@property (nonatomic, strong) UIButton *playBtn;
@property (nonatomic, strong) UIView *toolView;
@property (nonatomic, strong) UIActivityIndicatorView *indicatorView;
@property (nonatomic, assign) BOOL isPlay;
@end

@implementation SoundPlayView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    
    [self buildView];
    return self;
}

- (void)playWithInfo:(NSDictionary *)info time:(double)time {
    self.hidden = NO;
    self.isWaiting = YES;
    self.isPlay = YES;
    self.playBtn.selected = YES;
    self.time = time;
    [self.player play:info[@"url"]];
    [self start];
    [self.indicatorView startAnimating];
    
    [self toolViewShow];
    

    MPMediaItemArtwork *albumArt = [[MPMediaItemArtwork alloc] initWithImage:info[@"image"]];
    [[SoundPlayView shareInfo] setObject:info[@"title"] forKey:MPMediaItemPropertyTitle];
//    [[SoundPlayView shareInfo] setObject:info[@"subtitle"] forKey:MPMediaItemPropertyAlbumTitle];
//    [[SoundPlayView shareInfo] setObject:info[@"subtitle"] forKey:MPMediaItemPropertyArtist];
    [[SoundPlayView shareInfo] setObject:albumArt forKey:MPMediaItemPropertyArtwork];
}

- (NSString *)setCurrentTime:(NSTimeInterval)currentTime {
    int minute = currentTime / 60;
    int second = (int)currentTime % 60;
    NSString *currentTimeStr = [NSString stringWithFormat:@"%02d:%02d", minute,second];
    return currentTimeStr;
}

- (void)updateProgress:(NSTimer *)updatedTimer {
    double progress = self.player.progress;
    double duration = self.player.duration;
    if (!isnan(progress) && !isnan(duration)) {
        self.timeLB.text = [NSString stringWithFormat:@"%@/%@", [self setCurrentTime:progress], [self setCurrentTime:duration]];
    }
    self.sliderView.value = progress/duration;
    
    if (self.player.duration!=0 && self.isWaiting) {
        if (self.time!=0) [self.player seekToTime:self.time];
        self.isWaiting = NO;
        [self.indicatorView stopAnimating];
    }
    
    
    // 更新封面
    [[SoundPlayView shareInfo] setObject:[NSNumber numberWithDouble:progress] forKey:MPNowPlayingInfoPropertyElapsedPlaybackTime]; //音乐当前已经播放时间
    [[SoundPlayView shareInfo] setObject:[NSNumber numberWithDouble:duration] forKey:MPMediaItemPropertyPlaybackDuration];//歌曲剩余时间设置
    
    [[MPNowPlayingInfoCenter defaultCenter] setNowPlayingInfo:[SoundPlayView shareInfo]];
}

- (void)dismiss {
    [self.player stop];
    self.player = nil;
    [self setTimerValid];
}

- (void)setSubTitle:(NSString *)subTitle {
    _subTitle = subTitle;
    [[SoundPlayView shareInfo] setObject:subTitle forKey:MPMediaItemPropertyAlbumTitle];
}

- (void)resume {
    [self.player resume];
    self.playBtn.selected = YES;
}

- (void)pause {
    [self.player pause];
    self.playBtn.selected = NO;
}

/**
 *  开始计时器
 */
- (void)start {
    if (!_timer) {
        _timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(updateProgress:) userInfo:nil repeats:YES];
    }
}

/**
 *  结束计时器
 */
- (void)setTimerValid {
    if ([_timer isValid]) {
        [_timer invalidate];
        _timer = nil;
    }
}

+ (NSMutableDictionary *)shareInfo {
    if (!info) {
        info = [NSMutableDictionary dictionary];
    }
    return info;
}

- (void)buildView {
    UITapGestureRecognizer *tapGes = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(viewTapGesAction)];
    [self addGestureRecognizer:tapGes];
    
    // 播放器
    self.backgroundColor = [UIColor blackColor];
    self.player = [[STKAudioPlayer alloc] initWithOptions:(STKAudioPlayerOptions){ .flushQueueOnSeek = YES, .enableVolumeMixer = NO, .equalizerBandFrequencies = {50, 100, 200, 400, 800, 1600, 2600, 16000} }];
    self.player.meteringEnabled = YES;
    self.player.delegate = self;
    self.player.volume = 1;
    
    UIImageView *gifView = [[UIImageView alloc] init];
    gifView.image = [UIImage sd_animatedGIFNamed:@"sound"];
    [self addSubview:gifView];
    
    UIActivityIndicatorView *indicatorView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
    [gifView addSubview:indicatorView];
    self.indicatorView = indicatorView;
    [indicatorView startAnimating];
    
    UIButton *backBtn = [[UIButton alloc] init];
    [backBtn setImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(backClickAction) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:backBtn];
    
    UILabel *titleLB = [[UILabel alloc] init];
    titleLB.text = @"音频播放中";
    titleLB.font = [UIFont systemFontOfSize:14];
    titleLB.textColor = [UIColor whiteColor];
    titleLB.textAlignment = NSTextAlignmentRight;
    [self addSubview:titleLB];
    
    UIButton *videoBtn = [[UIButton alloc] init];
    videoBtn.titleLabel.font = [UIFont systemFontOfSize:14];
    [videoBtn setTitleColor:[UIColor yellowColor] forState:UIControlStateNormal];
    [videoBtn setTitle:@"返回视频" forState:UIControlStateNormal];
    [videoBtn addTarget:self action:@selector(videoClickAction) forControlEvents:UIControlEventTouchUpInside];
    videoBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [self addSubview:videoBtn];
    
    UIView *toolView = [[UIView alloc] init];
    [self addSubview:toolView];
    self.toolView = toolView;
    
    UIButton *playBtn = [[UIButton alloc] init];
    [playBtn setBackgroundImage:[UIImage imageNamed:@"pl-video-player-play"] forState:UIControlStateNormal];
    [playBtn setBackgroundImage:[UIImage imageNamed:@"pl-video-player-pause"] forState:UIControlStateSelected];
    playBtn.selected = YES;
    [playBtn addTarget:self action:@selector(playClickAction:) forControlEvents:UIControlEventTouchUpInside];
    [toolView addSubview:playBtn];
    self.playBtn = playBtn;
    
    UISlider *sliderView = [[UISlider alloc] init];
    [sliderView setTintColor:[UIColor appBlueColor]];
    sliderView.thumbTintColor = [UIColor colorWithMacHexString:@"#d9dcff"];
    [sliderView setThumbImage:[UIImage imageNamed:@"course_3"] forState:UIControlStateNormal];
    [sliderView setThumbImage:[UIImage imageNamed:@"course_3"] forState:UIControlStateSelected];
    [sliderView addTarget:self action:@selector(sliderMoveAction:) forControlEvents:UIControlEventValueChanged];
    [toolView addSubview:sliderView];
    self.sliderView = sliderView;
    
    UILabel *timeLB = [[UILabel alloc] init];
    timeLB.textColor = [UIColor whiteColor];
    timeLB.font = [UIFont systemFontOfSize:12];
    timeLB.textAlignment = NSTextAlignmentRight;
    [toolView addSubview:timeLB];
    self.timeLB = timeLB;
    
    gifView.sd_layout
    .bottomSpaceToView(self, 0)
    .topSpaceToView(self, 0)
    .leftSpaceToView(self, 0)
    .rightSpaceToView(self, 0);
    
    indicatorView.sd_layout
    .centerXEqualToView(gifView)
    .centerYEqualToView(gifView)
    .widthIs(20)
    .heightIs(20);
    
    toolView.sd_layout
    .bottomSpaceToView(self, 0)
    .leftSpaceToView(self, 0)
    .rightSpaceToView(self, 0)
    .heightIs(30);
    
    videoBtn.sd_layout
    .bottomSpaceToView(toolView, 0)
    .leftSpaceToView(self, SCREEN_WIDTH/2+25)
    .widthIs(60)
    .heightIs(20);
    
    titleLB.sd_layout
    .bottomSpaceToView(toolView, 0)
    .rightSpaceToView(self, SCREEN_WIDTH/2+25)
    .widthIs(100)
    .heightIs(20);
    
    backBtn.sd_layout
    .leftSpaceToView(self, 10)
    .topSpaceToView(self, [UIView getStatusBarHeight]+5)
    .widthIs(25)
    .heightIs(25);
    
    playBtn.sd_layout
    .centerYEqualToView(toolView)
    .leftSpaceToView(toolView, 15)
    .widthIs(18)
    .heightIs(18);
    
    timeLB.sd_layout
    .centerYEqualToView(toolView)
    .rightSpaceToView(toolView, 10)
    .heightIs(15);
    [timeLB setSingleLineAutoResizeWithMaxWidth:150];
    
    sliderView.sd_layout
    .centerYEqualToView(toolView)
    .leftSpaceToView(playBtn, 15)
    .rightSpaceToView(timeLB, 5)
    .heightIs(20);
    
}

- (void)viewTapGesAction {
    if (self.toolView.alpha<1) {
        [self toolViewShow];
    } else {
        [self toolViewHide];
    }
}

- (void)toolViewShow {
    [UIView animateWithDuration:0.5 animations:^{
        self.toolView.alpha = 1;
        [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(toolViewHide) object:nil];
        [self performSelector:@selector(toolViewHide) withObject:nil afterDelay:5];
    }];
}

- (void)toolViewHide {
    [UIView animateWithDuration:0.5 animations:^{
        self.toolView.alpha = 0;
    } completion:nil];
}


- (void)playClickAction:(UIButton *)btn {
    btn.selected = !btn.selected;
    if (btn.selected) { // 播放
        [self.player resume];
    } else {
        [self.player pause];
    }
    [self toolViewShow];
    if (self.playClickBlock!=nil) {
        self.playClickBlock(btn);
    }
}

- (void)backClickAction {
    [self dismiss];
    if (self.backClickBlock != nil) {
        self.backClickBlock();
    }
}

- (void)sliderMoveAction:(UISlider *)slider {
    double newSeekTime = slider.value * self.player.duration;
    [self.player seekToTime:newSeekTime];
    [self toolViewShow];
}

- (void)videoClickAction {
    self.hidden = YES;
    [self setTimerValid];
    [self.player stop];
    if (self.videoClickBlock != nil) {
        self.videoClickBlock(self.player.progress);
    }
}

-(void) audioPlayer:(STKAudioPlayer*)audioPlayer didFinishPlayingQueueItemId:(NSObject*)queueItemId withReason:(STKAudioPlayerStopReason)stopReason andProgress:(double)progress andDuration:(double)duration
{
    
}

#pragma mark - Delegate
-(void) audioPlayer:(STKAudioPlayer*)audioPlayer unexpectedError:(STKAudioPlayerErrorCode)errorCode
{
    
}

-(void) audioPlayer:(STKAudioPlayer*)audioPlayer didStartPlayingQueueItemId:(NSObject*)queueItemId
{

}

-(void) audioPlayer:(STKAudioPlayer*)audioPlayer didFinishBufferingSourceWithQueueItemId:(NSObject*)queueItemId
{
    if (self.playOverBlock!=nil) {
        self.playOverBlock();
    }
}

-(void) audioPlayer:(STKAudioPlayer *)audioPlayer logInfo:(NSString *)line
{
    NSLog(@"%@", line);
}

- (void)audioPlayer:(STKAudioPlayer *)audioPlayer didReadStreamMetadata:(NSDictionary *)dictionary
{
    
}

-(void) audioPlayer:(STKAudioPlayer*)audioPlayer stateChanged:(STKAudioPlayerState)state previousState:(STKAudioPlayerState)previousState
{
    //    STKAudioPlayerStateReady,
    //    STKAudioPlayerStateRunning = 1,
    //    STKAudioPlayerStatePlaying = (1 << 1) | STKAudioPlayerStateRunning,
    //    STKAudioPlayerStateBuffering = (1 << 2) | STKAudioPlayerStateRunning,
    //    STKAudioPlayerStatePaused = (1 << 3) | STKAudioPlayerStateRunning,
    //    STKAudioPlayerStateStopped = (1 << 4),
    //    STKAudioPlayerStateError = (1 << 5),
    //    STKAudioPlayerStateDisposed = (1 << 6)
    NSString *stateName;
    switch (previousState) {
        case STKAudioPlayerStateReady:
            stateName = @"STKAudioPlayerStateReady";
            break;
        case STKAudioPlayerStateRunning:
            stateName = @"STKAudioPlayerStateRunning";
            break;
        case STKAudioPlayerStatePlaying:
            stateName = @"STKAudioPlayerStatePlaying";
            break;
        case STKAudioPlayerStateBuffering:
            stateName = @"STKAudioPlayerStateBuffering";
            break;
        case STKAudioPlayerStatePaused:
            stateName = @"STKAudioPlayerStatePaused";
            break;
        case STKAudioPlayerStateStopped:
            stateName = @"STKAudioPlayerStateStopped";
            break;
        case STKAudioPlayerStateError:
            stateName = @"STKAudioPlayerStateError";
            break;
        case STKAudioPlayerStateDisposed:
            stateName = @"STKAudioPlayerStateDisposed";
            break;
        default:
            stateName = @"i do not konw";
            break;
    }
    NSLog(@"播放器状态%@", stateName);
}

@end
