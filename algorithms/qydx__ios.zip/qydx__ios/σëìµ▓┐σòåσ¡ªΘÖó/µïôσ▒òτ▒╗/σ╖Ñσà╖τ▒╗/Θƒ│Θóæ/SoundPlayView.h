//
//  SoundPlayView.h
//  前沿商学院
//
//  Created by 邓壮壮 on 2017/8/7.
//  Copyright © 2017年 edu268. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "STKAudioPlayer.h"

@interface SoundPlayView : UIView
@property (nonatomic, strong) NSURL *soundUrl;
@property (nonatomic, strong) STKAudioPlayer *player;
@property (nonatomic, copy) NSString *subTitle;

- (void)playWithInfo:(NSDictionary *)info time:(double)time;

@property (nonatomic, copy) void (^backClickBlock) ();
@property (nonatomic, copy) void (^playOverBlock) ();
@property (nonatomic, copy) void (^videoClickBlock) (double time);
@property (nonatomic, copy) void (^playClickBlock) (UIButton *playBtn);

- (void)dismiss;

- (void)resume;

- (void)pause;

+ (NSMutableDictionary *)shareInfo;
@end
