//
//  HWHttpAnimation.m
//  前沿商学院
//
//  Created by 邓壮壮 on 2017/7/27.
//  Copyright © 2017年 edu268. All rights reserved.
//

#import "HWHttpAnimation.h"
#import "UIImage+GIF.h"

static MBProgressHUD *HUD=nil;

@implementation HWHttpAnimation

+ (MBProgressHUD *)shareTool {
    if (!HUD) {
        HUD = [MBProgressHUD showHUDAddedTo:[UIApplication sharedApplication].keyWindow animated:YES];
        
        UIImage  *image=[UIImage sd_animatedGIFNamed:@"loading"];
        UIImageView  *gifview=[[UIImageView alloc]initWithFrame:CGRectMake(0,0,200, 200)];
        gifview.image=image;
        HUD.customView=gifview;
        // 再设置模式
        HUD.mode = MBProgressHUDModeCustomView;
        HUD.bezelView.style = MBProgressHUDBackgroundStyleSolidColor;
        HUD.bezelView.backgroundColor = [UIColor clearColor];
        // Change the background view style and color.
        HUD.backgroundView.style = MBProgressHUDBackgroundStyleSolidColor;
        HUD.backgroundView.color = [UIColor colorWithWhite:0.f alpha:0.1f];
    }
    return HUD;
}

@end
