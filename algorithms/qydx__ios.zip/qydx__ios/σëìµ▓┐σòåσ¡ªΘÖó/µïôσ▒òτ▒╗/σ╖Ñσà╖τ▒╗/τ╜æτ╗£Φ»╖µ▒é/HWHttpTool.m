//
//  HWHttpTool.m
//  黑马微博2期
//
//  Created by apple on 14-10-25.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import "HWHttpTool.h"
#import "AFNetworking.h"
#import "Reachability.h"
#import "AFNetworking.h"
#import "UIImage+GIF.h"
#import "LoginIndexViewController.h"

static NSString * const errorMsg = @"当前网络不稳定，请稍后重试";

@implementation HWHttpTool

+ (void)get:(NSString *)url params:(NSDictionary *)params success:(void (^)(id json))success failure:(void (^)(NSError *error))failure
{
    // 1.创建请求管理者
    AFHTTPSessionManager *mgr = [AFHTTPSessionManager manager];
    
    // 设置接收返回数据格式
    mgr.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/html", @"text/plain", @"text/json", nil];
    [mgr.requestSerializer setValue:@"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36" forHTTPHeaderField:@"User-Agent"];
    [mgr.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"content-type"];
    [mgr.requestSerializer setValue:@"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8" forHTTPHeaderField:@"Accept"];
    
    [mgr GET:url parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if (success) {
            NSLog(@"请求地址%@---正确结果%@",url, responseObject);
            success(responseObject);
        }
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        if (failure) {
            [MBProgressHUD showError:errorMsg];
            NSLog(@"请求地址%@---错误原因%@",url, error);
            failure(error);
        }
    }];
}


+ (void)post:(NSString *)url params:(NSDictionary *)params success:(void (^)(id json))success failure:(void (^)(NSError *error))failure
{
    [self post:url params:params animation:YES success:success failure:failure];
}

+ (void)post:(NSString *)url params:(NSDictionary *)params animation:(BOOL)animation success:(void (^)(id json))success failure:(void (^)(NSError *error))failure
{
    if ([HWHttpTool isExistenceNetwork]) { // You Wang
        // 1.创建请求管理者
        AFHTTPSessionManager *mgr = [AFHTTPSessionManager manager];
        
        // Https证书
        // 2.设置证书模式
//        [self httpsCerConfig:mgr];
        
        
        mgr.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/html", @"text/plain", @"text/json", nil];
        mgr.requestSerializer.timeoutInterval = 8.f;
        // 添加版本参数
        NSMutableDictionary *mutableParams = [NSMutableDictionary dictionaryWithDictionary:params];
        
        __block MBProgressHUD *HUD;
        if (animation) { // 如果需要动画
            HUD = [MBProgressHUD showHUDAddedTo:[UIApplication sharedApplication].keyWindow animated:YES];
            
            UIImage  *image=[UIImage sd_animatedGIFNamed:@"loading"];
            UIImageView  *gifview=[[UIImageView alloc]initWithFrame:CGRectMake(0,0,200, 200)];
            gifview.image=image;
            HUD.customView=gifview;
            // 再设置模式
            HUD.mode = MBProgressHUDModeCustomView;
            HUD.bezelView.style = MBProgressHUDBackgroundStyleSolidColor;
            HUD.bezelView.backgroundColor = [UIColor clearColor];
            // Change the background view style and color.
            HUD.backgroundView.style = MBProgressHUDBackgroundStyleSolidColor;
            HUD.backgroundView.color = [UIColor colorWithWhite:0.f alpha:0.1f];
            [HUD showAnimated:YES];
        }
        
        NSArray *sortedArray = [mutableParams.allKeys sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2){
            
            return [obj1 compare:obj2 options:NSNumericSearch];
            
        }];
        // 参数排序
        NSString *paramsSort = [NSString string];
        int i = 0;
        for (NSString *key in sortedArray) {
            if (i == 0) {
                paramsSort = [paramsSort stringByAppendingFormat:@"%@=%@", key, mutableParams[key]];
            } else {
                paramsSort = [paramsSort stringByAppendingFormat:@"&%@=%@", key, mutableParams[key]];
            }
            i++;
        }
        if (sortedArray.count==0) {
            paramsSort = [paramsSort stringByAppendingString:@"key=QianYan"];
        } else {
            paramsSort = [paramsSort stringByAppendingString:@"&key=QianYan"];
        }
        
        // 大写
        NSString *paramsU = [paramsSort uppercaseString];
        // MD5
        NSString *paramsMD5 = [NSString md5String:paramsU];
        
        mutableParams[@"sign"] = paramsMD5;
        mutableParams[@"version"] = APP_VERSION;
        
        url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        // 2.发送请求
        
        [mgr POST:url parameters:mutableParams progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            [HUD hideAnimated:YES];
            if (success) {
                NSLog(@"请求地址%@---正确结果%@",url, responseObject);
                success(responseObject);
            }
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            [HUD hideAnimated:YES];
            if (failure) {
                [MBProgressHUD showError:errorMsg];
                NSLog(@"请求地址%@---错误原因%@",url, error);
                failure(error);
            }
        }];
        
    } else {
        [MBProgressHUD hideHUD];
        [self showNoNetworkAlert];
    }
}

+ (void)postWebNoAnimation:(NSString *)url params:(NSDictionary *)params success:(void (^)(id json))success failure:(void (^)(NSError *error))failure {
    [self postWeb:url params:params animation:NO success:success failure:failure];
}

+ (void)postWeb:(NSString *)url params:(NSDictionary *)params success:(void (^)(id json))success {
    [self postWeb:url params:params animation:YES success:success failure:nil];
}

+ (void)getWeb:(NSString *)url params:(NSDictionary *)params success:(void (^)(id json))success {
    [self getWeb:url params:params animation:YES success:success failure:nil];
}

+ (void)postWeb:(NSString *)url params:(NSDictionary *)params success:(void (^)(id json))success failure:(void (^)(NSError *error))failure {
    [self postWeb:url params:params animation:YES success:success failure:failure];
}

+ (void)postWeb:(NSString *)url params:(NSDictionary *)params animation:(BOOL)animation success:(void (^)(id json))success failure:(void (^)(NSError *error))failure
{
    
    if ([HWHttpTool isExistenceNetwork]) { // You Wang
        
        MBProgressHUD *HUD;
        if (animation) { // 如果需要动画
            HUD = [MBProgressHUD showHUDAddedTo:[UIApplication sharedApplication].keyWindow animated:YES];
            
            UIImage  *image=[UIImage sd_animatedGIFNamed:@"loading"];
            UIImageView  *gifview=[[UIImageView alloc]initWithFrame:CGRectMake(0,0,200, 200)];
            gifview.image=image;
            HUD.customView=gifview;
            // 再设置模式
            HUD.mode = MBProgressHUDModeCustomView;
            HUD.bezelView.style = MBProgressHUDBackgroundStyleSolidColor;
            HUD.bezelView.backgroundColor = [UIColor clearColor];
            // Change the background view style and color.
            HUD.backgroundView.style = MBProgressHUDBackgroundStyleSolidColor;
            HUD.backgroundView.color = [UIColor colorWithWhite:0.f alpha:0.1f];
        }
        
        // 1.创建请求管理者
        AFHTTPSessionManager *mgr = [AFHTTPSessionManager manager];
        
        // Https证书
//        [self httpsCerConfig:mgr];
        
        mgr.requestSerializer.timeoutInterval = 8.f;
        mgr.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/html", @"text/plain", @"text/json", nil];
        NSDate *date = [NSDate dateWithTimeIntervalSinceNow:0];
        NSTimeInterval dateIn=[date timeIntervalSince1970];
        // 设置请求头部
        [mgr.requestSerializer setValue:APP_VERSION forHTTPHeaderField:@"DAXUE-VERSION"];
        [mgr.requestSerializer setValue:@"IOS" forHTTPHeaderField:@"DAXUE-PLATFORM"];
        [mgr.requestSerializer setValue:@"com.qydx.www" forHTTPHeaderField:@"DAXUE-PACKAGE"];
        [mgr.requestSerializer setValue:[NSString stringWithFormat:@"%0.f", dateIn] forHTTPHeaderField:@"DAXUE-TIMESTAMP"];
        
        if ([GLOBAL_CACHE hasCacheForKey:SESSION_ID]) {
            NSMutableString *cookieString = [[NSMutableString alloc] init];
            [cookieString appendFormat:@"JSESSIONID=%@;", [GLOBAL_CACHE stringForKey:SESSION_ID]];
            [mgr.requestSerializer setValue:cookieString forHTTPHeaderField:@"Cookie"];
        }
        
        int i = 0;
        for (NSString* key in params) {
            NSString *value = params[key];
            if (i==0) {
                url = [url stringByAppendingFormat:@"?%@=%@", key, value];
            } else {
                url = [url stringByAppendingFormat:@"&%@=%@", key, value];
            }
            i++;
        }
        
        NSString *urlMD5Com = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        
        // 2.发送请求
        [mgr POST:urlMD5Com parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            [HUD hideAnimated:YES];
            if (success && [responseObject[@"code"] isEqualToString:@"0000"]) {
                success(responseObject);
            } else if ([responseObject[@"code"] isEqualToString:@"0403"]) { // 重新登录
                LoginIndexViewController *vc = [[LoginIndexViewController alloc] init];
                [UIApplication sharedApplication].keyWindow.rootViewController = [[BaseNavigationViewController alloc] initWithRootViewController:vc];
            } else { // 信息错误
                [MBProgressHUD showError:responseObject[@"message"]];
            }
#if DEBUG//调试状态，打开LOG功能
            NSData *jsonData = [NSJSONSerialization dataWithJSONObject:responseObject options:NSJSONWritingPrettyPrinted error:nil];
            NSString *jsonStr = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
            NSLog(@"请求地址%@---正确结果%@",urlMD5Com, jsonStr);
#endif
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            [HUD hideAnimated:YES];
            if (failure) {
                if (animation) [MBProgressHUD showError:errorMsg];
                NSLog(@"请求地址%@---错误原因%@",urlMD5Com, error);
                failure(error);
            }
        }];
        
    } else {
        [MBProgressHUD hideHUD];
        [self showNoNetworkAlert];
    }
}

+ (void)getWeb:(NSString *)url params:(NSDictionary *)params animation:(BOOL)animation success:(void (^)(id json))success failure:(void (^)(NSError *error))failure
{
    
    if ([HWHttpTool isExistenceNetwork]) { // You Wang
        
        MBProgressHUD *HUD;
        if (animation) { // 如果需要动画
            HUD = [MBProgressHUD showHUDAddedTo:[UIApplication sharedApplication].keyWindow animated:YES];
            
            UIImage  *image=[UIImage sd_animatedGIFNamed:@"loading"];
            UIImageView  *gifview=[[UIImageView alloc]initWithFrame:CGRectMake(0,0,200, 200)];
            gifview.image=image;
            HUD.customView=gifview;
            // 再设置模式
            HUD.mode = MBProgressHUDModeCustomView;
            HUD.bezelView.style = MBProgressHUDBackgroundStyleSolidColor;
            HUD.bezelView.backgroundColor = [UIColor clearColor];
            // Change the background view style and color.
            HUD.backgroundView.style = MBProgressHUDBackgroundStyleSolidColor;
            HUD.backgroundView.color = [UIColor colorWithWhite:0.f alpha:0.1f];
        }
        
        // 1.创建请求管理者
        AFHTTPSessionManager *mgr = [AFHTTPSessionManager manager];
        
        // Https证书
        //        [self httpsCerConfig:mgr];
        
        mgr.requestSerializer.timeoutInterval = 8.f;
        mgr.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/html", @"text/plain", @"text/json", nil];
        NSDate *date = [NSDate dateWithTimeIntervalSinceNow:0];
        NSTimeInterval dateIn=[date timeIntervalSince1970];
        // 设置请求头部
        [mgr.requestSerializer setValue:APP_VERSION forHTTPHeaderField:@"DAXUE-VERSION"];
        [mgr.requestSerializer setValue:@"IOS" forHTTPHeaderField:@"DAXUE-PLATFORM"];
        [mgr.requestSerializer setValue:@"com.qydx.www" forHTTPHeaderField:@"DAXUE-PACKAGE"];
        [mgr.requestSerializer setValue:[NSString stringWithFormat:@"%0.f", dateIn] forHTTPHeaderField:@"DAXUE-TIMESTAMP"];
        
        if ([GLOBAL_CACHE hasCacheForKey:SESSION_ID]) {
            NSMutableString *cookieString = [[NSMutableString alloc] init];
            [cookieString appendFormat:@"JSESSIONID=%@;", [GLOBAL_CACHE stringForKey:SESSION_ID]];
            [mgr.requestSerializer setValue:cookieString forHTTPHeaderField:@"Cookie"];
        }
        
        int i = 0;
        for (NSString* key in params) {
            NSString *value = params[key];
            if (i==0) {
                url = [url stringByAppendingFormat:@"?%@=%@", key, value];
            } else {
                url = [url stringByAppendingFormat:@"&%@=%@", key, value];
            }
            i++;
        }
        
        NSString *urlMD5Com = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        
        // 2.发送请求
        [mgr GET:urlMD5Com parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            [HUD hideAnimated:YES];
            if (success && [responseObject[@"code"] isEqualToString:@"0000"]) {
                success(responseObject);
            } else if ([responseObject[@"code"] isEqualToString:@"0403"]) { // 重新登录
                LoginIndexViewController *vc = [[LoginIndexViewController alloc] init];
                [UIApplication sharedApplication].keyWindow.rootViewController = [[BaseNavigationViewController alloc] initWithRootViewController:vc];
            } else { // 信息错误
                [MBProgressHUD showError:responseObject[@"message"]];
            }
#if DEBUG//调试状态，打开LOG功能
            NSData *jsonData = [NSJSONSerialization dataWithJSONObject:responseObject options:NSJSONWritingPrettyPrinted error:nil];
            NSString *jsonStr = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
            NSLog(@"请求地址%@---正确结果%@",urlMD5Com, jsonStr);
#endif
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            [HUD hideAnimated:YES];
            if (failure) {
                if (animation) [MBProgressHUD showError:errorMsg];
                failure(error);
            }
            NSLog(@"请求地址%@---错误原因%@",urlMD5Com, error);
        }];
        
    } else {
        [MBProgressHUD hideHUD];
        [self showNoNetworkAlert];
    }
}

+ (void)showNoNetworkAlert {

    NSString *message = @"请检查您的网络连接状态或者APP网络权限(设置-前沿商学院-无线数据)";

    [MBProgressHUD showError:message];
}

+ (void)httpsCerConfig:(AFHTTPSessionManager *)mgr {
    // 2.设置证书模式
    mgr.securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeCertificate];
    NSString * cerPath = [[NSBundle mainBundle] pathForResource:@"qysxy.com.cn" ofType:@"cer"];
    NSData * cerData = [NSData dataWithContentsOfFile:cerPath];
    mgr.securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeCertificate withPinnedCertificates:[[NSSet alloc] initWithObjects:cerData, nil]];
    // 客户端是否信任非法证书
    mgr.securityPolicy.allowInvalidCertificates = YES;
    // 是否在证书域字段中验证域名
    [mgr.securityPolicy setValidatesDomainName:NO];
}

+ (BOOL)isExistenceNetwork
{
    BOOL isExistenceNetwork;
    Reachability *reachability = [Reachability reachabilityWithHostName:@"www.apple.com"];
    switch([reachability currentReachabilityStatus]){
        case NotReachable: isExistenceNetwork = FALSE;
            break;
        case ReachableViaWWAN: isExistenceNetwork = TRUE;
            break;
        case ReachableViaWiFi: isExistenceNetwork = TRUE;
            break;
    }
    
    BOOL isBaiDuExistenceNetwork;
    Reachability *baiduReachability = [Reachability reachabilityWithHostName:@"www.baidu.com"];
    switch([baiduReachability currentReachabilityStatus]){
        case NotReachable: isBaiDuExistenceNetwork = FALSE;
            break;
        case ReachableViaWWAN: isBaiDuExistenceNetwork = TRUE;
            break;
        case ReachableViaWiFi: isBaiDuExistenceNetwork = TRUE;
            break;
    }
    return isExistenceNetwork || isBaiDuExistenceNetwork;
}

// 根据字典得出json
+ (NSString *)getJsonStringWithDic:(NSDictionary *)dataDictionary
{
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dataDictionary options:NSJSONWritingPrettyPrinted error:&error];
    NSString *json =[[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    return json;
}
@end
