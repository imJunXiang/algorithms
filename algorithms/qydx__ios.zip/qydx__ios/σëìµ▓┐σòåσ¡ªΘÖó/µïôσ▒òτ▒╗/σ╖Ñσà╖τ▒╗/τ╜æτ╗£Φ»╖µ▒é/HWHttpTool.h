//
//  HWHttpTool.h
//  黑马微博2期
//
//  Created by apple on 14-10-25.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HWHttpTool : NSObject
// 表单请求
+ (void)get:(NSString *)url params:(NSDictionary *)params success:(void (^)(id json))success failure:(void (^)(NSError *error))failure;

+ (void)post:(NSString *)url params:(NSDictionary *)params success:(void (^)(id json))success failure:(void (^)(NSError *error))failure;

+ (void)post:(NSString *)url params:(NSDictionary *)params animation:(BOOL)animation success:(void (^)(id json))success failure:(void (^)(NSError *error))failure;

+ (void)postWeb:(NSString *)url params:(NSDictionary *)params success:(void (^)(id json))success failure:(void (^)(NSError *error))failure; // WebApi 请求

+ (void)postWeb:(NSString *)url params:(NSDictionary *)params success:(void (^)(id json))success;

+ (void)postWebNoAnimation:(NSString *)url params:(NSDictionary *)params success:(void (^)(id json))success failure:(void (^)(NSError *error))failure;

+ (void)postWeb:(NSString *)url params:(NSDictionary *)params animation:(BOOL)animation success:(void (^)(id json))success failure:(void (^)(NSError *error))failure;

+ (void)getWeb:(NSString *)url params:(NSDictionary *)params success:(void (^)(id json))success;

// 其它工具类
+ (NSString *)getJsonStringWithDic:(NSDictionary *)dataDictionary;
+ (BOOL)isExistenceNetwork;
@end
