//
//  VideoInfoTool.h
//  前沿商学院
//
//  Created by 邓壮壮 on 2017/8/29.
//  Copyright © 2017年 edu268. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VideoInfoTool : NSObject

+ (void)saveVideoCurrentTime:(CGFloat)currentTime vid:(NSString *)vid;

@end
