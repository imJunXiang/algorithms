//
//  StatusConst.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/8/7.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "StatusConst.h"

@implementation StatusConst
+ (instancetype)defaultManager
{
    static StatusConst *_instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instance = [[self alloc] init];
        _instance.playIndex = -1;
    });
    return _instance;
}
@end
