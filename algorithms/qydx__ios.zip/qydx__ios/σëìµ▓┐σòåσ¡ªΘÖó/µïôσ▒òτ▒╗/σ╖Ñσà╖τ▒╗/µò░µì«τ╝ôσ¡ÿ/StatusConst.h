//
//  StatusConst.h
//  前沿商学院
//
//  Created by MisterDeng on 2018/8/7.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface StatusConst : NSObject
+ (instancetype)defaultManager;
@property (nonatomic, assign) int playIndex;
@end
