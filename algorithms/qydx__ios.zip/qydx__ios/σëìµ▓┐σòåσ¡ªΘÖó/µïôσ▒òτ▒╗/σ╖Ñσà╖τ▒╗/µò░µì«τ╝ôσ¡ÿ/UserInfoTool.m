//
//  UserInfoTool.m
//  前沿商学院
//
//  Created by 邓壮壮 on 2016/11/21.
//  Copyright © 2016年 edu268. All rights reserved.
//

#import "UserInfoTool.h"

#import "KeyChainStore.h"
#define  KEY_USERNAME_PASSWORD @"com.company.app.usernamepassword"
#define  KEY_USERNAME @"com.company.app.username"
#define  KEY_PASSWORD @"com.company.app.password"

@implementation UserInfoTool

+(NSString *)getUUID
{
    NSString *strUUID = (NSString *)[KeyChainStore load:@"com.company.app.usernamepassword"];
    
    //首次执行该方法时，uuid为空
    if ([strUUID isEqualToString:@""] || !strUUID)
    {
        //生成一个uuid的方法
        CFUUIDRef uuidRef = CFUUIDCreate(kCFAllocatorDefault);
        
        strUUID = (NSString *)CFBridgingRelease(CFUUIDCreateString (kCFAllocatorDefault,uuidRef));
        
        //将该uuid保存到keychain
        [KeyChainStore save:KEY_USERNAME_PASSWORD data:strUUID];
    }
    return strUUID;
}

+ (BOOL)isLogin {
    return [GLOBAL_CACHE hasCacheForKey:SESSION_ID];
//    return NO;
}

+ (NSString *)getUserIcon:(NSString *)icon {
    return [NSString stringWithFormat:@"%@%@", imageUrlString, icon];
}

+ (BOOL)getUserFunction {
    if ([[EGOCache globalCache] hasCacheForKey:USER_FUN]) {
        if ([[[EGOCache globalCache] stringForKey:USER_FUN] isEqualToString:FUN_VALUE]) {
            return YES;
        } else {
            return NO;
        }
    } else {
        return YES;
    }
}

+ (NSURL *)getImgUrl:(NSString *)icon {
    return [NSURL URLWithString:[NSString stringWithFormat:@"%@%@", imageUrlString, icon]];
}

+ (NSString *)getUserName:(NSString *)username weixin:(NSString *)weixinname phone:(NSString *)phone {
    if (username.length!=0) {
        return username;
    } else if (weixinname.length!=0) {
        return weixinname;
    } else if (phone.length!=0) {
        return phone;
    } else {
        return @"匿名用户";
    }
}

+ (NSString *)getVipImgName:(NSInteger)type {
    if (type == 2) {
        return @"fws";
    } else if(type == 1) {
        return @"grhy";
    } else {
        return @"kthy";
    }
}

+ (NSString *)getPassPhone:(NSString *)phone {
    //字符串的替换
    if (phone.length==0) {
        return nil;
    }
    phone = [phone stringByReplacingCharactersInRange:NSMakeRange(3,4) withString:@"****"];
    return phone;
}

+ (NSString *)getFloatMoney:(NSString *)money {
    NSString *outNumber = [NSString stringWithFormat:@"%@",@(money.floatValue)];
    return outNumber;
}

+ (NSString *)getMoneyFormat:(NSString *)money {
    if ([money floatValue]==0) {
        return @"免费";
    } else {
        return [NSString stringWithFormat:@"￥%@", money];
    }
}

+ (NSString *)getDayFormat:(NSString *)timeFlage {
    if ([timeFlage isEqualToString:@"TODAY"]) {
        return @"今天";
    }
    if ([timeFlage isEqualToString:@"YESTERDAY"]) {
        return @"昨天";
    }
    if ([timeFlage isEqualToString:@"ONEWEEK"]) {
        return @"一周内";
    }
    if ([timeFlage isEqualToString:@"ONEMONTH"]) {
        return @"一月内";
    }
    if ([timeFlage isEqualToString:@"LATEST"]) {
        return @"最新";
    }
    return nil;
}


+ (void)logout {
    [HWHttpTool postWeb:[HTTPInterface logout] params:@{@"userId": USERID} animation:NO success:nil failure:nil];
}


+ (void)recordLearning:(NSString *)kpointId courseId:(NSString *)courseId progress:(double)progress duration:(double)duration {
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    if (courseId) params[@"courseId"] = courseId;
    if (kpointId) params[@"kpointId"] = kpointId;
    if (!isnan(duration)) params[@"duration"] = @(duration);
    if (!isnan(progress)) params[@"progress"] = @(progress);
    params[@"userId"] = USERID;

    [HWHttpTool getWeb:[ApiConst courseAppKpointProgressRecord] params:params success:^(id json) {
        
    }];
}



@end
