//
//  VideoInfoTool.m
//  前沿商学院
//
//  Created by 邓壮壮 on 2017/8/29.
//  Copyright © 2017年 edu268. All rights reserved.
//

#import "VideoInfoTool.h"

@implementation VideoInfoTool

+ (void)saveVideoCurrentTime:(CGFloat)currentTime vid:(NSString *)vid {
    NSMutableDictionary *mDict = [NSMutableDictionary dictionaryWithDictionary:[ [NSUserDefaults standardUserDefaults] dictionaryForKey:@"dict"]];
    if (currentTime!=0 && !isnan(currentTime)) {
        [mDict setValue:@(currentTime) forKey:vid];
        [[NSUserDefaults standardUserDefaults] setObject:mDict forKey:@"dict"];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
}

@end
