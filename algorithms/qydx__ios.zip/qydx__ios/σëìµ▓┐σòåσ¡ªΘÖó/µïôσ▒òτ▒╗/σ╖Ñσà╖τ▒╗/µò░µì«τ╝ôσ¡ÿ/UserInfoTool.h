//
//  UserInfoTool.h
//  前沿商学院
//
//  Created by 邓壮壮 on 2016/11/21.
//  Copyright © 2016年 edu268. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface UserInfoTool : NSObject

+(NSString *)getUUID;

+ (BOOL)isLogin;

+ (NSString *)getUserIcon:(NSString *)icon;

+ (NSURL *)getImgUrl:(NSString *)icon;

+ (BOOL)getUserFunction;

+ (NSString *)getUserName:(NSString *)username weixin:(NSString *)weixinname phone:(NSString *)phone;

+ (NSString *)getVipImgName:(NSInteger)type;

+ (NSString *)getPassPhone:(NSString *)phone;

+ (NSString *)getFloatMoney:(NSString *)money;

+ (NSString *)getMoneyFormat:(NSString *)money;

+ (NSString *)getDayFormat:(NSString *)timeFlage;

+ (void)pushMessageClickAction:(UIViewController *)nowVC model:(NSDictionary *)model;

+ (void)logout;

+ (void)login;

+ (void)recordLearning:(NSString *)kpointId courseId:(NSString *)courseId progress:(double)progress duration:(double)duration;

+ (void)shareMessageWithError:(NSError *)error;


@end
