//
//  DiscoverIndexViewController.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/6/29.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "DiscoverIndexViewController.h"
#import "SGPagingView.h"
#import "DiscoverIndexCell.h"
#import "HistoryIndexViewController.h"
#import "CollectionIndexViewController.h"
#import "AAChartKit.h"

@interface DiscoverIndexViewController ()<UITableViewDelegate, UITableViewDataSource, SGPageTitleViewDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSArray *cellModelArr;
@property (nonatomic, strong) AAChartModel *chartModel;
@property (nonatomic, strong) UILabel *titleLb2;
@property (nonatomic, strong) UILabel *titleLb3;
@property (nonatomic, strong) AAChartView *lineChart;
@end

@implementation DiscoverIndexViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    [self buildHeaderView];
    [self buildTableView];
    [self initData];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    self.tableView.height = self.view.height-248-45;
}

#pragma mark - DATA
- (void)initData {
    [self loadData];
}

- (void)loadData {
    [HWHttpTool getWeb:[ApiConst kpointStudytimeAppRecords] params:nil success:^(id json) {
        NSDictionary *data = json[@"result"];
        NSString *time = [NSString stringWithFormat:@"%.1f", [data[@"maxTime"] floatValue]/3600];
        NSString *day = [NSString stringWithObject:data[@"dayCount"]];
        self.titleLb2.attributedText = [NSString ls_changeCorlorWithColor:[UIColor appBlueColor] TotalString:[NSString stringWithFormat:@"学习时长：%@小时", time] subString:[NSString stringWithFormat:@"%@小时", time]];
        self.titleLb3.attributedText = [NSString ls_changeCorlorWithColor:[UIColor appBlueColor] TotalString:[NSString stringWithFormat:@"连续学习%@天", day] subString:[NSString stringWithFormat:@"%@天", day]];
        [self setData:data[@"records"]];
        [self.titleLb2 updateLayout];
        [self.titleLb3 updateLayout];
    }];
}

- (void)setData:(NSArray *)records {
    NSMutableArray *dataArr = [NSMutableArray array];
    NSMutableArray *dayArr = [NSMutableArray array];
    for (NSDictionary *model in records) {
        [dataArr addObject:@([model[@"dayMaxTime"] integerValue]/60)];
        NSString *a = [model[@"day"] substringFromIndex:4];
        NSString *b = [a substringToIndex:2];
        NSString *c = [a substringFromIndex:2];
        [dayArr addObject:[NSString stringWithFormat:@"%@.%@", b, c]];
    }
    
    NSDictionary *gradientColorDic = @{
                                       @"linearGradient": @{
                                               @"x1": @0,
                                               @"y1": @1,
                                               @"x2": @0,
                                               @"y2": @0
                                               },
                                       @"stops": @[@[@0,@"#f5f7ff"],
                                                   @[@1,@"#6079ff"]]//颜色字符串设置支持十六进制类型和 rgba 类型
                                       };
    
    self.chartModel = AAObject(AAChartModel)
    .chartTypeSet(AAChartTypeSpline)
    .animationDurationSet(@1000)
    .titleSet(@"")
    .subtitleSet(@"")
    .categoriesSet(dayArr)
    .yAxisTitleSet(@"")
    .markerRadiusSet(@4)
    .gradientColorEnabledSet(false)
    .yAxisVisibleSet(false)
    .symbolStyleSet(AAChartSymbolStyleTypeInnerBlank)
    .legendEnabledSet(false)
    .xAxisCrosshairColorSet(@"#6079ff")
    .dataLabelFontColorSet(@"#6079ff")
    .dataLabelEnabledSet(true)
    .dataLabelFontSizeSet(@9)
    .dataLabelFontWeightSet(@"300")
    .xAxisLabelsFontColorSet(@"#999999")
    .tooltipEnabledSet(false)
    .seriesSet(@[
                 AAObject(AASeriesElement)
                 .lineWidthSet(@1)
                 .dataSet(dataArr)
                 .colorSet(@"#6079ff")
                 ,
                 ]);
    [self.lineChart aa_drawChartWithChartModel:self.chartModel];
}
#pragma mark - ACTION
- (void)rightItemClick {
    
}
#pragma mark - UI

- (void)buildHeaderView {
    self.cellModelArr = @[@{@"icon": @"历史", @"name": @"历史记录"}, @{@"icon": @"收藏-2拷贝", @"name": @"我的收藏"}];
    UIView *headerV = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 248+45)];
    headerV.backgroundColor = [UIColor appBackGroundColor];
    [self.view addSubview:headerV];
    
    UIView *backV = [[UIView alloc] init];
    backV.backgroundColor = [UIColor whiteColor];
    [headerV addSubview:backV];
    
    UILabel *titleLb1 = [[UILabel alloc] init];
    titleLb1.textColor = [UIColor appTextColor];
    titleLb1.font = [UIFont systemFontOfSize:16 weight:400];
    titleLb1.textAlignment = NSTextAlignmentLeft;
    [backV addSubview:titleLb1];
    titleLb1.text = @"学习记录";
    
    UILabel *titleLb2 = [[UILabel alloc] init];
    titleLb2.font = [UIFont systemFontOfSize:14];
    titleLb2.textColor = [UIColor appLightTextColor];
    titleLb2.textAlignment = NSTextAlignmentLeft;
    [backV addSubview:titleLb2];
    self.titleLb2 = titleLb2;
    
    UILabel *titleLb3 = [[UILabel alloc] init];
    titleLb3.font = [UIFont systemFontOfSize:14];
    titleLb3.textColor = [UIColor appLightTextColor];
    titleLb3.textAlignment = NSTextAlignmentRight;
    [backV addSubview:titleLb3];
    self.titleLb3 = titleLb3;
    
    UILabel *titleLb4 = [[UILabel alloc] init];
    titleLb4.textColor = [UIColor appLightTextColor];
    titleLb4.font = [UIFont systemFontOfSize:10];
    titleLb4.textAlignment = NSTextAlignmentRight;
    [backV addSubview:titleLb4];
    titleLb4.text = @"最近7天的学习时长 / 单位：分钟";
    
    AAChartView *lineChart = [[AAChartView alloc] init];
    lineChart.userInteractionEnabled = NO;
    [backV addSubview:lineChart];
    self.lineChart = lineChart;
    
    UIView *titleV = [[UIView alloc] init];
    titleV.backgroundColor = [UIColor whiteColor];
    [headerV addSubview:titleV];
    
    UILabel *titleLb = [[UILabel alloc] init];
    titleLb.textColor = [UIColor appTextColor];
    titleLb.font = [UIFont systemFontOfSize:16 weight:400];
    titleLb.textAlignment = NSTextAlignmentLeft;
    [titleV addSubview:titleLb];
    titleLb.text = @"学习清单";
    
    backV.sd_layout
    .topSpaceToView(headerV, 10)
    .leftSpaceToView(headerV, 0)
    .rightSpaceToView(headerV, 0)
    .heightIs(228);
    
    titleLb1.sd_layout
    .topSpaceToView(backV, 15)
    .leftSpaceToView(backV, 15)
    .widthIs(120)
    .heightIs(20);
    
    titleLb2.sd_layout
    .topSpaceToView(titleLb1, 10)
    .leftSpaceToView(backV, 15)
    .heightIs(14);
    [titleLb2 setSingleLineAutoResizeWithMaxWidth:150];
    
    titleLb3.sd_layout
    .topSpaceToView(titleLb1, 10)
    .rightSpaceToView(backV, 15)
    .heightIs(14);
    [titleLb3 setSingleLineAutoResizeWithMaxWidth:150];
    
    titleLb4.sd_layout
    .topSpaceToView(titleLb3, 15)
    .leftSpaceToView(backV, 15)
    .heightIs(10);
    [titleLb4 setSingleLineAutoResizeWithMaxWidth:150];
    
    lineChart.sd_layout
    .topSpaceToView(titleLb4, 0)
    .leftSpaceToView(backV, 10)
    .rightSpaceToView(backV, 10)
    .bottomSpaceToView(backV, 0);
    
    titleV.sd_layout
    .topSpaceToView(backV, 10)
    .leftSpaceToView(headerV, 0)
    .rightSpaceToView(headerV, 0)
    .bottomSpaceToView(headerV, 0);
    
    titleLb.sd_layout
    .centerYEqualToView(titleV)
    .leftSpaceToView(titleV, 15)
    .widthIs(120)
    .heightIs(20);
    
    [headerV addSeparateLineMargin];
    
}

- (void)buildTableView {
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 248+45, SCREEN_WIDTH, self.view.height-248-45) style:UITableViewStylePlain];
    self.tableView.backgroundColor = [UIColor appBackGroundColor];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.showsHorizontalScrollIndicator = NO;
    self.tableView.scrollEnabled = NO;
    [self.view addSubview:self.tableView];
}

#pragma mark - Delegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.cellModelArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *model = self.cellModelArr[indexPath.row];
    DiscoverIndexCell *cell = [DiscoverIndexCell cellWithTableView:tableView];
    cell.model = model;
    if (indexPath.row==1) {
        cell.sepV.hidden = YES;
    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 45;
}

- (void)pageTitleView:(SGPageTitleView *)pageTitleView selectedIndex:(NSInteger)selectedIndex {
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row==0) {
        HistoryIndexViewController *vc = [[HistoryIndexViewController alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
    }
    if (indexPath.row==1) {
        CollectionIndexViewController *vc = [[CollectionIndexViewController alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
    }
}

@end
