//
//  CollectionIndexViewController.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/3.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "CollectionIndexViewController.h"
#import "CollectionIndexCell.h"
#import "CourseDetailViewController.h"

@interface CollectionIndexViewController ()<UITableViewDelegate, UITableViewDataSource>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, assign) NSInteger pageindex;
@property (nonatomic, strong) NSMutableArray *modelArr;
@end

@implementation CollectionIndexViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initData];
    [self buildTableView];
    [self buildEmptyView:0 title:nil];
    [self.view addSeparateLineTop];
}

- (void)initData {
    self.pageindex = 1;
    self.modelArr = [NSMutableArray array];
    [self.tableView.mj_footer resetNoMoreData];
    [self loadData];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    self.tableView.height = self.view.height;
}

- (void)loadData {
    NSDictionary *params = @{@"pageindex": @(self.pageindex), @"pageSize":PAGE_COUNT};
    [HWHttpTool getWeb:[ApiConst favoritesAppList] params:params success:^(id json) {
        NSDictionary *data = json[@"result"];
        if ([data[@"pages"] integerValue]<=self.pageindex) {
            [self.tableView.mj_footer endRefreshingWithNoMoreData];
        }
        
        [self.modelArr addObjectsFromArray:data[@"records"]];
        [self.tableView reloadData];
        [self emptyReload:self.modelArr];
    }];
}

- (void)deleteData:(NSInteger)row {
    NSDictionary *params = @{@"favoriteId": self.modelArr[row][@"id"]};
    [HWHttpTool postWeb:[ApiConst favoritesAppRemove] params:params success:^(id json) {
        
    }];
}

- (void)buildTableView {
    self.navigationItem.title = @"我的收藏";
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGTH) style:UITableViewStylePlain];
    self.tableView.backgroundColor = [UIColor appBackGroundColor];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.showsHorizontalScrollIndicator = NO;
    [self.view addSubview:self.tableView];
    
    Weak(self);
    self.tableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        wArg.pageindex++;
        [wArg loadData];
        [wArg.tableView.mj_footer endRefreshing];
    }];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.modelArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *model = self.modelArr[indexPath.row];
    CollectionIndexCell *cell = [CollectionIndexCell cellWithTableView:tableView];
    cell.model = model;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *model = self.modelArr[indexPath.row];
    CourseDetailViewController *vc = [[CourseDetailViewController alloc] init];
    vc.courseId = [NSString stringWithObject:model[@"courseId"]];
    [self.navigationController pushViewController:vc animated:YES];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 45;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}

-(NSArray<UITableViewRowAction*>*)tableView:(UITableView *)tableView editActionsForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewRowAction *delAction = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleNormal title:@"移除" handler:^(UITableViewRowAction * _Nonnull action, NSIndexPath * _Nonnull indexPath) {
        // 点击删除时 do something
        [self deleteData:indexPath.row];
        [self.modelArr removeObjectAtIndex:indexPath.row];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation: UITableViewRowAnimationFade];
    }];
    delAction.backgroundColor = [UIColor colorWithMacHexString:@"#fd9525"];
    NSArray *arr = @[delAction];
    return arr;
}



@end
