//
//  CollectionIndexCell.h
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/3.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CollectionIndexCell : UITableViewCell
+ (instancetype)cellWithTableView:(UITableView *)tableView;
@property (nonatomic, strong) UIImageView *iconImgV;
@property (nonatomic, strong) UILabel *nameLb;
@property (nonatomic, strong) UILabel *perLb;

@property (nonatomic, strong) NSDictionary *model;
@end
