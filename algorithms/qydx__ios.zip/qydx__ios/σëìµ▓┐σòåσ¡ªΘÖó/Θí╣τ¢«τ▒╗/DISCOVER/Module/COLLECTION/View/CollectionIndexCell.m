//
//  CollectionIndexCell.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/3.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "CollectionIndexCell.h"

@implementation CollectionIndexCell

- (void)setModel:(NSDictionary *)model {
    _model = model;
    self.nameLb.text = model[@"courseTitle"];
    
    if (model[@"sumPlayProgress"]!=nil && model[@"sumDuration"]!=nil) {
        float p = [model[@"sumPlayProgress"] floatValue];
        float d = [model[@"sumDuration"] floatValue];
        float result;
        if (p==0||d==0) {
            result = 0;
        } else {
            result = p/d>1?1:p/d;
        }
        self.perLb.text = [NSString stringWithFormat:@"%.f%%", result*100];
    } else {
        self.perLb.text = @"0%";
    }
}

+ (instancetype)cellWithTableView:(UITableView *)tableView
{
    NSString *cellID = @"CollectionIndexCell";
    CollectionIndexCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell == nil) {
        cell = [[CollectionIndexCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
    }
    
    return cell;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    [self buildView];
    return self;
}

- (void)buildView {
    UIImageView *iconImgV = [[UIImageView alloc] init];
    iconImgV.image = [UIImage imageNamed:@"dis_3"];
    [self addSubview:iconImgV];
    self.iconImgV = iconImgV;
    
    UILabel *nameLb = [[UILabel alloc] init];
    nameLb.textColor = [UIColor appTextColor];
    nameLb.font = [UIFont systemFontOfSize:14];
    nameLb.textAlignment = NSTextAlignmentLeft;
    [self addSubview:nameLb];
    self.nameLb = nameLb;
    
    UILabel *perLb = [[UILabel alloc] init];
    perLb.textColor = [UIColor appTextColor];
    perLb.font = [UIFont systemFontOfSize:14];
    perLb.textAlignment = NSTextAlignmentLeft;
    [self addSubview:perLb];
    self.perLb = perLb;
    
    UIButton *bookBtn = [[UIButton alloc] init];
    [bookBtn setBackgroundImage:[UIImage imageNamed:@"备忘录拷贝6"] forState:UIControlStateNormal];
    [self addSubview:bookBtn];
    
    [self addSeparateLineMargin];
    
    iconImgV.sd_layout
    .centerYEqualToView(self)
    .leftSpaceToView(self, 15)
    .widthIs(18)
    .heightIs(18);
    
    bookBtn.sd_layout
    .centerYEqualToView(self)
    .rightSpaceToView(self, 15)
    .widthIs(16)
    .heightIs(19);
    
    perLb.sd_layout
    .centerYEqualToView(self)
    .rightSpaceToView(bookBtn, 15)
    .heightIs(15);
    [perLb setSingleLineAutoResizeWithMaxWidth:200];
    
    nameLb.sd_layout
    .centerYEqualToView(self)
    .leftSpaceToView(iconImgV, 10)
    .rightSpaceToView(perLb, 15)
    .heightIs(15);

}

@end
