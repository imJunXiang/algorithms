//
//  HistoryIndexViewController.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/3.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "HistoryIndexViewController.h"
#import "HistoryIndexCell.h"
#import "HistoryIndexHeaderCell.h"
#import "CourseDetailViewController.h"
#import "HistoryIndexHeaderView.h"

@interface HistoryIndexViewController ()<UITableViewDelegate, UITableViewDataSource>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, assign) NSInteger pageindex;
@property (nonatomic, strong) NSMutableArray *modelArr;
@property (nonatomic, copy) NSString *dateStr;
@property (nonatomic, strong) NSMutableArray *record;
@end

@implementation HistoryIndexViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self buildTableView];
    [self buildEmptyView:0 title:nil];
    [self initData];
    [self.view addSeparateLineTop];
}

- (void)initData {
    self.pageindex = 1;
    self.modelArr = [NSMutableArray array];
    [self.tableView.mj_footer resetNoMoreData];
    [self loadData];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    self.tableView.height = self.view.height;
}

- (void)loadData {
    NSDictionary *params = @{@"page": @(self.pageindex),@"pageSize":@"10000"};
    [HWHttpTool getWeb:[ApiConst courseStudyhistoryAppList] params:params success:^(id json) {
        NSDictionary *data = json[@"result"];
        if ([data[@"pages"] integerValue]<=self.pageindex) {
            [self.tableView.mj_footer endRefreshingWithNoMoreData];
        }
        
        [self.modelArr addObjectsFromArray:data[@"records"]];
        [self formatData];
        [self.tableView reloadData];
        [self emptyReload:self.modelArr];
    }];
}

- (void)formatData {
    if (self.modelArr==nil||self.modelArr.count==0) {
        return;
    }
    NSString *lastDate = [NSDate dateWithOriginal:self.modelArr[0][@"update_time"] format:@"yyyy/MM/dd"];
    NSMutableArray *record = [NSMutableArray array];
    NSMutableArray *modelArr = [NSMutableArray array];
    for (int i=0; i<self.modelArr.count; i++) {
        NSDictionary *model = self.modelArr[i];
        NSString *date = [NSDate dateWithOriginal:model[@"update_time"] format:@"yyyy/MM/dd"];
        if (i==self.modelArr.count-1) {
            // 记录值
            NSMutableDictionary *data = [NSMutableDictionary dictionary];
            [data setObject:modelArr forKey:@"record"];
            [data setObject:lastDate forKey:@"date"];
            [record addObject:data];
            modelArr = [NSMutableArray array];
            lastDate = date;
        } else if ([date isEqualToString:lastDate]) {
            [modelArr addObject:model];
        } else {
            // 记录值
            NSMutableDictionary *data = [NSMutableDictionary dictionary];
            [data setObject:modelArr forKey:@"record"];
            [data setObject:lastDate forKey:@"date"];
            [record addObject:data];
            modelArr = [NSMutableArray array];
            lastDate = date;
            i--;
        }
    }
    
    self.record = record;
}

- (void)buildTableView {
    self.navigationItem.title = @"历史记录";
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGTH) style:UITableViewStylePlain];
    self.tableView.backgroundColor = [UIColor whiteColor];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.showsHorizontalScrollIndicator = NO;
    [self.view addSubview:self.tableView];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.record.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSArray *modelArr = self.record[section][@"record"];
    return modelArr.count;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    NSDictionary *model = self.record[section];
    HistoryIndexHeaderView *headerV = [[HistoryIndexHeaderView alloc] init];
    headerV.dateLb.text = model[@"date"];
    headerV.topSepV.hidden = section==0;
    return headerV;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *model = self.record[indexPath.section];
    NSDictionary *subModel = model[@"record"][indexPath.row];
    HistoryIndexCell *cell = [HistoryIndexCell cellWithTableView:tableView];
    cell.nameLb.text = subModel[@"courseTitle"];
    cell.timeLb.text = [NSDate dateWithOriginal:subModel[@"update_time"] format:@"HH:mm"];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 50;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 40;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *model = self.record[indexPath.section];
    NSDictionary *subModel = model[@"record"][indexPath.row];
    CourseDetailViewController *vc = [[CourseDetailViewController alloc] init];
    vc.courseId = [NSString stringWithObject:subModel[@"courseId"]];
    [self.navigationController pushViewController:vc animated:YES];
}

@end
