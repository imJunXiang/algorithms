//
//  HistoryIndexCell.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/3.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "HistoryIndexCell.h"

@implementation HistoryIndexCell

+ (instancetype)cellWithTableView:(UITableView *)tableView
{
    NSString *cellID = @"HistoryIndexCell";
    HistoryIndexCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell == nil) {
        cell = [[HistoryIndexCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
    }
    
    return cell;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    [self buildView];
    return self;
}

- (void)buildView {
    UIView *sepV = [[UIView alloc] init];
    sepV.backgroundColor = [UIColor appBlueColor];
    [self addSubview:sepV];
    
    UILabel *timeLb = [[UILabel alloc] init];
    timeLb.textColor = [UIColor appGrayTextColor];
    timeLb.font = [UIFont systemFontOfSize:9];
    timeLb.textAlignment = NSTextAlignmentLeft;
    [self addSubview:timeLb];
    self.timeLb = timeLb;
    
    UILabel *nameLb = [[UILabel alloc] init];
    nameLb.textColor = [UIColor appTextColor];
    nameLb.font = [UIFont systemFontOfSize:14];
    nameLb.textAlignment = NSTextAlignmentLeft;
    [self addSubview:nameLb];
    self.nameLb = nameLb;
    
    sepV.sd_layout
    .topSpaceToView(self, 0)
    .leftSpaceToView(self, 18)
    .bottomSpaceToView(self, 0)
    .widthIs(2);
    
    timeLb.sd_layout
    .topSpaceToView(self, 10)
    .leftSpaceToView(sepV, 20)
    .widthIs(120)
    .heightIs(7);
    
    nameLb.sd_layout
    .topSpaceToView(timeLb, 7)
    .leftSpaceToView(sepV, 20)
    .rightSpaceToView(self, 15)
    .heightIs(7);
}

@end
