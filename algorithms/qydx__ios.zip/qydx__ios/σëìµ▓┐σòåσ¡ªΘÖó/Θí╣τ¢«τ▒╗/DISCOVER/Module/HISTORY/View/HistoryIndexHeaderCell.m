//
//  HistoryIndexHeaderView.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/3.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "HistoryIndexHeaderCell.h"

@implementation HistoryIndexHeaderCell

+ (instancetype)cellWithTableView:(UITableView *)tableView
{
    NSString *cellID = @"HistoryIndexHeaderCell";
    HistoryIndexHeaderCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell == nil) {
        cell = [[HistoryIndexHeaderCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
    }
    
    return cell;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    [self buildView];
    return self;
}

- (void)buildView {
    self.backgroundColor = [UIColor whiteColor];
    
    UIImageView *iconImgV = [[UIImageView alloc] init];
    iconImgV.image = [UIImage imageNamed:@"his_1"];
    [self addSubview:iconImgV];
    
    UIView *sepV = [[UIView alloc] init];
    sepV.backgroundColor = [UIColor appBlueColor];
    [self addSubview:sepV];
    
    UIView *topSepV = [[UIView alloc] init];
    topSepV.backgroundColor = [UIColor appBlueColor];
    [self addSubview:topSepV];
    self.topSepV = topSepV;
    
    UILabel *dateLb = [[UILabel alloc] init];
    dateLb.textColor = [UIColor appTextColor];
    dateLb.font = [UIFont systemFontOfSize:14];
    dateLb.textAlignment = NSTextAlignmentLeft;
    [self addSubview:dateLb];
    self.dateLb = dateLb;
    
    UILabel *timeLb = [[UILabel alloc] init];
    timeLb.textColor = [UIColor appGrayTextColor];
    timeLb.font = [UIFont systemFontOfSize:9];
    timeLb.textAlignment = NSTextAlignmentLeft;
    [self addSubview:timeLb];
    self.timeLb = timeLb;
    
    UILabel *nameLb = [[UILabel alloc] init];
    nameLb.textColor = [UIColor appTextColor];
    nameLb.font = [UIFont systemFontOfSize:14];
    nameLb.textAlignment = NSTextAlignmentLeft;
    [self addSubview:nameLb];
    self.nameLb = nameLb;
    
    iconImgV.sd_layout
    .topSpaceToView(self, 13)
    .leftSpaceToView(self, 15)
    .widthIs(8)
    .heightIs(8);
    
    sepV.sd_layout
    .topSpaceToView(iconImgV, 0)
    .leftSpaceToView(self, 18)
    .bottomSpaceToView(self, 0)
    .widthIs(2);
    
    topSepV.sd_layout
    .bottomSpaceToView(iconImgV, 0)
    .leftSpaceToView(self, 18)
    .topSpaceToView(self, 0)
    .widthIs(2);
    
    dateLb.sd_layout
    .topSpaceToView(self, 10)
    .leftSpaceToView(sepV, 20)
    .widthIs(120)
    .heightIs(14);
    
    timeLb.sd_layout
    .topSpaceToView(self, 50)
    .leftSpaceToView(sepV, 20)
    .widthIs(120)
    .heightIs(7);
    
    nameLb.sd_layout
    .topSpaceToView(timeLb, 7)
    .leftSpaceToView(sepV, 20)
    .rightSpaceToView(self, 15)
    .heightIs(7);
}

@end
