//
//  HistoryIndexHeaderView.h
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/3.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HistoryIndexHeaderCell : UITableViewCell
@property (nonatomic, strong) UILabel *timeLb;
@property (nonatomic, strong) UIView *topSepV;
@property (nonatomic, strong) UILabel *nameLb;
@property (nonatomic, strong) UILabel *dateLb;
+ (instancetype)cellWithTableView:(UITableView *)tableView;
@end
