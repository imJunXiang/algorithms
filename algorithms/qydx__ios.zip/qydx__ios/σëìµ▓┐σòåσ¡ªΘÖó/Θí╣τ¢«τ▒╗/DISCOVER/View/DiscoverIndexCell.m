//
//  DiscoverIndexCell.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/6/29.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "DiscoverIndexCell.h"

@implementation DiscoverIndexCell

- (void)setModel:(NSDictionary *)model {
    _model = model;
    self.iconImgV.image = [UIImage imageNamed:model[@"icon"]];
    self.nameLb.text = model[@"name"];
}

+ (instancetype)cellWithTableView:(UITableView *)tableView
{
    NSString *cellID = @"DiscoverIndexCell";
    DiscoverIndexCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell == nil) {
        cell = [[DiscoverIndexCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
    }
    
    return cell;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    [self buildView];
    return self;
}

- (void)buildView {
    UIImageView *iconImgV = [[UIImageView alloc] init];
    [self addSubview:iconImgV];
    self.iconImgV = iconImgV;
    
    UILabel *nameLb = [[UILabel alloc] init];
    nameLb.textColor = [UIColor appTextColor];
    nameLb.font = [UIFont systemFontOfSize:15];
    nameLb.textAlignment = NSTextAlignmentLeft;
    [self addSubview:nameLb];
    self.nameLb = nameLb;
    
    iconImgV.sd_layout
    .centerYEqualToView(self)
    .leftSpaceToView(self, 15)
    .widthIs(17)
    .heightIs(17);
    
    nameLb.sd_layout
    .topEqualToView(iconImgV)
    .leftSpaceToView(iconImgV, 15)
    .rightSpaceToView(self, 15)
    .heightIs(16);
    
    self.sepV = [self addSeparateLineMargin];
    [self addArrowImgView];
}

@end
