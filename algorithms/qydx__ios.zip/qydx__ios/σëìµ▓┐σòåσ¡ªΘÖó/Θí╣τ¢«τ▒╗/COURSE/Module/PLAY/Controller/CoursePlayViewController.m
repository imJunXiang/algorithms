//
//  CoursePlayViewController.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/5.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "CoursePlayViewController.h"
#import "CoursePlayListViewController.h"
#import "CoursePlayTextViewController.h"
#import "STKAudioPlayer.h"
#import "SampleQueueId.h"
#import "StatusConst.h"

@interface CoursePlayViewController ()<STKAudioPlayerDelegate>
@property (nonatomic, strong) UILabel *nameLb;
@property (nonatomic, strong) UISlider *slider;
@property (nonatomic, strong) UILabel *timeLb1;
@property (nonatomic, strong) UILabel *timeLb2;
@property (nonatomic, strong) UIButton *playBtn;
@property (nonatomic, strong) UIImageView *courseImgV;
@property (nonatomic, strong) NSTimer *timer;
@property (nonatomic, strong) STKAudioPlayer *audioPlayer;
@property (nonatomic, strong) NSURL *musicUrl;
@property (nonatomic, strong) NSArray *listArr;
@end

@implementation CoursePlayViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self buildMainUI];
    [self setupTimer];
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    [StatusConst defaultManager].playIndex = self.playIndex;
}

+ (instancetype)defaultManager:(NSDictionary *)model
{
    static CoursePlayViewController *_instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instance = [[self alloc] init];
        _instance.model = model;
        _instance.listArr = model[@"courseKpoints"];
        _instance.playIndex = -1;
        
        NSError * error;
        if (error) {
            NSLog(@"Proxy Start Failure, %@", error);
        } else {
            NSLog(@"Proxy Start Success");
        }
    });
    return _instance;
}


#pragma mark - DATA
- (void)setPlayIndex:(int)playIndex {
    if (self.playIndex==playIndex||playIndex<0) {
        if (playIndex<0) {
            _playIndex = playIndex;
        }
        return;
    }
    _playIndex = playIndex;
    self.musicUrl = [NSURL URLWithString:self.listArr[self.playIndex][@"audio_url"]];
    [self loadData];
}


-(void) setupTimer {
    self.timer = [NSTimer timerWithTimeInterval:0.1 target:self selector:@selector(tick) userInfo:nil repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:self.timer forMode:NSRunLoopCommonModes];
}

- (void)loadData {
    self.navigationItem.title = self.model[@"title"];
    self.nameLb.text = self.listArr[self.playIndex][@"title"];
    self.courseImgV.image = [UIImage imageNamed:@"course_1"];

    [self switchMusicUrl];
    
}
#pragma mark - ACTION
- (void)toolbarLeftClick {
    CoursePlayListViewController *vc = [[CoursePlayListViewController alloc] init];
    vc.listArr = self.listArr;
    vc.playIndex = self.playIndex;
    vc.playVC = self;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)toolbarRightClick {
    NSDictionary *model = self.listArr[self.playIndex];
    CoursePlayTextViewController *vc = [[CoursePlayTextViewController alloc] init];
    vc.kpointId = [NSString stringWithObject:model[@"id"]];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)switchMusicUrl {
    STKDataSource* dataSource = [STKAudioPlayer dataSourceFromURL:self.musicUrl];
    [self.audioPlayer setDataSource:dataSource withQueueItemId:[[SampleQueueId alloc] initWithUrl:self.musicUrl andCount:0]];
    self.playBtn.selected = YES;
}

- (void)leftPlayClick {
    if (self.playIndex<=0) {
        [MBProgressHUD showError:@"已经是第一集"];
        return;
    }
    self.playIndex--;
}

- (void)rightPlayClick {
    if (self.playIndex>=self.listArr.count-1) {
        [MBProgressHUD showError:@"已经是最后一集"];
        return;
    }
    self.playIndex++;
}

-(void)sliderChanged
{
    if (!self.audioPlayer)
    {
        return;
    }
    
    NSLog(@"Slider Changed: %f", self.slider.value);
    
    [self.audioPlayer seekToTime:self.slider.value];
}

- (void)playClick:(UIButton *)button {
    button.selected = !button.selected;
    if (button.selected) {// 开始播放
        [self.audioPlayer resume];
    } else {
        [self.audioPlayer pause];
    }
}

#pragma mark - UI
-(NSString*) formatTimeFromSeconds:(int)totalSeconds
{
    int seconds = totalSeconds % 60;
    int minutes = totalSeconds / 60;
    
    return [NSString stringWithFormat:@"%02d:%02d", minutes, seconds];
}

- (void)buildMainUI {
    self.view.backgroundColor = [UIColor appBackGroundColor];
    
    UIImageView *backImgV = [[UIImageView alloc] init];
    backImgV.image = [UIImage imageNamed:@"course_2"];
    [self.view addSubview:backImgV];
    
    [self.view addSubview:self.courseImgV];
    
    [self.view addSubview:self.nameLb];
    
    UISlider *slider = [[UISlider alloc] init];
    [slider setTintColor:[UIColor appBlueColor]];
    slider.thumbTintColor = [UIColor colorWithMacHexString:@"#d9dcff"];
    [slider setThumbImage:[UIImage imageNamed:@"course_3"] forState:UIControlStateNormal];
    [slider setThumbImage:[UIImage imageNamed:@"course_3"] forState:UIControlStateSelected];
    [slider addTarget:self action:@selector(sliderChanged) forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:slider];
    self.slider = slider;
    
    UILabel *timeLb1 = [[UILabel alloc] init];
    timeLb1.textColor = [UIColor appGrayTextColor];
    timeLb1.font = [UIFont systemFontOfSize:12];
    timeLb1.textAlignment = NSTextAlignmentLeft;
    [self.view addSubview:timeLb1];
    self.timeLb1 = timeLb1;
    
    UILabel *timeLb2 = [[UILabel alloc] init];
    timeLb2.textColor = [UIColor appGrayTextColor];
    timeLb2.font = [UIFont systemFontOfSize:12];
    timeLb2.textAlignment = NSTextAlignmentRight;
    [self.view addSubview:timeLb2];
    self.timeLb2 = timeLb2;
    
    self.timeLb1.text = @"00:00";
    self.timeLb2.text = @"00:00";
    
    [self.view addSubview:self.playBtn];
    
    UIButton *leftBtn = [[UIButton alloc] init];
    [leftBtn setBackgroundImage:[UIImage imageNamed:@"course_8"] forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(leftPlayClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:leftBtn];
    
    UIButton *rightBtn = [[UIButton alloc] init];
    [rightBtn setBackgroundImage:[UIImage imageNamed:@"course_7"] forState:UIControlStateNormal];
    [rightBtn addTarget:self action:@selector(rightPlayClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:rightBtn];
    
    UIView *toolbarV = [[UIView alloc] init];
    toolbarV.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:toolbarV];
    
    UIButton *toolbarLV = [self buildToolbarBtn:@"目录列表" icon:@"course_4"];
    [toolbarLV addTarget:self action:@selector(toolbarLeftClick) forControlEvents:UIControlEventTouchUpInside];
    [toolbarV addSubview:toolbarLV];
    
    UIButton *toolbarRV = [self buildToolbarBtn:@"文字" icon:@"course_6"];
     [toolbarRV addTarget:self action:@selector(toolbarRightClick) forControlEvents:UIControlEventTouchUpInside];
    [toolbarV addSubview:toolbarRV];
    
    backImgV.sd_layout
    .topSpaceToView(self.view, 0)
    .leftSpaceToView(self.view, 0)
    .rightSpaceToView(self.view, 0)
    .heightIs(183*HEIGHT_RADIO);
    
    self.courseImgV.sd_layout
    .topSpaceToView(self.view, 30)
    .centerXEqualToView(self.view)
    .widthIs(185)
    .heightIs(240);
    
    self.nameLb.sd_layout
    .topSpaceToView(self.courseImgV, 30)
    .leftSpaceToView(self.view, 15)
    .rightSpaceToView(self.view, 15)
    .heightIs(16);
    
    slider.sd_layout
    .topSpaceToView(self.nameLb, 30)
    .leftSpaceToView(self.view, 55)
    .rightSpaceToView(self.view, 55)
    .heightIs(20);
    
    timeLb1.sd_layout
    .topSpaceToView(slider, 10)
    .leftEqualToView(slider)
    .widthIs(50)
    .heightIs(10);
    
    timeLb2.sd_layout
    .topSpaceToView(slider, 10)
    .rightEqualToView(slider)
    .widthIs(50)
    .heightIs(10);
    
    self.playBtn.sd_layout
    .topSpaceToView(slider, 33)
    .centerXEqualToView(self.view)
    .widthIs(82)
    .heightIs(82);
    
    leftBtn.sd_layout
    .centerYEqualToView(self.playBtn)
    .rightSpaceToView(self.playBtn, 50)
    .widthIs(16)
    .heightIs(19);
    
    rightBtn.sd_layout
    .centerYEqualToView(self.playBtn)
    .leftSpaceToView(self.playBtn, 50)
    .widthIs(16)
    .heightIs(19);
    
    toolbarV.sd_layout
    .bottomSpaceToView(self.view, 0)
    .leftSpaceToView(self.view, 0)
    .rightSpaceToView(self.view, 0)
    .heightIs(50);
    
    toolbarLV.sd_layout
    .topSpaceToView(toolbarV, 0)
    .leftSpaceToView(toolbarV, 0)
    .widthIs(SCREEN_WIDTH/2)
    .heightIs(50);
    
    toolbarRV.sd_layout
    .topSpaceToView(toolbarV, 0)
    .rightSpaceToView(toolbarV, 0)
    .widthIs(SCREEN_WIDTH/2)
    .heightIs(50);
}

- (UIButton *)buildToolbarBtn:(NSString *)title icon:(NSString *)icon {
    UIButton *backBtn = [[UIButton alloc] init];
    
    UIImageView *iconImgV = [[UIImageView alloc] init];
    iconImgV.image = [UIImage imageNamed:icon];
    [backBtn addSubview:iconImgV];
    
    UILabel *titleLb = [[UILabel alloc] init];
    titleLb.textColor = [UIColor appBlueColor];
    titleLb.font = [UIFont systemFontOfSize:11];
    titleLb.textAlignment = NSTextAlignmentCenter;
    [backBtn addSubview:titleLb];
    titleLb.text = title;
    
    iconImgV.sd_layout
    .topSpaceToView(backBtn, 10)
    .centerXEqualToView(backBtn)
    .widthIs(17)
    .heightIs(17);
    
    titleLb.sd_layout
    .topSpaceToView(iconImgV, 7)
    .centerXEqualToView(backBtn)
    .widthIs(50)
    .heightIs(11);
    
    return backBtn;
}

#pragma mark - Delegate
-(void) audioPlayer:(STKAudioPlayer*)audioPlayer unexpectedError:(STKAudioPlayerErrorCode)errorCode
{
    
}

-(void) audioPlayer:(STKAudioPlayer*)audioPlayer didStartPlayingQueueItemId:(NSObject*)queueItemId
{
    SampleQueueId* queueId = (SampleQueueId*)queueItemId;
    
    NSLog(@"Started: %@", [queueId.url description]);
}

-(void) audioPlayer:(STKAudioPlayer*)audioPlayer didFinishBufferingSourceWithQueueItemId:(NSObject*)queueItemId
{
    [self rightPlayClick];
}

-(void) audioPlayer:(STKAudioPlayer*)audioPlayer didFinishPlayingQueueItemId:(NSObject*)queueItemId withReason:(STKAudioPlayerStopReason)stopReason andProgress:(double)progress andDuration:(double)duration
{
    
}

-(void) audioPlayer:(STKAudioPlayer *)audioPlayer logInfo:(NSString *)line
{
    NSLog(@"%@", line);
}

- (void)audioPlayer:(STKAudioPlayer *)audioPlayer didReadStreamMetadata:(NSDictionary *)dictionary
{
    
}

-(void) audioPlayer:(STKAudioPlayer*)audioPlayer stateChanged:(STKAudioPlayerState)state previousState:(STKAudioPlayerState)previousState
{
    //    STKAudioPlayerStateReady,
    //    STKAudioPlayerStateRunning = 1,
    //    STKAudioPlayerStatePlaying = (1 << 1) | STKAudioPlayerStateRunning,
    //    STKAudioPlayerStateBuffering = (1 << 2) | STKAudioPlayerStateRunning,
    //    STKAudioPlayerStatePaused = (1 << 3) | STKAudioPlayerStateRunning,
    //    STKAudioPlayerStateStopped = (1 << 4),
    //    STKAudioPlayerStateError = (1 << 5),
    //    STKAudioPlayerStateDisposed = (1 << 6)
    NSString *stateName;
    switch (previousState) {
        case STKAudioPlayerStateReady:
            stateName = @"STKAudioPlayerStateReady";
            break;
        case STKAudioPlayerStateRunning:
            stateName = @"STKAudioPlayerStateRunning";
            break;
        case STKAudioPlayerStatePlaying:
            stateName = @"STKAudioPlayerStatePlaying";
            break;
        case STKAudioPlayerStateBuffering:
            stateName = @"STKAudioPlayerStateBuffering";
            break;
        case STKAudioPlayerStatePaused:
            stateName = @"STKAudioPlayerStatePaused";
            break;
        case STKAudioPlayerStateStopped:
            stateName = @"STKAudioPlayerStateStopped";
            break;
        case STKAudioPlayerStateError:
            stateName = @"STKAudioPlayerStateError";
            break;
        case STKAudioPlayerStateDisposed:
            stateName = @"STKAudioPlayerStateDisposed";
            break;
        default:
            stateName = @"i do not konw";
            break;
    }
    NSLog(@"播放器状态%@", stateName);
}

- (STKAudioPlayer *)audioPlayer {
    if (_audioPlayer==nil) {
        self.audioPlayer = [[STKAudioPlayer alloc] initWithOptions:(STKAudioPlayerOptions){ .flushQueueOnSeek = YES, .enableVolumeMixer = NO, .equalizerBandFrequencies = {50, 100, 200, 400, 800, 1600, 2600, 16000} }];
        self.audioPlayer.delegate = self;
    }
    return _audioPlayer;
}

-(void) tick
{
    
    if (!self.audioPlayer)
    {
        self.slider.value = 0;
        return;
    }
    
    if (self.audioPlayer.currentlyPlayingQueueItemId == nil)
    {
        self.slider.value = 0;
        self.slider.minimumValue = 0;
        self.slider.maximumValue = 0;
        return;
    }
    
    if (self.audioPlayer.duration != 0)
    {
        self.slider.minimumValue = 0;
        self.slider.maximumValue = self.audioPlayer.duration;
        self.slider.value = self.audioPlayer.progress;
        
        self.timeLb1.text = [self formatTimeFromSeconds:self.audioPlayer.progress];
        self.timeLb2.text = [self formatTimeFromSeconds:self.audioPlayer.duration];
    }
    else
    {
        self.slider.value = 0;
        self.slider.minimumValue = 0;
        self.slider.maximumValue = 0;
    }
    
}

- (UIButton *)playBtn {
    if (_playBtn==nil) {
        UIButton *playBtn = [[UIButton alloc] init];
        [playBtn setBackgroundImage:[UIImage imageNamed:@"course_5"] forState:UIControlStateNormal];
        [playBtn setBackgroundImage:[UIImage imageNamed:@"course_9"] forState:UIControlStateSelected];
        [playBtn addTarget:self action:@selector(playClick:) forControlEvents:UIControlEventTouchUpInside];
        self.playBtn = playBtn;
    }
    return _playBtn;
}

- (UILabel *)nameLb {
    if (_nameLb==nil) {
        UILabel *nameLb = [[UILabel alloc] init];
        nameLb.textColor = [UIColor appTextColor];
        nameLb.font = [UIFont systemFontOfSize:15 weight:400];
        nameLb.textAlignment = NSTextAlignmentCenter;
        self.nameLb = nameLb;
    }
    return _nameLb;
}

- (UIImageView *)courseImgV {
    if (_courseImgV==nil) {
        UIImageView *courseImgV = [[UIImageView alloc] init];
        self.courseImgV = courseImgV;
    }
    return _courseImgV;
}

@end
