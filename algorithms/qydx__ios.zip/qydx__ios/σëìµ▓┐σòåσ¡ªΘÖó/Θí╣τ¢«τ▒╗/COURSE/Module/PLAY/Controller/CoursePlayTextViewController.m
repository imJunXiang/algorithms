//
//  CoursePlayTextViewController.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/6.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "CoursePlayTextViewController.h"
#import "CoursePlayListCell.h"

@interface CoursePlayTextViewController ()
@property (nonatomic, strong) UIWebView *webV;
@property (nonatomic, strong) UILabel *nameLb;
@property (nonatomic, strong) UILabel *teacherLb;
@property (nonatomic, strong) UIScrollView *scrollV;
@end

@implementation CoursePlayTextViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    self.automaticallyAdjustsScrollViewInsets = NO;
    [self buildMainUI];
    
    [HWHttpTool getWeb:[NSString stringWithFormat:@"%@/%@", [ApiConst courseKpointDetail], self.kpointId] params:nil success:^(id json) {
        NSDictionary *data = json[@"result"];
        self.nameLb.text = data[@"title"];
        self.teacherLb.text = @"讲师：娄强";
        [self.webV loadHTMLString:data[@"description"] baseURL:nil];
    }];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    self.scrollV.height = self.view.height;
}

- (void)buildMainUI {
    UIScrollView *scrollV = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, self.view.height)];
    scrollV.showsHorizontalScrollIndicator = NO;
    scrollV.showsVerticalScrollIndicator = NO;
    if (@available(iOS 11.0, *)) {
        scrollV.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    } else {
        // Fallback on earlier versions
    }
    [self.view addSubview:scrollV];
    self.scrollV = scrollV;
    
    UILabel *nameLb = [[UILabel alloc] init];
    nameLb.textColor = [UIColor appTextColor];
    nameLb.font = [UIFont systemFontOfSize:15 weight:400];
    nameLb.textAlignment = NSTextAlignmentLeft;
    [scrollV addSubview:nameLb];
    self.nameLb = nameLb;
    
    UILabel *teacherLb = [[UILabel alloc] init];
    teacherLb.textColor = [UIColor appGrayTextColor];
    teacherLb.font = [UIFont systemFontOfSize:12];
    teacherLb.textAlignment = NSTextAlignmentLeft;
    [scrollV addSubview:teacherLb];
    self.teacherLb = teacherLb;
    
    UIWebView *webV = [[UIWebView alloc] init];
    webV.scrollView.bounces = NO;
    webV.allowsInlineMediaPlayback = YES;
    [webV.scrollView addObserver:self forKeyPath:@"contentSize" options:NSKeyValueObservingOptionNew context:nil];
    [scrollV addSubview:webV];
    self.webV = webV;
    
    nameLb.sd_layout
    .topSpaceToView(scrollV, 20)
    .leftSpaceToView(scrollV, 15)
    .rightSpaceToView(scrollV, 15)
    .heightIs(15);
    
    teacherLb.sd_layout
    .topSpaceToView(nameLb, 15)
    .leftSpaceToView(scrollV, 15)
    .rightSpaceToView(scrollV, 15)
    .heightIs(12);
    
    webV.sd_layout
    .topSpaceToView(teacherLb, 20)
    .leftSpaceToView(scrollV, 15)
    .rightSpaceToView(scrollV, 15)
    .heightIs(1);
    
    [scrollV setupAutoHeightWithBottomView:webV bottomMargin:10];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context {
    if ([keyPath isEqualToString:@"contentSize"]) {
        CGSize size = [self.webV sizeThatFits:CGSizeZero];
        self.webV.sd_layout.heightIs(size.height);
    }
}


@end
