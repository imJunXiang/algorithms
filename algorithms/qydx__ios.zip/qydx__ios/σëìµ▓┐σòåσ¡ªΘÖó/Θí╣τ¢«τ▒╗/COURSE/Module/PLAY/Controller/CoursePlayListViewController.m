//
//  CoursePlayListViewController.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/6.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "CoursePlayListViewController.h"
#import "CourseDetailListView.h"
#import "CoursePlayListCell.h"
#import "CoursePlayTextViewController.h"

@interface CoursePlayListViewController ()<UITableViewDelegate, UITableViewDataSource>
@property (nonatomic, strong) UITableView *tableView;
@end

@implementation CoursePlayListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self buildTableView];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    self.tableView.height = self.view.height;
}

- (void)buildTableView {
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGTH) style:UITableViewStylePlain];
    self.tableView.backgroundColor = [UIColor appBackGroundColor];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.showsHorizontalScrollIndicator = NO;
    [self.view addSubview:self.tableView];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.listArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *model = self.listArr[indexPath.row];
    CoursePlayListCell *cell = [CoursePlayListCell cellWithTableView:tableView];
    cell.model = model;
    [cell changeColor:indexPath.row playIndex:self.playIndex];
    cell.textClickBlock = ^() {
        CoursePlayTextViewController *vc = [[CoursePlayTextViewController alloc] init];
        vc.kpointId = [NSString stringWithObject:model[@"id"]];
        [self.navigationController pushViewController:vc animated:YES];
    };
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 45;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    self.playVC.playIndex = indexPath.row;
    [self.navigationController popViewControllerAnimated:YES];
}

@end
