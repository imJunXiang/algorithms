//
//  CoursePlayListCell.h
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/6.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CoursePlayListCell : UITableViewCell
@property (nonatomic, strong) UILabel *nameLb;
@property (nonatomic, strong) UILabel *perLb;
@property (nonatomic, strong) NSDictionary *model;
- (void)changeColor:(NSInteger)index playIndex:(NSInteger)playIndex;
+ (instancetype)cellWithTableView:(UITableView *)tableView;
@property (nonatomic, copy) void (^textClickBlock) ();
@end
