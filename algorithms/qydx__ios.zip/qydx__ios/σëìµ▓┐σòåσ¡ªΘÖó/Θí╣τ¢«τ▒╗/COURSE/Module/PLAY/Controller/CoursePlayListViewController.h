//
//  CoursePlayListViewController.h
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/6.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "BaseViewController.h"
#import "CoursePlayViewController.h"

@interface CoursePlayListViewController : BaseViewController
@property (nonatomic, strong) NSArray *listArr;
@property (nonatomic, assign) int playIndex;
@property (nonatomic, strong) CoursePlayViewController *playVC;
@end
