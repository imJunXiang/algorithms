//
//  CoursePlayListCell.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/6.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "CoursePlayListCell.h"

@implementation CoursePlayListCell

- (void)setModel:(NSDictionary *)model {
    _model = model;
    self.nameLb.text = model[@"title"];
    
    if (model[@"paly_progress_last"]!=nil && model[@"kpoint_duration_time"]!=nil) {
        float p = [model[@"paly_progress_last"] floatValue];
        float d = [model[@"kpoint_duration_time"] floatValue];
        float result;
        if (p==0||d==0) {
            result = 0;
        } else {
            result = p/d>1?1:p/d;
        }
        if (result==1) {
            self.perLb.text = @"重新学习";
        } else if (result == 0) {
            self.perLb.text = @"开始学习";
        } else {
            self.perLb.text = [NSString stringWithFormat:@"%.f%%", result*100];
        }
    } else {
        self.perLb.text = @"开始学习";
    }
}

- (void)changeColor:(NSInteger)index playIndex:(NSInteger)playIndex {
    if (index==playIndex) {
        self.nameLb.textColor = [UIColor appBlueColor];
    } else if ([self.perLb.text isEqualToString:@"重新学习"]) {
        self.nameLb.textColor = [UIColor appLightTextColor];
        self.perLb.backgroundColor = [UIColor appLightTextColor];
    } else {
        self.nameLb.textColor = [UIColor appTextColor];
        self.perLb.backgroundColor = [UIColor appBlueColor];
    }
}

- (void)bookClick {
    if (self.textClickBlock!=nil) {
        self.textClickBlock();
    }
}

+ (instancetype)cellWithTableView:(UITableView *)tableView
{
    NSString *cellID = @"CoursePlayListCell";
    CoursePlayListCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell == nil) {
        cell = [[CoursePlayListCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
    }
    
    return cell;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    [self buildView];
    return self;
}

- (void)buildView {
    self.backgroundColor = [UIColor clearColor];
    UIView *backV = [[UIView alloc] init];
    [self addSubview:backV];
    
    UILabel *countLb = [[UILabel alloc] init];
    countLb.textColor = [UIColor appTextColor];
    countLb.font = [UIFont systemFontOfSize:14];
    countLb.textAlignment = NSTextAlignmentLeft;
//    [backV addSubview:countLb];
    
    UILabel *nameLb = [[UILabel alloc] init];
    nameLb.textColor = [UIColor appTextColor];
    nameLb.font = [UIFont systemFontOfSize:14];
    nameLb.textAlignment = NSTextAlignmentLeft;
    [backV addSubview:nameLb];
    self.nameLb = nameLb;
    
    UIButton *bookBtn = [[UIButton alloc] init];
    [bookBtn setBackgroundImage:[UIImage imageNamed:@"备忘录拷贝6"] forState:UIControlStateNormal];
    [bookBtn addTarget:self action:@selector(bookClick) forControlEvents:UIControlEventTouchUpInside];
    [backV addSubview:bookBtn];
    
    UILabel *perLb = [[UILabel alloc] init];
    perLb.textColor = [UIColor whiteColor];
    perLb.font = [UIFont systemFontOfSize:10];
    perLb.textAlignment = NSTextAlignmentCenter;
    perLb.sd_cornerRadius = @(10);
    perLb.backgroundColor = [UIColor appBlueColor];
    [backV addSubview:perLb];
    self.perLb = perLb;
    
    backV.sd_layout
    .topSpaceToView(self, 0)
    .leftSpaceToView(self, 0)
    .rightSpaceToView(self, 0)
    .bottomSpaceToView(self, 0);
    
    countLb.sd_layout
    .centerYEqualToView(backV)
    .leftSpaceToView(backV, 15)
    .widthIs(16)
    .heightIs(11);
    
    perLb.sd_layout
    .centerYEqualToView(backV)
    .rightSpaceToView(backV, 15)
    .widthIs(47)
    .heightIs(20);
    
    bookBtn.sd_layout
    .centerYEqualToView(backV)
    .rightSpaceToView(perLb, 15)
    .widthIs(16)
    .heightIs(20);
    
    nameLb.sd_layout
    .centerYEqualToView(backV)
    .leftSpaceToView(backV, 15)
    .rightSpaceToView(bookBtn, 10)
    .heightIs(14);
}

@end
