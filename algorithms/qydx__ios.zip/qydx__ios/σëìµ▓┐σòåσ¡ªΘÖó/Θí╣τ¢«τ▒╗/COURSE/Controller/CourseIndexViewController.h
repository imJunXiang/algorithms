//
//  CourseIndexViewController.h
//  前沿商学院
//
//  Created by MisterDeng on 2018/6/29.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "BaseViewController.h"

@interface CourseIndexViewController : BaseViewController

@end
