//
//  DiscoverIndexViewController.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/6/29.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "CourseIndexViewController.h"
#import "SGPagingView.h"
#import "CourseIndexCell.h"
#import "PYSearchViewController.h"
#import "CourseDetailViewController.h"

@interface CourseIndexViewController ()<UITableViewDelegate, UITableViewDataSource, SGPageTitleViewDelegate, PYSearchViewControllerDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSArray *catesArr;
@property (nonatomic, strong) NSMutableArray *coursesArr;
@property (nonatomic, assign) NSInteger pageindex;
@property (nonatomic, copy) NSString *cateId;
@end

@implementation CourseIndexViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.coursesArr = [NSMutableArray array];
    self.pageindex = 1;
    [self loadData];
    [self buildNavItem];
    [self buildTableView];
    [self buildEmptyView:44 title:nil];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    self.tableView.height = self.view.height-44;
}

#pragma mark - DATA
- (void)loadData {
    [HWHttpTool getWeb:[ApiConst productClassAppList] params:nil success:^(id json) {
        NSDictionary *data = json[@"result"];
        self.catesArr = data[@"records"];
        [self buildHeaderView];
    }];
    [self loadHotSearch];
}

- (void)loadCourseData {
    NSDictionary *params = @{@"categoryId": self.cateId, @"page": @(self.pageindex),@"pageSize":PAGE_COUNT};
    [HWHttpTool getWeb:[ApiConst courseClassList] params:params success:^(id json) {
        NSDictionary *data = json[@"result"];
        if ([data[@"pages"] integerValue]<=self.pageindex) {
            [self.tableView.mj_footer endRefreshingWithNoMoreData];
        }
        
        [self.coursesArr addObjectsFromArray:data[@"records"]];
        [self.tableView reloadData];
        
        [self emptyReload:self.coursesArr];
    }];
}

- (void)loadHotSearch {
    [HWHttpTool getWeb:[ApiConst courseSearchHotList] params:nil success:^(id json) {
        NSDictionary *data = json[@"result"];
        NSArray *dataArr = data[@"records"];
        NSMutableArray *titles = [NSMutableArray array];
        for (NSDictionary *model in dataArr) {
            [titles addObject:model[@"keywords"]];
        }
        [GLOBAL_CACHE setObject:titles forKey:@"hot_search"];
    }];
}

#pragma mark - ACTION
- (void)rightItemClick {
    // 1.创建热门搜索
    NSArray *hotSeaches = (NSArray *)[GLOBAL_CACHE objectForKey:@"hot_search"];
    // 2. 创建控制器
    PYSearchViewController *searchViewController = [PYSearchViewController searchViewControllerWithHotSearches:hotSeaches searchBarPlaceholder:@"输入您要搜索的内容" didSearchBlock:^(PYSearchViewController *searchViewController, UISearchBar *searchBar, NSString *searchText) {
        
    }];
    searchViewController.cancelButton = nil;
    searchViewController.delegate = self;
    searchViewController.searchBarBackgroundColor = [UIColor appBackGroundColor];
    searchViewController.searchResultShowMode = PYSearchResultShowModeCustom;
    searchViewController.hotSearchStyle = PYHotSearchStyleARCBorderTag; // 热门搜索风格为默认
    searchViewController.searchSuggestionHidden = NO;
    // 5. 跳转到搜索控制器
    [self.navigationController pushViewController:searchViewController animated:YES];
}
#pragma mark - UI
- (void)buildNavItem {
    if (self.navigationItem.title==nil) {
        self.navigationItem.title = @"课程中心";
    }
    self.navigationItem.rightBarButtonItem = [UIBarButtonItem itemWithTarget:self action:@selector(rightItemClick) image:@"dis_2" highImage:@"dis_2"];
}

- (void)buildHeaderView {
    if (self.catesArr.count==0) {
        return;
    }
    NSMutableArray *titles = [NSMutableArray array];
    for (NSDictionary *model in self.catesArr) {
        [titles addObject:model[@"classFullName"]];
    }
    
    SGPageTitleViewConfigure *configure = [SGPageTitleViewConfigure pageTitleViewConfigure];
    configure.titleFont = [UIFont systemFontOfSize:14];
    configure.titleSelectedFont = [UIFont systemFontOfSize:14];
    configure.titleColor = [UIColor appLightTextColor];
    configure.titleSelectedColor = [UIColor appTextColor];
    configure.indicatorStyle = SGIndicatorStyleFixed;
    configure.indicatorFixedWidth = 30;
    configure.bottomSeparatorColor = [UIColor clearColor];
    
    SGPageTitleView *pageTitleView = [SGPageTitleView pageTitleViewWithFrame:CGRectMake(0, 0, self.view.width, 44) delegate:self titleNames:titles configure:configure];
    [self.view addSubview:pageTitleView];
    
    pageTitleView.indicatorView.image = [UIImage imageNamed:@"dis_1"];
}

- (void)buildTableView {
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 44, SCREEN_WIDTH, self.view.height-44) style:UITableViewStylePlain];
    self.tableView.contentInset = UIEdgeInsetsMake(10, 0, 0, 0);
    self.tableView.backgroundColor = [UIColor appBackGroundColor];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.showsHorizontalScrollIndicator = NO;
    [self.view addSubview:self.tableView];
    
    Weak(self);
    self.tableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        wArg.pageindex++;
        [wArg loadCourseData];
        [wArg.tableView.mj_footer endRefreshing];
    }];
}

#pragma mark - Delegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.coursesArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *model = self.coursesArr[indexPath.row];
    CourseIndexCell *cell = [CourseIndexCell cellWithTableView:tableView];
    cell.model = model;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 130;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *model = self.coursesArr[indexPath.row];
    CourseDetailViewController *vc = [[CourseDetailViewController alloc] init];
    vc.courseId = [NSString stringWithObject:model[@"courseId"]];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)pageTitleView:(SGPageTitleView *)pageTitleView selectedIndex:(NSInteger)selectedIndex {
    self.cateId = self.catesArr[selectedIndex][@"id"];
    self.pageindex = 1;
    self.coursesArr = [NSMutableArray array];
    [self.tableView.mj_footer resetNoMoreData];
    [self loadCourseData];
}

- (void)searchViewController:(PYSearchViewController *)searchViewController  searchTextDidChange:(UISearchBar *)seachBar searchText:(NSString *)searchText
{
    NSDictionary *params = @{@"title": searchText};
    [HWHttpTool getWeb:[ApiConst courseSearch] params:params success:^(id json) {
        NSDictionary *data = json[@"result"];
        searchViewController.searchText = searchText;
        searchViewController.searchSuggestions = data[@"records"];
    }];
}

- (void)searchViewController:(PYSearchViewController *)searchViewController didSearchWithsearchBar:(UISearchBar *)searchBar searchText:(NSString *)searchText
{
    NSDictionary *params = @{@"title": searchText};
    [HWHttpTool getWeb:[ApiConst courseSearch] params:params success:^(id json) {
        NSDictionary *data = json[@"result"];
        searchViewController.searchText = searchText;
        searchViewController.searchSuggestions = data[@"records"];
    }];
}


@end
