//
//  CourseDetailViewController.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/5.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "CourseDetailViewController.h"
#import "CourseDetailHeaderView.h"
#import "CourseDetailListView.h"
#import "CourseDetailContentCell.h"
#import "CoursePlayViewController.h"
#import "SoundPlayView.h"
#import "VideoInfoTool.h"
#import "ZFPlayerView.h"
#import "ZFPlayerModel.h"
#import "TXPlayerAuthParams.h"
#import "TXVodPlayer.h"
#import "TXMoviePlayerNetApi.h"
#import "TXMoviePlayerNetDelegate.h"
#import "TXMoviePlayInfoResponse.h"
#import "CoursePlayListCell.h"
#import "CoursePlayTextViewController.h"
#import "StatusConst.h"

@interface CourseDetailViewController ()<ZFPlayerDelegate, TXMoviePlayerNetDelegate, UITableViewDelegate, UITableViewDataSource>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) SoundPlayView *soundView;
@property (nonatomic, copy) NSURL *videoURL;
@property (nonatomic, copy) NSString *soundUrl;
@property (nonatomic, strong) CourseDetailHeaderView *headerV;
@property (nonatomic, copy) NSString *playingKpointId;
@property (nonatomic, strong) ZFPlayerView *playerView;
@property (nonatomic, strong) CourseDetailContentCell *contentV;
@property (nonatomic, strong) ZFPlayerModel *playerModel;
@property (nonatomic, strong) TXVodPlayer *getInfoPlayer;
/** 播放器View的父视图*/
@property (nonatomic) UIView *playerFatherView;
@property (nonatomic, strong) NSDictionary *courseModel;
@property (nonatomic, strong) TXMoviePlayerNetApi *getInfoNetApi;
@property (nonatomic, strong) NSArray *listArr;
@property (nonatomic, copy) NSString *videoId;
@property (nonatomic, assign) int playIndex;
@property (nonatomic, strong) TXPlayerAuthParams *p;
@property (nonatomic, assign) BOOL isVideo;
@end

@implementation CourseDetailViewController
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.playIndex = -1;
    }
    return self;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = YES;
}

-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    self.navigationController.navigationBarHidden = NO;
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    self.tableView.height = self.view.height+[UIView getStatusBarHeight];
    if (!self.isVideo) {
        self.playIndex = [StatusConst defaultManager].playIndex;
        [self.tableView reloadData];
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self buildMainUI];
    [self initData];
}

#pragma mark - DATA
- (void)initData {
    [self loadData];
    self.playerView.soundBtn.selected = NO;
}

- (void)loadData {
    
    [HWHttpTool getWeb:[NSString stringWithFormat:@"%@/%@",[ApiConst courseDetail],self.courseId] params:nil success:^(id json) {
        NSDictionary *data = json[@"result"];
        if ([data isEqual:@""]) {
            [MBProgressHUD showError:@"课程信息异常"];
            return;
        }
        if ([[NSString stringWithObject:data[@"type"]] isEqualToString:@"1"]) {
            self.isVideo = YES;
            self.headerV.playBtn.hidden = NO;
        }
        self.courseModel = data;
        self.headerV.model = data;
        self.listArr = data[@"courseKpoints"];
        if (self.listArr.count>0) {
            self.videoId = self.listArr[0][@"video_id"];
        }
        [self.contentV.webV loadHTMLString:data[@"description"] baseURL:nil];
        [self.contentV.webV.scrollView addObserver:self forKeyPath:@"contentSize" options:NSKeyValueObservingOptionNew context:nil];
        [self.tableView reloadData];
    }];
    
}
#pragma mark - ACTION
- (void)backClick {
    [self videoRecord];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)likeClick:(UIButton *)button {
    button.selected = !button.selected;
    
    if (button.selected) {
        NSDictionary *params = @{@"courseId": self.courseId};
        [HWHttpTool getWeb:[ApiConst favoritesCourseAdd] params:params success:^(id json) {
        }];
    } else {
        NSDictionary *params = @{@"favoriteId": self.courseModel[@"favoriteId"]};
        [HWHttpTool postWeb:[ApiConst favoritesAppRemove] params:params success:^(id json) {
        }];
    }
}

#pragma mark - UI
- (void)buildMainUI {
    [self.view addSubview:self.tableView];
    
    // 视频播放
    self.playerView = [[ZFPlayerView alloc] init];
    self.playerView.hidden = YES;
    [self.playerView playerControlView:nil playerModel:nil];
    // 设置代理
    self.playerView.delegate = self;
    [self.playerView.soundBtn addTarget:self action:@selector(soundPlayAction:) forControlEvents:UIControlEventTouchUpInside];
    
    // 音频播放
    SoundPlayView *soundView = [[SoundPlayView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_WIDTH*9/16)];
    soundView.hidden = YES;
    [self.view addSubview:soundView];
    self.soundView = soundView;
    Weak(self);
    soundView.backClickBlock = ^() {
        [wArg.navigationController popViewControllerAnimated:YES];
    };
    soundView.videoClickBlock = ^(double time) {
        [wArg videoContinue];
    };
    soundView.playClickBlock = ^(UIButton *btn) {
        if (btn.selected) {
            [wArg videoResume];
        } else {
            [wArg videoPause];
        }
    };
    soundView.playOverBlock = ^() {
        [wArg zf_playerOverAction];
    };
    
}

- (void)soundPlayAction:(UIButton *)btn {
    if (btn.selected) {
        [MBProgressHUD showError:@"暂无对应音频"];
        return;
    }
    [self.view bringSubviewToFront:self.soundView];
    [self soundPlay];
}

- (void)remoteControlReceivedWithEvent:(UIEvent *)event {
    if (event.type == UIEventTypeRemoteControl) {  //判断是否为远程控制
        switch (event.subtype) {
            case  UIEventSubtypeRemoteControlPlay:
                [self.soundView resume];
                break;
            case UIEventSubtypeRemoteControlPause:
                [self.soundView pause];
                NSLog(@"暂停");
                break;
            case UIEventSubtypeRemoteControlNextTrack:
               
                break;
            case UIEventSubtypeRemoteControlPreviousTrack:
                
                break;
            default:
                break;
        }
    }
}

#pragma mark - 视频播放
- (void)onNetSuccess:(TXMoviePlayerNetApi *)obj {
    self.playerModel.fatherView       = self.headerV.videoImg;
    self.playerModel.videoURL = [NSURL URLWithString:obj.playInfo.playUrl];
    self.playerModel.placeholderImage = self.headerV.videoImg.image;
    self.playerModel.title = self.courseModel[@"title"];
    NSLog(@"%@", [NSString stringWithFormat:@"腾讯云视频地址%@,vid为%@", self.playerModel.videoURL, self.videoId]);
    [_playerView resetToPlayNewVideo:self.playerModel];
}

- (void)onNetFailed:(TXMoviePlayerNetApi *)obj reason:(NSString *)reason code:(int)code {
    
}

- (void)getNextInfo:(TXPlayerAuthParams *)p {
    
    if (self.getInfoNetApi == nil) {
        self.getInfoNetApi = [[TXMoviePlayerNetApi alloc] init];
        self.getInfoNetApi.delegate = self;
        self.getInfoNetApi.https = TRUE;
    }
    [self.getInfoNetApi getplayinfo:p.appId
                             fileId:p.fileId
                            timeout:p.timeout
                                 us:p.us
                              exper:p.exper
                               sign:p.sign];
}

- (void)videoPlay {
    if (self.listArr==nil||self.listArr.count<=0) {
        return;
    }
    
    if (self.playIndex==-1) {
        self.playIndex = 0;
        [self.tableView reloadData];
    }
    NSDictionary *model = self.listArr[self.playIndex];
    self.videoId = [NSString stringWithObject:model[@"video_id"]];
    self.playerView.hidden = NO;
    self.p = [TXPlayerAuthParams new];
    self.p.appId = 1252754012;
    self.p.fileId = self.videoId;
    
    [self getNextInfo:self.p];
}

- (void)soundPlay {
    NSDictionary *model = self.listArr[self.playIndex];
    self.soundUrl = model[@"audio_url"];
    NSDictionary *info = @{@"image": self.headerV.videoImg.image, @"title": @"", @"url": self.soundUrl};
    [self.soundView playWithInfo:info time:self.playerView.player.currentPlaybackTime];
    [self.playerView pause];
}

- (void)videoPause {
    [self.soundView pause];;
    [self.playerView pause];
}

- (void)videoContinue {
    if ([self.p.fileId isEqualToString:self.videoId]) {
        [self.playerView play];
        [self.playerView.player seek:self.soundView.player.progress];
    } else {
        [self videoPlay];
    }
}

- (void)videoResume {
    if (self.soundView.hidden==NO) { // 音频阶段
        [self.soundView resume];
        [self.playerView pause];
    } else {
        [self.playerView play];
        [self.soundView pause];
    }
}

- (void)videoRecord {
    NSString *kpointId;
    for (NSDictionary *model in self.listArr) {
        if ([[NSString stringWithObject:model[@"video_id"]] isEqualToString:self.videoId]) {
            kpointId = [NSString stringWithObject:model[@"id"]];
        }
    }
    if (self.soundView.hidden==NO) {
        if (!isnan(self.soundView.player.progress) && !isnan(self.soundView.player.duration)) {
            [UserInfoTool recordLearning:kpointId courseId:self.courseId progress:(NSInteger)self.soundView.player.progress duration:(NSInteger)self.soundView.player.duration];
        }
    } else {
        if (!isnan(self.playerView.player.currentPlaybackTime) && !isnan(self.playerView.player.duration)) {
            [UserInfoTool recordLearning:kpointId courseId:self.courseId progress:(NSInteger)self.playerView.player.currentPlaybackTime duration:(NSInteger)self.playerView.player.duration];
        }
    }
}

- (void)zf_playerBackAction {
    [self.navigationController popViewControllerAnimated:YES];
}

- (ZFPlayerModel *)playerModel {
    if (!_playerModel) {
        _playerModel                  = [[ZFPlayerModel alloc] init];
        _playerModel.fatherView = self.headerV.videoImg;
    }
    return _playerModel;
}

#pragma mark - Delegate
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    if (section==0) {
        return self.headerV;
    }
    return [UIView new];
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    UIView *footerView = [UIView new];
    footerView.backgroundColor = [UIColor whiteColor];
    return footerView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (section==0) {
        [self.headerV layoutIfNeeded];
        return self.headerV.height;
    }
    return 0.1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 0.1;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section==0) {
        return self.listArr.count;
    }
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section==0) {
        NSDictionary *model = self.listArr[indexPath.row];
        CoursePlayListCell *cell = [CoursePlayListCell cellWithTableView:tableView];
        cell.model = model;
        [cell changeColor:indexPath.row playIndex:self.playIndex];
        cell.backgroundColor = [UIColor whiteColor];
        cell.textClickBlock = ^() {
            CoursePlayTextViewController *vc = [[CoursePlayTextViewController alloc] init];
            vc.kpointId = [NSString stringWithObject:model[@"id"]];
            [self.navigationController pushViewController:vc animated:YES];
        };
        return cell;
    }
    return self.contentV;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [self videoRecord];
    self.playIndex = (int)indexPath.row;
    if (self.isVideo) { // 播放视频
        if (self.soundView.hidden==YES) {
            [self videoPlay];
        } else {
            [self soundPlay];
        }
    } else {
        CoursePlayViewController *vc = [CoursePlayViewController defaultManager:self.courseModel];
        vc.playIndex = (int)indexPath.row;
        [self.navigationController pushViewController:vc animated:YES];
    }
    [self.tableView reloadData];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section==0) {
        return 45;
    }
    [self.contentV.webV layoutIfNeeded];
    return 55+self.contentV.webV.height;
}

- (CourseDetailHeaderView *)headerV {
    if (_headerV==nil) {
        CourseDetailHeaderView *headerV = [[CourseDetailHeaderView alloc] init];
        [headerV.backBtn addTarget:self action:@selector(backClick) forControlEvents:UIControlEventTouchUpInside];
        [headerV.toolView.soundBtn addTarget:self action:@selector(soundPlayAction:) forControlEvents:UIControlEventTouchUpInside];
        [headerV.playBtn addTarget:self action:@selector(videoPlay) forControlEvents:UIControlEventTouchUpInside];
        [headerV.likeBtn addTarget:self action:@selector(likeClick:) forControlEvents:UIControlEventTouchUpInside];
        self.headerV = headerV;
    }
    return _headerV;
}

- (void)zf_playerOverAction {
    [self videoRecord];
    // 播放下一集
    if (self.playIndex==self.listArr.count-1) {
        [MBProgressHUD showError:@"已经是最后一集"];
        return;
    }
    self.playIndex++;
    if (self.soundView.hidden==NO) { // 音频
        [self soundPlay];
    } else {
        [self videoPlay];
    }
    [self.tableView reloadData];
}

- (CourseDetailContentCell *)contentV {
    if (_contentV==nil) {
        CourseDetailContentCell *cell = [CourseDetailContentCell cellWithTableView:self.tableView];
        self.contentV = cell;
    }
    return _contentV;
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context {
    if ([keyPath isEqualToString:@"contentSize"]) {
        CGSize size = [self.contentV.webV sizeThatFits:CGSizeZero];
        self.contentV.webV.sd_layout.heightIs(size.height);
        [self.tableView beginUpdates];
        [self.tableView endUpdates];
    }
}

- (UITableView *)tableView {
    if (_tableView==nil) {
        self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, -[UIView getStatusBarHeight], SCREEN_WIDTH, self.view.height+[UIView getStatusBarHeight]) style:UITableViewStyleGrouped];
        self.tableView.backgroundColor = [UIColor appBackGroundColor];
        self.tableView.delegate = self;
        self.tableView.dataSource = self;
        self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        self.tableView.showsVerticalScrollIndicator = NO;
        self.tableView.showsHorizontalScrollIndicator = NO;
    }
    return _tableView;
}

@end
