//
//  CourseDetailContentView.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/5.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "CourseDetailContentCell.h"

@interface CourseDetailContentCell()<UIWebViewDelegate>
@property (nonatomic, strong) UITableView *tableView;
@end

@implementation CourseDetailContentCell
- (instancetype)init
{
    self = [super init];
    if (self) {
        [self buildView];
    }
    return self;
}

+ (instancetype)cellWithTableView:(UITableView *)tableView
{
    NSString *cellID = @"CourseDetailContentCell";
    CourseDetailContentCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell == nil) {
        cell = [[CourseDetailContentCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
        cell.tableView = tableView;
    }
    
    return cell;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    [self buildView];
    return self;
}


- (void)buildView {
    self.backgroundColor = [UIColor whiteColor];
    
    UIView *sepV = [UIView new];
    sepV.backgroundColor = [UIColor appBackGroundColor];
    [self addSubview:sepV];
    
    UIView *titleV = [[UIView alloc] init];
    titleV.backgroundColor = [UIColor whiteColor];
    [self addSubview:titleV];
    
    UILabel *nameLb = [[UILabel alloc] init];
    nameLb.textColor = [UIColor appTextColor];
    nameLb.font = [UIFont systemFontOfSize:16 weight:400];
    nameLb.textAlignment = NSTextAlignmentLeft;
    [titleV addSubview:nameLb];
    nameLb.text = @"课程详情";
    
    [titleV addSeparateLine];
    
    UIWebView *webV = [[UIWebView alloc] init];
    webV.scrollView.bounces = NO;
    webV.allowsInlineMediaPlayback = YES;
    [self addSubview:webV];
    self.webV = webV;
    
    sepV.sd_layout
    .topSpaceToView(self, 0)
    .leftSpaceToView(self, 0)
    .rightSpaceToView(self, 0)
    .heightIs(10);
    
    titleV.sd_layout
    .topSpaceToView(sepV, 0)
    .leftSpaceToView(self, 0)
    .rightSpaceToView(self, 0)
    .heightIs(45);
    
    nameLb.sd_layout
    .centerYEqualToView(titleV)
    .leftSpaceToView(titleV, 15)
    .widthIs(100)
    .heightIs(9);
    
    webV.sd_layout
    .topSpaceToView(titleV, 10)
    .leftSpaceToView(self, 15)
    .rightSpaceToView(self, 15)
    .heightIs(1);
}

@end
