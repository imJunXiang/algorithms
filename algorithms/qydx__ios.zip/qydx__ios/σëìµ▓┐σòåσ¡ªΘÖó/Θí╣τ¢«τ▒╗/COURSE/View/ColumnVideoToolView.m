//
//  ColumnVideoToolView.m
//  前沿商学院
//
//  Created by 邓壮壮 on 2017/6/30.
//  Copyright © 2017年 edu268. All rights reserved.
//

#import "ColumnVideoToolView.h"

@implementation ColumnVideoToolView

- (instancetype)init {
    
    self = [super init];
    
    UIButton *moreBtn = [[UIButton alloc] init];
    [moreBtn addTarget:self action:@selector(moreClickAction) forControlEvents:UIControlEventTouchUpInside];
    [moreBtn setBackgroundImage:[UIImage imageNamed:@"videomore"] forState:UIControlStateNormal];
    [self addSubview:moreBtn];
    self.moreBtn = moreBtn;
    
    UIButton *shareBtn = [[UIButton alloc] init];
    [shareBtn setBackgroundImage:[UIImage imageNamed:@"fx"] forState:UIControlStateNormal];
    [self addSubview:shareBtn];
    self.shareBtn = shareBtn;
    
    UIButton *soundBtn = [[UIButton alloc] init];
    [soundBtn setBackgroundImage:[UIImage imageNamed:@"sound"] forState:UIControlStateNormal];
    [soundBtn setBackgroundImage:[UIImage imageNamed:@"音频不可点"] forState:UIControlStateSelected];
    soundBtn.selected = YES;
    [self addSubview:soundBtn];
    self.soundBtn = soundBtn;
    
    moreBtn.sd_layout
    .rightSpaceToView(self, 0)
    .topSpaceToView(self, 0)
    .widthIs(25)
    .heightIs(25);
    
    shareBtn.sd_layout
    .rightSpaceToView(moreBtn, 8)
    .topSpaceToView(self, 0)
    .widthIs(25)
    .heightIs(25);
    
    soundBtn.sd_layout
    .rightSpaceToView(shareBtn, 8)
    .topSpaceToView(self, 0)
    .widthIs(25)
    .heightIs(25);
    
    return self;
}

- (void)buildMaskView:(UIView *)videoView {
    
    UITapGestureRecognizer *tapGes = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(maskTapAction)];
    
    UIView *maskView = [[UIView alloc] init];
    maskView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.7];
    [videoView addSubview:maskView];
    maskView.hidden = YES;
    self.maskView = maskView;
    [maskView addGestureRecognizer:tapGes];
    
    UIButton *colBtn = [self buildButton:@"sc" title:@"收藏"];
    [colBtn setImage:[UIImage imageNamed:@"scxz"] forState:UIControlStateSelected];
    self.colBtn = colBtn;
    
    UIButton *comBtn = [self buildButton:@"消息" title:@"评论"];
    self.comBtn = comBtn;

    UIButton *downBtn = [self buildButton:@"下载" title:@"缓存课程"];
    downBtn.hidden = [UserInfoTool getUserFunction];
    self.downBtn = downBtn;
    
    maskView.sd_layout
    .topSpaceToView(videoView, 0)
    .leftSpaceToView(videoView, 0)
    .bottomSpaceToView(videoView, 0)
    .rightSpaceToView(videoView, 0);
    
    comBtn.sd_layout
    .centerXEqualToView(maskView)
    .centerYEqualToView(maskView)
    .widthIs(60)
    .heightIs(60);
    
    colBtn.sd_layout
    .leftSpaceToView(comBtn, 30)
    .centerYEqualToView(maskView)
    .widthIs(60)
    .heightIs(60);
    
    downBtn.sd_layout
    .rightSpaceToView(comBtn, 30)
    .centerYEqualToView(maskView)
    .widthIs(60)
    .heightIs(60);
    
    [colBtn setImagePosition:LXMImagePositionTop spacing:2];
    [downBtn setImagePosition:LXMImagePositionTop spacing:2];
    [comBtn setImagePosition:LXMImagePositionTop spacing:2];
    
}

- (UIButton *)buildButton:(NSString *)icon title:(NSString *)title {
    UIButton *button = [[UIButton alloc] init];
    [button setImage:[UIImage imageNamed:icon] forState:UIControlStateNormal];
    [button setTitle:title forState:UIControlStateNormal];
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:13];
    [self.maskView addSubview:button];
    return button;
}

- (void)moreClickAction {
    self.maskView.hidden = !self.maskView.hidden;
}

- (void)maskTapAction {
    self.maskView.hidden = !self.maskView.hidden;
}

@end
