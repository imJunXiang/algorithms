//
//  CourseDetailListView.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/5.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "CourseDetailListView.h"

@implementation CourseDetailListView

- (void)setModel:(NSDictionary *)model {
    _model = model;
    
    for (int i=0; i<14; i++) {
        UIButton *cellV = [self buildCell:nil];
        [self addSubview:cellV];
        
        cellV.sd_layout
        .topSpaceToView(self.tempV, 0)
        .leftSpaceToView(self, 0)
        .rightSpaceToView(self, 0)
        .heightIs(42);
        self.tempV = cellV;
        cellV.tag = i;
        [cellV addTarget:self action:@selector(cellClick:) forControlEvents:UIControlEventTouchUpInside];
    }
    [self setupAutoHeightWithBottomView:self.tempV bottomMargin:0];
}

- (void)cellClick:(UIButton *)button {
    if (self.cellClickBlock!=nil) {
        self.cellClickBlock(button.tag);
    }
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self buildView];
    }
    return self;
}

- (UIButton *)buildCell:(NSDictionary *)model {
    UIButton *backV = [[UIButton alloc] init];
    backV.backgroundColor = [UIColor whiteColor];
    
    UILabel *countLb = [[UILabel alloc] init];
    countLb.textColor = [UIColor appTextColor];
    countLb.font = [UIFont systemFontOfSize:14];
    countLb.textAlignment = NSTextAlignmentLeft;
    [backV addSubview:countLb];
    
    UILabel *nameLb = [[UILabel alloc] init];
    nameLb.textColor = [UIColor appTextColor];
    nameLb.font = [UIFont systemFontOfSize:14];
    nameLb.textAlignment = NSTextAlignmentLeft;
    [backV addSubview:nameLb];
    
    UIButton *bookBtn = [[UIButton alloc] init];
    [bookBtn setBackgroundImage:[UIImage imageNamed:@"备忘录拷贝6"] forState:UIControlStateNormal];
    [backV addSubview:bookBtn];
    
    UILabel *perLb = [[UILabel alloc] init];
    perLb.textColor = [UIColor whiteColor];
    perLb.font = [UIFont systemFontOfSize:10];
    perLb.textAlignment = NSTextAlignmentCenter;
    perLb.sd_cornerRadius = @(10);
    perLb.backgroundColor = [UIColor appBlueColor];
    [backV addSubview:perLb];
    
    countLb.sd_layout
    .centerYEqualToView(backV)
    .leftSpaceToView(backV, 15)
    .widthIs(16)
    .heightIs(11);
    
    perLb.sd_layout
    .centerYEqualToView(backV)
    .rightSpaceToView(backV, 15)
    .widthIs(47)
    .heightIs(20);
    
    bookBtn.sd_layout
    .centerYEqualToView(backV)
    .rightSpaceToView(perLb, 15)
    .widthIs(16)
    .heightIs(20);
    
    nameLb.sd_layout
    .centerYEqualToView(backV)
    .leftSpaceToView(countLb, 10)
    .rightSpaceToView(bookBtn, 10)
    .heightIs(14);
    
    nameLb.text = @"创业思考：长成参天大树的三大关键";
    countLb.text = @"01";
    perLb.text = @"99%";
    
    return backV;
}

- (void)buildView {
    UIView *titleV = [[UIView alloc] init];
    titleV.backgroundColor = [UIColor whiteColor];
    [self addSubview:titleV];
    self.tempV = titleV;
    
    UILabel *nameLb = [[UILabel alloc] init];
    nameLb.textColor = [UIColor appTextColor];
    nameLb.font = [UIFont systemFontOfSize:16 weight:400];
    nameLb.textAlignment = NSTextAlignmentLeft;
    [titleV addSubview:nameLb];
    nameLb.text = @"课程内容";
    
    [titleV addSeparateLine];
    
    titleV.sd_layout
    .topSpaceToView(self, 0)
    .leftSpaceToView(self, 0)
    .rightSpaceToView(self, 0)
    .heightIs(45);
    
    nameLb.sd_layout
    .centerYEqualToView(titleV)
    .leftSpaceToView(titleV, 15)
    .widthIs(100)
    .heightIs(9);
}

@end
