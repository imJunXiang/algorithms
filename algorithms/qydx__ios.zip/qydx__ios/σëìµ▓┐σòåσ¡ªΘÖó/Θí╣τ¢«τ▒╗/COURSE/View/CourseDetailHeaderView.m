//
//  CourseDetailHeaderView.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/5.
//  Copyright © 2018年 edu268. All rights reserved.
//

//
//  ColumnVideoView.m
//  前沿商学院
//
//  Created by 邓壮壮 on 2017/6/9.
//  Copyright © 2017年 edu268. All rights reserved.
//

#import "CourseDetailHeaderView.h"

@implementation CourseDetailHeaderView

- (void)setModel:(NSDictionary *)model {
    _model = model;
    [self.videoImg sd_setImageWithURL:[model[@"cover_image_url"] getURL]];
    self.nameLb.text = model[@"title"];
    self.teacherLb.text = [NSString stringWithFormat:@"%@ · %@", model[@"teacherNamePrefix"], model[@"teacherName"]];
    self.desLb.text = [NSString stringWithFormat:@"%@", model[@"teacherDescription"]];
    self.countLb.text = [NSString stringWithFormat:@"%ld", [model[@"add_view_count"] integerValue]+[model[@"page_view_count"] integerValue]];
    if ([[NSString stringWithObject:model[@"favoriteId"]] isEmptyString]) {
        self.likeBtn.selected = NO;
    } else {
        self.likeBtn.selected = YES;
    }
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self buildView];
    }
    return self;
}

- (void)buildView {
    self.backgroundColor = [UIColor whiteColor];
    UIImageView *videoImg = [[UIImageView alloc] init];
    videoImg.userInteractionEnabled = YES;
    [self addSubview:videoImg];
    self.videoImg = videoImg;
    
    UIView *maskView = [[UIView alloc] init];
    maskView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.3];
    [videoImg addSubview:maskView];
    
    UIButton *playBtn = [[UIButton alloc] init];
    [playBtn setBackgroundImage:[UIImage imageNamed:@"bf-btn"] forState:UIControlStateNormal];
    [videoImg addSubview:playBtn];
    playBtn.hidden = YES;
    self.playBtn = playBtn;
    
    UIButton *backBtn = [[UIButton alloc] init];
    [backBtn setBackgroundImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
    [videoImg addSubview:backBtn];
    self.backBtn = backBtn;
    
    ColumnVideoToolView *toolView = [[ColumnVideoToolView alloc] init];
    toolView.backgroundColor = [UIColor clearColor];
//    [videoImg addSubview:toolView];
    self.toolView = toolView;
    
    UIView *nameV = [[UIView alloc] init];
    nameV.backgroundColor = [UIColor whiteColor];
    [self addSubview:nameV];
    
    UILabel *nameLb = [[UILabel alloc] init];
    nameLb.textColor = [UIColor appTextColor];
    nameLb.font = [UIFont systemFontOfSize:16 weight:400];
    nameLb.textAlignment = NSTextAlignmentLeft;
    [nameV addSubview:nameLb];
    self.nameLb = nameLb;
    
    UILabel *countLb = [[UILabel alloc] init];
    countLb.textColor = [UIColor appLightTextColor];
    countLb.font = [UIFont systemFontOfSize:12];
    countLb.textAlignment = NSTextAlignmentRight;
    [nameV addSubview:countLb];
    self.countLb = countLb;
    
    UIButton *likeBtn = [[UIButton alloc] init];
    [likeBtn setImage:[UIImage imageNamed:@"爱心-2"] forState:UIControlStateNormal];
    [likeBtn setImage:[UIImage imageNamed:@"爱心-1"] forState:UIControlStateSelected];
    [nameV addSubview:likeBtn];
    self.likeBtn = likeBtn;
    
    [nameV addSeparateLine];
    
    UILabel *teacherLb = [[UILabel alloc] init];
    teacherLb.textColor = [UIColor appTextColor];
    teacherLb.font = [UIFont systemFontOfSize:14];
    teacherLb.textAlignment = NSTextAlignmentLeft;
    [self addSubview:teacherLb];
    self.teacherLb = teacherLb;
    
    UILabel *desLb = [[UILabel alloc] init];
    desLb.textColor = [UIColor appGrayTextColor];
    desLb.font = [UIFont systemFontOfSize:12];
    desLb.textAlignment = NSTextAlignmentLeft;
    desLb.numberOfLines = 0;
    [self addSubview:desLb];
    self.desLb = desLb;
    
    UIView *sepV = [UIView new];
    sepV.backgroundColor = [UIColor appBackGroundColor];
    [self addSubview:sepV];
    
    UIView *titleV = [[UIView alloc] init];
    titleV.backgroundColor = [UIColor whiteColor];
    [self addSubview:titleV];
    
    UILabel *titleLb = [[UILabel alloc] init];
    titleLb.textColor = [UIColor appTextColor];
    titleLb.font = [UIFont systemFontOfSize:16 weight:400];
    titleLb.textAlignment = NSTextAlignmentLeft;
    [titleV addSubview:titleLb];
    titleLb.text = @"课程内容";
    
    [titleV addSeparateLine];
    
    videoImg.sd_layout
    .leftSpaceToView(self, 0)
    .topSpaceToView(self, 0)
    .rightSpaceToView(self, 0)
    .heightIs(SCREEN_WIDTH*9/16);
    
    maskView.sd_layout
    .leftSpaceToView(videoImg, 0)
    .topSpaceToView(videoImg, 0)
    .rightSpaceToView(videoImg, 0)
    .bottomSpaceToView(videoImg, 0);
    
    playBtn.sd_layout
    .centerXEqualToView(videoImg)
    .topSpaceToView(videoImg, 75)
    .widthIs(60)
    .heightIs(60);
    
    backBtn.sd_layout
    .leftSpaceToView(videoImg, 10)
    .topSpaceToView(videoImg, [UIView getStatusBarHeight]+5)
    .widthIs(25)
    .heightIs(25);
    
    toolView.sd_layout
    .topSpaceToView(videoImg, [UIView getStatusBarHeight]+5)
    .widthIs(170)
    .rightSpaceToView(videoImg, 10)
    .heightIs(30);
    
    nameV.sd_layout
    .topSpaceToView(videoImg, 0)
    .leftSpaceToView(self, 0)
    .rightSpaceToView(self, 0)
    .heightIs(45);
    
    countLb.sd_layout
    .centerYEqualToView(nameV)
    .rightSpaceToView(nameV, 15)
    .heightIs(9);
    [countLb setSingleLineAutoResizeWithMaxWidth:120];
    
    likeBtn.sd_layout
    .centerYEqualToView(nameV)
    .rightSpaceToView(countLb, 10)
    .widthIs(16)
    .heightIs(14);
    
    nameLb.sd_layout
    .centerYEqualToView(nameV)
    .leftSpaceToView(nameV, 15)
    .rightSpaceToView(likeBtn, 10)
    .heightIs(16);
    
    teacherLb.sd_layout
    .topSpaceToView(nameV, 15)
    .leftSpaceToView(self, 15)
    .rightSpaceToView(self, 15)
    .heightIs(14);
    
    desLb.sd_layout
    .topSpaceToView(teacherLb, 15)
    .leftSpaceToView(self, 15)
    .rightSpaceToView(self, 15)
    .autoHeightRatio(0);
    
    sepV.sd_layout
    .topSpaceToView(desLb, 15)
    .leftSpaceToView(self, 0)
    .rightSpaceToView(self, 0)
    .heightIs(10);
    
    titleV.sd_layout
    .topSpaceToView(sepV, 0)
    .leftSpaceToView(self, 0)
    .rightSpaceToView(self, 0)
    .heightIs(45);
    
    titleLb.sd_layout
    .centerYEqualToView(titleV)
    .leftSpaceToView(titleV, 15)
    .widthIs(100)
    .heightIs(9);
    
    [self setupAutoHeightWithBottomView:titleV bottomMargin:0];
}

- (void)buildMaskView {
    [self.toolView buildMaskView:self];
}


@end

