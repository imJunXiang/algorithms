//
//  CourseDetailHeaderView.h
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/5.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomLabel.h"
#import "ColumnVideoToolView.h"

@interface CourseDetailHeaderView : UIView
@property (nonatomic, strong) UIImageView *videoImg;
@property (nonatomic, strong) UIButton *playBtn;
@property (nonatomic, strong) UIButton *backBtn;
@property (nonatomic, strong) UIView *maskView;
@property (nonatomic, strong) UILabel *nameLb;
@property (nonatomic, strong) UILabel *countLb;
@property (nonatomic, strong) UILabel *teacherLb;
@property (nonatomic, strong) UILabel *desLb;
@property (nonatomic, strong) UIButton *likeBtn;

@property (nonatomic, strong) ColumnVideoToolView *toolView;

@property (nonatomic, strong) NSDictionary *model;
@end
