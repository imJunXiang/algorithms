//
//  DiscoverIndexCell.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/6/29.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "CourseIndexCell.h"

@implementation CourseIndexCell

- (void)setModel:(NSDictionary *)model {
    _model = model;
    [self.iconImgV sd_setImageWithURL:[model[@"coverImageUrl"] getURL] placeholderImage:nil];
    self.nameLb.text = model[@"courseTitle"];
    self.desLb.text = model[@"courseSimpleDesc"];
    self.teacherLb.text = [NSString stringWithFormat:@"%@ · %@", model[@"teacherNamePrefix"], model[@"teacherName"]];
    
    if (model[@"sumPlayProgress"]!=nil && model[@"sumDuration"]!=nil) {
        float p = [model[@"sumPlayProgress"] floatValue];
        float d = [model[@"sumDuration"] floatValue];
        float result;
        if (d==0||p==0) {
            result = 0;
            self.progress.sd_layout.widthIs(16);
            self.proLb.text = @"";
        } else {
            result = p/d>1?1:p/d;
            self.progress.sd_layout.widthIs(result*160);
            self.progress.width = result*160;
            self.proLb.text = [NSString stringWithFormat:@"%.f%%", result*100];
        }
    } else {
        self.progress.sd_layout.widthIs(16);
        self.proLb.text = @"";
    }
    
    [self.progress updateLayout];
    self.gradientLayer.frame = self.progress.bounds;
}

+ (instancetype)cellWithTableView:(UITableView *)tableView
{
    NSString *cellID = @"CourseIndexCell";
    CourseIndexCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell == nil) {
        cell = [[CourseIndexCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
    }
    
    return cell;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    [self buildView];
    return self;
}

- (void)buildView {
    UIImageView *iconImgV = [[UIImageView alloc] init];
    iconImgV.sd_cornerRadius = @(2);
    [self addSubview:iconImgV];
    self.iconImgV = iconImgV;
    
    UILabel *nameLb = [[UILabel alloc] init];
    nameLb.textColor = [UIColor appTextColor];
    nameLb.font = [UIFont systemFontOfSize:16 weight:400];
    nameLb.textAlignment = NSTextAlignmentLeft;
    [self addSubview:nameLb];
    self.nameLb = nameLb;
    
    UILabel *desLb = [[UILabel alloc] init];
    desLb.textColor = [UIColor appGrayTextColor];
    desLb.font = [UIFont systemFontOfSize:12];
    desLb.textAlignment = NSTextAlignmentLeft;
    [self addSubview:desLb];
    self.desLb = desLb;
    
    UILabel *teacherLb = [[UILabel alloc] init];
    teacherLb.textColor = [UIColor appLightTextColor];
    teacherLb.font = [UIFont systemFontOfSize:12];
    teacherLb.textAlignment = NSTextAlignmentLeft;
    [self addSubview:teacherLb];
    self.teacherLb = teacherLb;
    
    UIView *proV = [[UIView alloc] init];
    proV.backgroundColor = [UIColor colorWithMacHexString:@"cfd7ff"];
    proV.sd_cornerRadius = @(8);
    [self addSubview:proV];
    self.proV = proV;
    
    UIView *progress = [[UIView alloc] initWithFrame:CGRectMake(132, 220, 78, 12)];
    progress.sd_cornerRadius = @(8);
    [proV addSubview:progress];
    self.progress = progress;
    
    //Gradient
    CAGradientLayer *gradientLayer = [[CAGradientLayer alloc] init];
    gradientLayer.colors = @[
                             (id)[UIColor colorWithRed:93.0f/255.0f green:101.0f/255.0f blue:255.0f/255.0f alpha:1.0f].CGColor,
                             (id)[UIColor colorWithRed:108.0f/255.0f green:201.0f/255.0f blue:255.0f/255.0f alpha:1.0f].CGColor];
    gradientLayer.locations = @[@0, @1];
    [gradientLayer setStartPoint:CGPointMake(0, 1)];
    [gradientLayer setEndPoint:CGPointMake(1, 1)];
    [progress.layer addSublayer:gradientLayer];;
    self.gradientLayer = gradientLayer;
    
    UILabel *proLb = [[UILabel alloc] init];
    proLb.textColor = [UIColor whiteColor];
    proLb.font = [UIFont systemFontOfSize:10];
    proLb.textAlignment = NSTextAlignmentCenter;
    [progress addSubview:proLb];
    self.proLb = proLb;
    
    iconImgV.sd_layout
    .centerYEqualToView(self)
    .leftSpaceToView(self, 15)
    .widthIs(100)
    .heightIs(100);
    
    nameLb.sd_layout
    .topEqualToView(iconImgV)
    .leftSpaceToView(iconImgV, 15)
    .rightSpaceToView(self, 15)
    .heightIs(16);
    
    desLb.sd_layout
    .topSpaceToView(nameLb, 15)
    .leftSpaceToView(iconImgV, 15)
    .rightSpaceToView(self, 15)
    .heightIs(14);
    
    teacherLb.sd_layout
    .topSpaceToView(desLb, 15)
    .leftSpaceToView(iconImgV, 15)
    .rightSpaceToView(self, 15)
    .heightIs(13);
    
    proV.sd_layout
    .bottomEqualToView(iconImgV)
    .leftSpaceToView(iconImgV, 15)
    .widthIs(160)
    .heightIs(16);
    
    progress.sd_layout
    .topSpaceToView(proV, 0)
    .leftSpaceToView(proV, 0)
    .bottomSpaceToView(proV, 0)
    .widthIs(78);
    
    proLb.sd_layout
    .centerYEqualToView(progress)
    .centerXEqualToView(progress)
    .heightIs(15);
    [proLb setSingleLineAutoResizeWithMaxWidth:150];
    
    [self addSeparateLineMargin];
}

@end
