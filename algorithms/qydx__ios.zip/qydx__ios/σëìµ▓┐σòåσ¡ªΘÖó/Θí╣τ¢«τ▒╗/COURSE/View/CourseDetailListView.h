//
//  CourseDetailListView.h
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/5.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CourseDetailListView : UIView
@property (nonatomic, strong) UIView *tempV;
@property (nonatomic, strong) NSDictionary *model;
@property (nonatomic, copy) void (^cellClickBlock) (NSInteger index);
@end
