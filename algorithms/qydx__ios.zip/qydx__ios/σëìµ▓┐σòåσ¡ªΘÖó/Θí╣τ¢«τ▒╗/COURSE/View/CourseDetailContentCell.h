//
//  CourseDetailContentView.h
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/5.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CourseDetailContentCell : UITableViewCell
@property (nonatomic, strong) NSDictionary *model;
@property (nonatomic, strong)  UIWebView *webV;
+ (instancetype)cellWithTableView:(UITableView *)tableView;
@end
