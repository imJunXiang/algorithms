//
//  ColumnVideoToolView.h
//  前沿商学院
//
//  Created by 邓壮壮 on 2017/6/30.
//  Copyright © 2017年 edu268. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ColumnVideoToolView : UIView
@property (nonatomic, strong) UIButton *shareBtn;
@property (nonatomic, strong) UIButton *moreBtn;
@property (nonatomic, strong) UIButton *colBtn;
@property (nonatomic, strong) UIButton *comBtn;
@property (nonatomic, strong) UIButton *downBtn;
@property (nonatomic, strong) UIButton *soundBtn;
@property (nonatomic, strong) UIView *maskView;

- (void)buildMaskView:(UIView *)videoView;
- (void)moreClickAction;
@end
