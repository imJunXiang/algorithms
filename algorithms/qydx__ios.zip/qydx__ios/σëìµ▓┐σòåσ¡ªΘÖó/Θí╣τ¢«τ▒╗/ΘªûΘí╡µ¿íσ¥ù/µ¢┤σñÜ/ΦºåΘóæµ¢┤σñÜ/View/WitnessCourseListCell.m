//
//  CourseBuyMoreCell.m
//  前沿商学院
//
//  Created by 邓壮壮 on 2017/3/23.
//  Copyright © 2017年 edu268. All rights reserved.
//

#import "CourseBuyMoreCell.h"

@interface CourseBuyMoreCell ()
@property (weak, nonatomic) IBOutlet UIImageView *timeIcon;

@end

@implementation CourseBuyMoreCell

- (void)awakeFromNib
{
    [super awakeFromNib];
    [self addSeparateLine];
    
    UILabel *advanceLB = [[UILabel alloc] init];
    advanceLB.textColor = [UIColor whiteColor];
    advanceLB.font = [UIFont systemFontOfSize:12];
    advanceLB.textAlignment = NSTextAlignmentCenter;
    advanceLB.text = @"预售课程";
    advanceLB.backgroundColor = [UIColor colorWithWhite:0 alpha:0.3];
    [self.myImageView addSubview:advanceLB];
    self.advanceLB = advanceLB;
    
    advanceLB.sd_layout
    .leftSpaceToView(self.myImageView, 0)
    .bottomSpaceToView(self.myImageView, 0)
    .widthIs(70)
    .heightIs(20);
}

// 创建cell
+ (instancetype)cellWithTableView:(UITableView *)tableView
{
    NSString *cellID = @"CourseBuyMoreCell";
    CourseBuyMoreCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell == nil) {
        [tableView registerNib:[UINib nibWithNibName:cellID bundle:nil] forCellReuseIdentifier:cellID];
        cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    }
    
    return cell;
}

- (void)setModel:(NSDictionary *)model {
    _model = model;
    
    [self.myImageView sd_setImageWithURL:[NSURL URLWithString:[UserInfoTool getUserIcon:model[@"mobileLogo"]]] placeholderImage:[UIImage imageNamed:@"占位图"]];
    self.myTitle.text = model[@"name"];
    
    self.priceLB.text = [NSString stringWithFormat:@"￥%@", model[@"currentprice"]];
    self.teacherLB.text = model[@"teacherList"][0][@"name"];
    self.courseCountLB.text = [NSString stringWithFormat:@"%@集", model[@"kpointNum"]];
    
    if ([model[@"saleType"] isEqualToString:@"PRESALE"]) {
        self.advanceLB.hidden = NO;
    } else {
        self.advanceLB.hidden = YES;
    }
    
    self.timeLB.text = [NSDate dateWithChineseMdHm:model[@"addtime"]];
    
    if (IAPBOOL) {
        self.advanceLB.hidden = YES;
        self.priceLB.hidden = YES;
    }
}

@end
