//
//  CourseBuyMoreCell.h
//  前沿商学院
//
//  Created by 邓壮壮 on 2017/3/23.
//  Copyright © 2017年 edu268. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CourseBuyMoreCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *myImageView;

@property (weak, nonatomic) IBOutlet UILabel *myTitle;

@property (weak, nonatomic) IBOutlet UILabel *timeLB;
@property (weak, nonatomic) IBOutlet UILabel *priceLB;
@property (weak, nonatomic) IBOutlet UILabel *teacherLB;
@property (weak, nonatomic) IBOutlet UILabel *courseCountLB;
@property (nonatomic, strong) UILabel *advanceLB;

// 创建cell
+ (instancetype)cellWithTableView:(UITableView *)tableView;
@property (nonatomic, assign) NSInteger type;
@property (nonatomic, strong) NSDictionary *model;
@end
