//
//  BaseViewController.m
//  前沿商学院
//
//  Created by 邓壮壮 on 2016/11/16.
//  Copyright © 2016年 edu268. All rights reserved.
//

#import "BaseViewController.h"

@interface BaseViewController ()

@end

@implementation BaseViewController

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.edgesForExtendedLayout = UIRectEdgeNone;
    self.view.backgroundColor = [UIColor whiteColor];
    NSLog(@"当前控制器：%@", NSStringFromClass([self class]));
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
}

- (void)emptyReload:(NSArray *)modelArr {
    if (modelArr==nil || modelArr.count<=0) {
        self.emptyV.hidden = NO;
    } else {
        self.emptyV.hidden = YES;
    }
}

- (void)buildEmptyView:(CGFloat)y title:(NSString *)title {
    UIView *backV = [[UIView alloc] initWithFrame:CGRectMake(0, y, self.view.width, self.view.height-y)];
    backV.backgroundColor = [UIColor clearColor];
    backV.hidden = YES;
    [self.view addSubview:backV];
    self.emptyV = backV;
    
    UIImageView *iconImgV = [[UIImageView alloc] init];
    iconImgV.image = [UIImage imageNamed:@"empty"];
    [backV addSubview:iconImgV];
    
    UILabel *nameLb = [[UILabel alloc] init];
    nameLb.textColor = [UIColor appTextColor];
    nameLb.font = [UIFont systemFontOfSize:15 weight:400];
    nameLb.textAlignment = NSTextAlignmentCenter;
    [backV addSubview:nameLb];
    if (title==nil) {
        title = @"内容被抓走了~";
    }
    nameLb.text = title;
    
    iconImgV.sd_layout
    .topSpaceToView(backV, 50)
    .centerXEqualToView(backV)
    .widthIs(300)
    .heightIs(240);
    
    nameLb.sd_layout
    .topSpaceToView(iconImgV, 20)
    .leftSpaceToView(backV, 20)
    .rightSpaceToView(backV, 20)
    .heightIs(20);
}


@end
