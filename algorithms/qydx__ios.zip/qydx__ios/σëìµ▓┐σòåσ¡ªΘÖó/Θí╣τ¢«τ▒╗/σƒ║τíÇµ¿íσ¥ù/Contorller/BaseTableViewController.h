//
//  BaseTableViewController.h
//  前沿商学院
//
//  Created by 邓壮壮 on 2016/11/22.
//  Copyright © 2016年 edu268. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseTableViewController : BaseViewController <UITableViewDelegate, UITableViewDataSource, DZNEmptyDataSetSource, DZNEmptyDataSetDelegate>
@property (nonatomic, strong) UITableView *tableView;

- (void)reloadTableView;
@end
