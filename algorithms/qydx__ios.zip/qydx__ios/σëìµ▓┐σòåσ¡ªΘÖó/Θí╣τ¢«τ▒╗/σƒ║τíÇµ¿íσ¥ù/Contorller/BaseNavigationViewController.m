//
//  HomeNavViewController.m
//  和益管家
//
//  Created by sks on 16/8/23.
//  Copyright © 2016年 Silence. All rights reserved.
//

#import "BaseNavigationViewController.h"

@interface BaseNavigationViewController ()<UIGestureRecognizerDelegate>

@end

@implementation BaseNavigationViewController

- (UIButton *)backBtn {
    if (_backBtn == nil) {
        UIButton* backButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [backButton setImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
        backButton.titleLabel.hidden = YES;
        [backButton addTarget:self action:@selector(backBtnClick) forControlEvents:UIControlEventTouchUpInside];
        backButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        backButton.contentEdgeInsets = UIEdgeInsetsMake(0, -10, 0, 0);
        CGFloat btnW = SCREEN_WIDTH > 375 ? 50 : 44;
        backButton.frame = CGRectMake(0, 0, btnW, 40);
        _backBtn = backButton;
    }
    return _backBtn;
}

- (void)backBtnClick {
    [self popViewControllerAnimated:YES];
}

- (instancetype)initWithRootViewController:(UIViewController *)rootViewController {
    self = [super initWithRootViewController:rootViewController];
    if (self) {
        self.navigationBar.translucent = NO;
        // 设置导航栏颜色
        [self.navigationBar setShadowImage:[self imageWithColor:[UIColor clearColor]]];
        self.navigationBar.barTintColor = [UIColor whiteColor];
        self.navigationBar.tintColor = [UIColor appTextColor];
        self.interactivePopGestureRecognizer.delegate = self;
        
        // 普通状态
        UIBarButtonItem *item = [UIBarButtonItem appearance];
        
        NSMutableDictionary *textAttrs = [NSMutableDictionary dictionary];
        //    textAttrs[NSForegroundColorAttributeName] = [UIColor whiteColor];
        textAttrs[NSFontAttributeName] = [UIFont systemFontOfSize:14];
        
        [item setTitleTextAttributes:textAttrs forState:UIControlStateNormal];
        
        // 设置不可用状态
        NSMutableDictionary *disableTextAttrs = [NSMutableDictionary dictionary];
        disableTextAttrs[NSForegroundColorAttributeName] = [UIColor grayColor];
        disableTextAttrs[NSFontAttributeName] = [UIFont systemFontOfSize:14];
        
        [item setTitleTextAttributes:disableTextAttrs forState:UIControlStateDisabled];
        
        // 设置导航栏标题为白色
        NSShadow *shadow = [[NSShadow alloc] init];
        shadow.shadowColor = [UIColor whiteColor];
        shadow.shadowOffset = CGSizeMake(0, 0);
        [self.navigationBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor appTextColor], NSForegroundColorAttributeName, shadow,NSShadowAttributeName, [UIFont systemFontOfSize:18], NSFontAttributeName, nil]];
        
    }
    return self;
}

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated {
    if (self.childViewControllers.count>0) {
        viewController.hidesBottomBarWhenPushed = YES;
    }
    [super pushViewController:viewController animated:animated];
}

- (UIViewController *)popViewControllerAnimated:(BOOL)animated {
    [MBProgressHUD hideHUD];
    return [super popViewControllerAnimated:animated];
}

- (void)dismissViewControllerAnimated:(BOOL)flag completion:(void (^)(void))completion {
    [super dismissViewControllerAnimated:flag completion:completion];
    [MBProgressHUD hideHUD];
    
}

- (UIStatusBarStyle)preferredStatusBarStyle {
    return UIStatusBarStyleLightContent;
}

- (UIImage *)imageWithColor:(UIColor *)color {
    
    CGRect rect = CGRectMake(0, 0, 1, 1);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

@end

