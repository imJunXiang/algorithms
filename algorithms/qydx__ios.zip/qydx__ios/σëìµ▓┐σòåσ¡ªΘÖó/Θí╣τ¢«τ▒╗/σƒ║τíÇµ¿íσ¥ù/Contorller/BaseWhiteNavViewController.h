//
//  BaseWhiteNavViewController.h
//  前沿商学院
//
//  Created by 邓壮壮 on 2016/11/16.
//  Copyright © 2016年 edu268. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseWhiteNavViewController : UINavigationController
@property (nonatomic, strong) UIButton *backBtn;
@end
