//
//  HomeNavViewController.h
//  和益管家
//
//  Created by sks on 16/8/23.
//  Copyright © 2016年 Silence. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseNavigationViewController : UINavigationController
@property (nonatomic, strong) UIButton *backBtn;
@end
