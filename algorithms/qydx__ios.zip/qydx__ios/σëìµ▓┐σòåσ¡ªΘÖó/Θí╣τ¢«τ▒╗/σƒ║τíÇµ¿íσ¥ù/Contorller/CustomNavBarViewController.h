//
//  CustomNavBarViewController.h
//  前沿商学院
//
//  Created by MisterDeng on 2017/11/27.
//  Copyright © 2017年 edu268. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomNavBarViewController : UIViewController
@property (nonatomic, strong) WRCustomNavigationBar *customNavBar;
@end
