//
//  BLWelcomeViewController.m
//  268EDU_Demo
//
//  Created by yzla50010 on 16/3/1.
//  Copyright © 2016年 edu268. All rights reserved.
//

#import "WelcomeViewController.h"
#import "BLMainViewController.h"
#import "DHGuidePageHUD.h"
#import "DHGifImageOperation.h"

@interface WelcomeViewController () <UIScrollViewDelegate>
@property (nonatomic, strong) NSArray                 *imageArray;
@property (nonatomic, strong) UIPageControl           *imagePageControl;
@property (nonatomic, assign) NSInteger               slideIntoNumber;
@property (nonatomic, strong) UIImageView *lastImgView;
@end

@implementation WelcomeViewController

#pragma mark - 设置APP静态图片引导页

- (void)viewDidLoad
{
    [super viewDidLoad];
    NSArray *imageNameArray = @[@"welcome1",@"welcome2",@"welcome3"];
    self.imageArray = imageNameArray;
    // 设置引导视图的scrollview
    UIScrollView *guidePageView = [[UIScrollView alloc]initWithFrame:self.view.frame];
    [guidePageView setBackgroundColor:[UIColor lightGrayColor]];
    [guidePageView setContentSize:CGSizeMake(SCREEN_WIDTH*imageNameArray.count, SCREEN_HEIGTH)];
    [guidePageView setBounces:NO];
    [guidePageView setPagingEnabled:YES];
    [guidePageView setShowsHorizontalScrollIndicator:NO];
    [guidePageView setDelegate:self];
    [self.view addSubview:guidePageView];
    
    // 添加在引导视图上的多张引导图片
    for (int i=0; i<imageNameArray.count; i++) {
        UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(SCREEN_WIDTH*i, 0, SCREEN_WIDTH, SCREEN_HEIGTH)];
        if ([[DHGifImageOperation dh_contentTypeForImageData:[NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:imageNameArray[i] ofType:nil]]] isEqualToString:@"gif"]) {
            NSData *localData = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:imageNameArray[i] ofType:nil]];
            imageView = (UIImageView *)[[DHGifImageOperation alloc] initWithFrame:imageView.frame gifImageData:localData];
            [guidePageView addSubview:imageView];
        } else {
            imageView.image = [UIImage imageNamed:imageNameArray[i]];
            [guidePageView addSubview:imageView];
        }
        
        // 设置在最后一张图片上显示进入体验按钮
        if (i == imageNameArray.count-1) {
            [imageView setUserInteractionEnabled:YES];
            UIButton *startButton = [[UIButton alloc]initWithFrame:CGRectMake(0, SCREEN_HEIGTH-90, 150, 40)];
            startButton.centerX = SCREEN_WIDTH/2;
            [startButton setTitleColor:[UIColor colorWithRed:164/255.0 green:201/255.0 blue:67/255.0 alpha:1.0] forState:UIControlStateNormal];
            [startButton.titleLabel setFont:[UIFont systemFontOfSize:21]];
            [startButton addTarget:self action:@selector(startClick) forControlEvents:UIControlEventTouchUpInside];
            [imageView addSubview:startButton];
        }
    }
    
    // 设置引导页上的页面控制器
//    self.imagePageControl = [[UIPageControl alloc]initWithFrame:CGRectMake(SCREEN_WIDTH*0.0, SCREEN_HEIGTH*0.9, SCREEN_WIDTH*1.0, SCREEN_HEIGTH*0.1)];
//    self.imagePageControl.currentPage = 0;
//    self.imagePageControl.numberOfPages = imageNameArray.count;
//    self.imagePageControl.pageIndicatorTintColor = [UIColor grayColor];
//    self.imagePageControl.currentPageIndicatorTintColor = [UIColor whiteColor];
//    [self.view addSubview:self.imagePageControl];
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollview {
    int page = scrollview.contentOffset.x / scrollview.frame.size.width;
    [self.imagePageControl setCurrentPage:page];
    if (self.imageArray && page < self.imageArray.count-1) {
        self.slideIntoNumber = 1;
    }
    if (self.imageArray && page == self.imageArray.count-1) {
        UISwipeGestureRecognizer *swipeGestureRecognizer = [[UISwipeGestureRecognizer alloc] initWithTarget:nil action:nil];
        if (swipeGestureRecognizer.direction == UISwipeGestureRecognizerDirectionRight){
            self.slideIntoNumber++;
            if (self.slideIntoNumber == 3) {
                [self startClick];
            }
        }
    }
}

- (void)startClick
{
    [UIView animateWithDuration:3 animations:^{
        BLMainViewController *mainVC = [[BLMainViewController alloc] init];
        UIWindow *window = [UIApplication sharedApplication].keyWindow;
        window.rootViewController = mainVC;
        [mainVC.view addSubview:self.lastImgView];
        self.lastImgView.alpha = 0.0;
    } completion:^(BOOL finished) {
        
    }];
}

@end
