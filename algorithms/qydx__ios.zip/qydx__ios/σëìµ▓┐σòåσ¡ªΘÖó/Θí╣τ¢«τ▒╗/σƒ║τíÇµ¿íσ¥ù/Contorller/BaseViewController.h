//
//  BaseViewController.h
//  前沿商学院
//
//  Created by 邓壮壮 on 2016/11/16.
//  Copyright © 2016年 edu268. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WRCustomNavigationBar.h"

@interface BaseViewController : UIViewController
@property (nonatomic, strong) UIView *emptyV;
- (void)buildEmptyView:(CGFloat)y title:(NSString *)title;
- (void)emptyReload:(NSArray *)modelArr;
@end
