//
//  BLMainViewController.m
//  Sina_Microblog
//
//  Created by yzla50010 on 16/2/21.
//  Copyright © 2016年 yzla50010. All rights reserved.
//

#import "BLMainViewController.h"
#import "BaseWhiteNavViewController.h"
#import "BLTabBar.h"
#import "AppDelegate.h"
#import "HomeIndexViewController.h"
#import "CourseIndexViewController.h"
#import "DiscoverIndexViewController.h"
#import "MineIndexViewController.h"
@interface BLMainViewController ()<UITabBarControllerDelegate, UITabBarDelegate, BLTabBarDelegate, UIWebViewDelegate, UIAlertViewDelegate>
@property (nonatomic, strong) UIView *aler_window;
@property (nonatomic, strong) UIView *alerView;
@property (nonatomic, strong) AFHTTPSessionManager *manager;

@end

@implementation BLMainViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.delegate = self;
    self.tabBar.translucent = YES;
    self.tabBar.backgroundColor = [UIColor whiteColor];

    // 1.初始化子控制器
    HomeIndexViewController *home = [[HomeIndexViewController alloc] init];
    [self addChildVC:home title:@"首页" image:@"首页未选中" selectedImage:@"首页"];
    
    CourseIndexViewController *course = [[CourseIndexViewController alloc] init];
    [self addChildVC:course title:@"课程" image:@"课程未选中" selectedImage:@"课程"];
    
    DiscoverIndexViewController *discover = [[DiscoverIndexViewController alloc] init];
    [self addChildVC:discover title:@"发现" image:@"发现未选中" selectedImage:@"发现"];
    
    MineIndexViewController *mine = [[MineIndexViewController alloc] init];
    [self addChildVC:mine title:@"我的" image:@"我的未选中" selectedImage:@"我的"];
}

- (void)addChildVC:(UIViewController *)viewController title:(NSString *)title image:(NSString *)image selectedImage:(NSString *)selectedImage
{

    viewController.title = title;
    // 设置子控制器的图片
    viewController.tabBarItem.image = [UIImage imageNamed:image];
    viewController.tabBarItem.selectedImage = [[UIImage imageNamed:selectedImage] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    //设置文字样式
    NSMutableDictionary *textAttrs = [NSMutableDictionary dictionary];
    textAttrs[NSForegroundColorAttributeName] = [UIColor appLightTextColor];
    
    NSMutableDictionary *selectTextAttrs = [NSMutableDictionary dictionary];
    selectTextAttrs[NSForegroundColorAttributeName] = [UIColor appTextColor];
    
    [viewController.tabBarItem setTitleTextAttributes:textAttrs forState:UIControlStateNormal];
    [viewController.tabBarItem setTitleTextAttributes:selectTextAttrs forState:UIControlStateSelected];
    
    BaseNavigationViewController *mainNavVC = [[BaseNavigationViewController alloc] initWithRootViewController:viewController];
    
    [self addChildViewController:mainNavVC];
}

- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController {
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    appDelegate.currentNavIndex  = tabBarController.selectedIndex;
}

@end
