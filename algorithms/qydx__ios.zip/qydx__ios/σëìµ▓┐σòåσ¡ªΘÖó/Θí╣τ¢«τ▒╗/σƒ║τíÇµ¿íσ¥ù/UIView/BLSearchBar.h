//
//  BLSearchBar.h
//  Sina_Microblog
//
//  Created by yzla50010 on 16/2/22.
//  Copyright © 2016年 yzla50010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BLSearchBar : UITextField

+ (instancetype)searchBar;







@end
