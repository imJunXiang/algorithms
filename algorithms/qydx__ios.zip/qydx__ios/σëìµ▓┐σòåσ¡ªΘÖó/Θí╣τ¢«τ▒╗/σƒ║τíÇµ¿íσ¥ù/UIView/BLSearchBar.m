//
//  BLSearchBar.m
//  Sina_Microblog
//
//  Created by yzla50010 on 16/2/22.
//  Copyright © 2016年 yzla50010. All rights reserved.
//

#import "BLSearchBar.h"

@implementation BLSearchBar
//系统搜索框有很多限制，自定义
//    UISearchBar *searchBar = [[UISearchBar alloc] init];
//    searchBar.height = 30;
//    [searchBar setScopeBarBackgroundImage:[UIImage imageNamed:@"searchbar_textfield_background"]];
//    searchBar.searchBarStyle = UISearchBarStyleProminent;
//     self.navigationItem.titleView = searchBar;

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.font = [UIFont systemFontOfSize:15];
        self.placeholder = @"请输入内容";
        [self setBackground:[UIImage imageNamed:@"searchbar_textfield_background"]];
                
        UIImageView *searchImage = [[UIImageView alloc] init];
        searchImage.image = [UIImage imageNamed:@"searchbar_textfield_search_icon"];
        searchImage.width = 30;
        searchImage.height = 30;
        searchImage.contentMode = UIViewContentModeCenter;
        self.leftView = searchImage;
        self.leftViewMode = UITextFieldViewModeAlways;
    }
    return self;
}


+ (instancetype)searchBar
{
    return [[self alloc] init];
}


@end
