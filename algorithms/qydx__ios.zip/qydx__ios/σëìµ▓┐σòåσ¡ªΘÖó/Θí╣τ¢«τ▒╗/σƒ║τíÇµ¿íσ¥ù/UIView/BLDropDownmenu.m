//
//  BLDropDownmenu.m
//  Sina_Microblog
//
//  Created by yzla50010 on 16/2/23.
//  Copyright © 2016年 yzla50010. All rights reserved.
//

#import "BLDropDownmenu.h"
@interface BLDropDownmenu()

/** 将来用来显示具体内容的容器 即为窗口视图的背景图片 */
@property (nonatomic, weak) UIImageView *containerView;

@end

@implementation BLDropDownmenu

- (UIImageView *)containerView
{
    if (!_containerView)
    {
        UIImageView *containerView = [[UIImageView alloc]init];
        containerView.userInteractionEnabled = YES;//开启imageView的交互功能
        containerView.image = [UIImage imageNamed:@"矩形-30"];
        [self addSubview:containerView];
        self.containerView = containerView;//使self.containerView拥有 containerView, 不让弱引用立即销毁
    }
    return _containerView;
}


- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.backgroundColor = [UIColor clearColor];//把控件设置为透明色
    }
    return self;
}



+ (instancetype)menu
{
    return [[self alloc] init];
}

/*  * 重写内容控件 */
- (void)setContent:(UIView *)content
{
    _content = content;
    
    //设置控件在窗口中的坐标
    content.x = 10;//内容距左10；
    content.y = 15;//距上15;
    
    //根据内容设置 窗口背景图片的尺寸
    self.containerView.height = CGRectGetMaxY(content.frame) +11;//高:内容的getMaxY +11
    self.containerView.width = CGRectGetMaxX(content.frame) + 10;//宽:内容的getMaxX +10
    
    //把内容加到窗口背景图片中
    [self.containerView addSubview:content];
}

/**  * 重写内容为控制器的内容的setter方法 */
- (void)setContentController:(UIViewController *)contentController
{
    _contentController = contentController;
    
    //在窗口中添加控制器
    self.content = contentController.view;
}

/**  * 显示窗口 */
- (void)showFrom:(UIView *)from
{
    // 1. 获取最上面的窗口
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
  
    // 2. 把本view类加到窗口中
    [window addSubview:self];
    
    // 3. 设置本类view的尺寸,窗口设置多大,self 就多大
    self.frame = window.frame;
    
    // 4. 设置窗口的位置坐标， 默认情况下，frame 是以父控件左上角为坐标原点（0，0）
    /*
     * - (CGRect)convertRect:(CGRect)rect toView:(nullable UIView *)view;
     控件以原来的坐标, 转换到 以 view 的左顶点为 坐标原点的负坐标;
     用view 的坐标 - 控件 的坐标  宽高不变
     
     
     */

    CGRect newFrame = [from convertRect:from.bounds toView:window];
    
    // 或 两者是一样的，都是为了获取 控件from 在window 上的坐标
    // CGRect newFrame = [from.superview convertRect:from.frame toView:window];
  
    self.containerView.centerX = CGRectGetMidX(newFrame);
  
    self.containerView.y = CGRectGetMaxY(from.frame)+10;
}

/**  * 销毁 */
- (void)dismiss
{
    [self removeFromSuperview];
}


- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self dismiss];
}






@end
