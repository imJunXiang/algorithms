
#import "UIWindow+Extension.h"
#import "BLMainViewController.h"
#import "WelcomeViewController.h"
#import "LoginIndexViewController.h"

@implementation UIWindow (Extension)



- (void)switchRootViewController
{
    if ([UserInfoTool isLogin]) {
        BLMainViewController *vc = [[BLMainViewController alloc] init];
        self.rootViewController = vc;
    } else {
        LoginIndexViewController *vc = [[LoginIndexViewController alloc] init];
        self.rootViewController = [[BaseNavigationViewController alloc] initWithRootViewController:vc];
    }
}

+ (BOOL)updateBool
{
    NSString *oldVer = [USER_DEF stringForKey:USER_VERSION];
    NSString *nowVer = [NSString getAppVersion];
    [USER_DEF setObject:nowVer forKey:USER_VERSION];
    [USER_DEF synchronize];
    return !([oldVer isEqualToString:nowVer]);
}

+ (BOOL)updateBoolForGuide
{
    NSString *oldVer = [USER_DEF stringForKey:@"guidever"];
    NSString *nowVer = [NSString getAppVersion];
    [USER_DEF setObject:nowVer forKey:@"guidever"];
    [USER_DEF synchronize];
    return !([oldVer isEqualToString:nowVer]);
}

@end
