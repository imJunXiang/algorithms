//
//  BLShowLabelWithoutData.h
//  268EDU_Demo
//
//  Created by yzla50010 on 16/3/23.
//  Copyright © 2016年 edu268. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BLShowLabelWithoutData : UIView
/** 显示 */
- (void)showMessage:(NSString *)message Image:(NSString *)image isImage:(BOOL)isImage;
/** 销毁 */
- (void)dismiss;

+ (instancetype)showLabel;
@end
