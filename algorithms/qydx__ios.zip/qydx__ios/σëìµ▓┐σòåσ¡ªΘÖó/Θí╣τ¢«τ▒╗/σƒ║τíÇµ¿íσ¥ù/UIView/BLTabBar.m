//
//  BLTabBar.m
//  Sina_Microblog
//
//  Created by yzla50010 on 16/2/23.
//  Copyright © 2016年 yzla50010. All rights reserved.
//TabBar

#import "BLTabBar.h"

//定义按钮数
#define btnCount 5


@interface BLTabBar()

@property (nonatomic, weak) UIButton *midPlusBtn;


@end
@implementation BLTabBar

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        UIButton *midPlusBtn = [[UIButton alloc] init];
        [midPlusBtn setBackgroundImage:[UIImage imageNamed:@"tabbar_compose_button"] forState:UIControlStateNormal];
        [midPlusBtn setBackgroundImage:[UIImage imageNamed:@"tabbar_compose_button_highlighted"] forState:UIControlStateHighlighted];
        [midPlusBtn setImage:[UIImage imageNamed:@"tabbar_compose_icon_add"] forState:UIControlStateNormal];
        [midPlusBtn setImage:[UIImage imageNamed:@"tabbar_compose_icon_add_highlighted"] forState:UIControlStateHighlighted];
        midPlusBtn.size = midPlusBtn.currentBackgroundImage.size;
      
        [midPlusBtn addTarget:self action:@selector(midPlusBtnClick) forControlEvents:UIControlEventTouchUpInside];
       
        [self addSubview:midPlusBtn];
        self.midPlusBtn = midPlusBtn;
    }
    return self;
}

/**
 *  加号按钮点击
 */
- (void)midPlusBtnClick
{
    // 通知代理  respondsToSelector:判断这个类是否有@SEL 这个方法
    if ([self.Delegate respondsToSelector:@selector(BLTabBarBtnClick:)])
    {
        [self.Delegate BLTabBarBtnClick:self];
    }
}


- (void)layoutSubviews
{
    [super layoutSubviews];//必须先调用父类的布局，才能对自定义控件进行操控
    
    //自定义按钮的坐标
    self.midPlusBtn.centerX = self.width / 2.0;
    self.midPlusBtn.centerY = self.height / 2.0;
    
    //把工具栏等分
    CGFloat tabBarBtnWidth = self.width / btnCount;
    CGFloat tabBarBtnIndex = 0;
    
    for (UIView * subClass in self.subviews)
    {
        Class class = NSClassFromString(@"UITabBarButton");
        if ([subClass isKindOfClass:class])
        {
            subClass.width = tabBarBtnWidth;
            subClass.x = tabBarBtnIndex * tabBarBtnWidth;
            
            tabBarBtnIndex ++;
            if (tabBarBtnIndex == 2)
            {
                tabBarBtnIndex ++;
            }
        }
    }
}




@end
