//
//  BLShowLabelWithoutData.m
//  268EDU_Demo
//
//  Created by yzla50010 on 16/3/23.
//  Copyright © 2016年 edu268. All rights reserved.
//

#import "BLShowLabelWithoutData.h"
@interface BLShowLabelWithoutData()

/** 将来用来显示 */
@property (nonatomic, strong) UILabel *Contentlabel;
@property (nonatomic, strong) UIImageView *imageView;

@end

@implementation BLShowLabelWithoutData

static BLShowLabelWithoutData* _instance = nil;

+(instancetype)showLabel
{
    if (!_instance)
    {
        _instance = [[self alloc] init] ;
    }
    return _instance ;
}




- (UILabel *)Contentlabel
{
    if (!_Contentlabel)
    {
        _Contentlabel = [[UILabel alloc] init];
    }
    return _Contentlabel;
}

- (UIImageView *)imageView
{
    if (!_imageView)
    {
        _imageView = [[UIImageView alloc] init];
    }
    return _imageView;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:CGRectMake(kScreen_width/2-120, CGRectGetMinY(frame), 240, 120)];
    if (self)
    {
        self.backgroundColor = [UIColor clearColor];//把控件设置为透明色
    }
    return self;
}



- (void)showMessage:(NSString *)message Image:(NSString *)image isImage:(BOOL)isImage
{
    
    [self.imageView removeFromSuperview];
    [self.Contentlabel removeFromSuperview];
   
    if (isImage)
    {
        self.imageView.frame = CGRectMake(CGRectGetWidth(self.frame)/2-42, 0, 84, 84);
        
        self.imageView.image = [UIImage imageNamed:image];
        
        [self addSubview:self.imageView];
     
        self.Contentlabel.frame = CGRectMake(0, CGRectGetMaxY(_imageView.frame)+5, CGRectGetWidth(self.frame), 30);

        
    }
    else
    {
        self.Contentlabel.frame = CGRectMake(0, 20, CGRectGetWidth(self.frame), 30);
    }
    
    
    self.Contentlabel.text = message;
    self.Contentlabel.textAlignment = NSTextAlignmentCenter;
    self.Contentlabel.font = [UIFont systemFontOfSize:16];
    self.Contentlabel.textColor = [UIColor darkGrayColor];
    [self addSubview:self.Contentlabel];
    
}

- (void)dismiss
{
    [self removeFromSuperview];
}


@end
