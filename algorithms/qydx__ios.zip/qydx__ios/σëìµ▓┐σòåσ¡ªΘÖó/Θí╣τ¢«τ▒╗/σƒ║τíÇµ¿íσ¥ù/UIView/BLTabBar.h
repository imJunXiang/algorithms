//
//  BLTabBar.h
//  Sina_Microblog
//
//  Created by yzla50010 on 16/2/23.
//  Copyright © 2016年 yzla50010. All rights reserved.
/*
 *代理:
 *代理就是自己不能干的事, 自己定一个规则, 让别人去做.
 *tabBarButton 不能自己点击, 就让别人拿到他, 然后去实现他的点击事件 
 */

#import <UIKit/UIKit.h>

@class BLTabBar;//引入
////MARK: 因为HWTabBar继承自UITabBar，所以称为HWTabBar的代理，也必须实现UITabBar的代理协议

@protocol BLTabBarDelegate <UITabBarDelegate>
@optional
// 制订代理协义
- (void)BLTabBarBtnClick:(BLTabBar *)tabBar;

@end



@interface BLTabBar : UITabBar

@property (nonatomic, weak) id <BLTabBarDelegate>Delegate;


@end
