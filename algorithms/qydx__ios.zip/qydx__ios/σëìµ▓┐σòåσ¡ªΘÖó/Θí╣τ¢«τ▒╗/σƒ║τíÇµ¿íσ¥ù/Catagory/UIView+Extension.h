//
//  UIView+Extension.h
//  Sina_Microblog
//
//  Created by yzla50010 on 16/2/21.
//  Copyright © 2016年 yzla50010. All rights reserved.
//

#import <UIKit/UIKit.h>

//分类
@interface UIView (Extension)
@property (nonatomic, assign) CGFloat x;
@property (nonatomic, assign) CGFloat y;
@property (nonatomic, assign) CGFloat width;
@property (nonatomic, assign) CGFloat height;
@property (nonatomic, assign) CGFloat centerX;
@property (nonatomic, assign) CGFloat centerY;

@property (nonatomic, assign) CGSize size;//控件尺寸
@property (nonatomic, assign) CGPoint origin;//控件坐标









@end
