//
//  UIAlertView+AlertV.h
//  268EDU_Demo
//
//  Created by yzla50010 on 16/5/18.
//  Copyright © 2016年 edu268. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIAlertView (AlertV)
+ (UIAlertView *)alertView:(NSString *)title image:(UIImage *)image confirm:(NSString *)confirm cancel:(NSString *)cancel;

@end
