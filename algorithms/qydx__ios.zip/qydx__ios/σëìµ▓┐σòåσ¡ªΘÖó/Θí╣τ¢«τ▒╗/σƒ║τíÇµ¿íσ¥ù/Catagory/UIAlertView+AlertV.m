//
//  UIAlertView+AlertV.m
//  268EDU_Demo
//
//  Created by yzla50010 on 16/5/18.
//  Copyright © 2016年 edu268. All rights reserved.
//

#import "UIAlertView+AlertV.h"

@implementation UIAlertView (AlertV)

+ (UIAlertView *)alertView:(NSString *)title image:(UIImage *)image confirm:(NSString *)confirm cancel:(NSString *)cancel
{

    UIAlertView *aler = [[UIAlertView alloc] initWithTitle:@"提示" message:@"无可用网络" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"去学习", nil];
    for (Class class in aler.subviews)
    {
        NSLog(@"------%@", NSStringFromClass(class));
    }
    return aler;
}

@end
