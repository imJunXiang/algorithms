//
//  UIBarButtonItem+Extension.m
//  Sina_Microblog
//
//  Created by yzla50010 on 16/2/21.
//  Copyright © 2016年 yzla50010. All rights reserved.
//

#import "UIBarButtonItem+Extension.h"

@implementation UIBarButtonItem (Extension)


/*
+ (UIBarButtonItem *)itemWithTarget:(id)target action:(SEL)action image:(NSString *)image highImage:(NSString *)highImage title:(NSString *)title
{

    UIView *view = [[UIView alloc] init];
    view.frame = CGRectMake(0, 0, 120, 44);
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    
    [btn setBackgroundImage:[UIImage imageNamed:image] forState:UIControlStateNormal];
    [btn setBackgroundImage:[UIImage imageNamed:highImage] forState:UIControlStateHighlighted];
    // 设置尺寸
    btn.size = btn.currentBackgroundImage.size;
    btn.x = 0;
    btn.y = CGRectGetMidY(view.frame) - btn.size.height*0.5;
   
    [view addSubview:btn];

    UILabel *label = [[UILabel alloc] init];
    label.x = CGRectGetMaxX(btn.frame);
    label.y = CGRectGetMidY(view.frame) *0.5;
    label.size = CGSizeMake(100, 21);
    
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont systemFontOfSize:14.0];
    label.textColor = navColor;
    label.text = title;
    [view addSubview:label];
    
    return [[UIBarButtonItem alloc] initWithCustomView:view];

   
    
}
*/
+ (UIBarButtonItem *)itemWithTarget:(id)target action:(SEL)action circleImage:(NSString *)image
{
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    
    [btn setBackgroundImage:[UIImage getCircleImg:[UIImage imageNamed:image] size:CGSizeMake(34, 34)] forState:UIControlStateNormal];
    // 设置尺寸
    btn.size = btn.currentBackgroundImage.size;
    
    return [[UIBarButtonItem alloc] initWithCustomView:btn];
}

+ (UIBarButtonItem *)itemWithTarget:(id)target action:(SEL)action image:(NSString *)image
{
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    
    [btn setBackgroundImage:[UIImage imageNamed:image] forState:UIControlStateNormal];
    // 设置尺寸
    btn.size = btn.currentBackgroundImage.size;
    
    
    return [[UIBarButtonItem alloc] initWithCustomView:btn];
}

+ (UIBarButtonItem *)itemWithTarget:(id)target action:(SEL)action image:(NSString *)image highImage:(NSString *)highImage
{
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    
    [btn setBackgroundImage:[UIImage imageNamed:image] forState:UIControlStateNormal];
    [btn setBackgroundImage:[UIImage imageNamed:highImage] forState:UIControlStateHighlighted];
    // 设置尺寸
    btn.size = btn.currentBackgroundImage.size;
    
    
    return [[UIBarButtonItem alloc] initWithCustomView:btn];
}


@end
