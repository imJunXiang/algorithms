//
//  UIView+Extension.m
//  Sina_Microblog
//
//  Created by yzla50010 on 16/2/21.
//  Copyright © 2016年 yzla50010. All rights reserved.
//

#import "UIView+Extension.h"

@implementation UIView (Extension)

/* x * 重写x 的setter方法 */
- (void)setX:(CGFloat)x
{
    CGRect frame = self.frame;
    frame.origin.x = x;
    self.frame = frame;
}

/* x * 重写x 的getter方法 */
- (CGFloat)x
{
    return self.frame.origin.x;
}
- (void)setCenterX:(CGFloat)centerX
{
    CGPoint center = self.center;
    center.x = centerX;
    self.center = center;
}

- (CGFloat)centerX
{
    return self.center.x;
}

- (void)setCenterY:(CGFloat)centerY
{
    CGPoint center = self.center;
    center.y = centerY;
    self.center = center;
}

- (CGFloat)centerY
{
    return self.center.y;
}

/* y * 重写y 的setter方法 */
- (void)setY:(CGFloat)y
{
    CGRect frame = self.frame;
    frame.origin.y = y;
    self.frame = frame;
}

/* y * 重写y 的getter方法 */
- (CGFloat)y
{
    return self.frame.origin.y;
}


/* width * 重写width 的setter方法 */
- (void)setWidth:(CGFloat)width
{
    CGRect frame = self.frame;
    frame.size.width = width;
    self.frame = frame;
}

/* width * 重写width 的getter方法 */
- (CGFloat)width
{
    return self.frame.size.width;
}

/* height * 重写height 的setter方法 */
- (void)setHeight:(CGFloat)height
{
    CGRect frame = self.frame;
    frame.size.height = height;
    self.frame = frame;
}

/* height * 重写height 的getter方法 */
- (CGFloat)height
{
    return self.frame.size.height;
}

/* size * 重写size 的setter方法 */
- (void)setSize:(CGSize)size
{
    CGRect frame = self.frame;
    frame.size = size;
    self.frame = frame;
}

/* size * 重写size 的getter方法 */
- (CGSize)size
{
    return self.frame.size;
}

/* x * 重写x 的setter方法 */
- (void)setOrigin:(CGPoint)origin
{
    CGRect frame = self.frame;
    frame.origin = origin;
    self.frame = frame;
}

/* origin * 重写origin 的getter方法 */

- (CGPoint)origin
{
    return self.frame.origin;
}





@end
