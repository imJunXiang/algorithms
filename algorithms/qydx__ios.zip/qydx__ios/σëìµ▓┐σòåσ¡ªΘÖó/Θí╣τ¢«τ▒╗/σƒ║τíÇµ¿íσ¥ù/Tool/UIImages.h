//
//  UIImages.h
//  268EDU_Demo
//
//  Created by EDU268 on 15/10/29.
//  Copyright © 2015年 edu268. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImages : UIImage
+ (UIImage *)imageName:(NSString *)imageName andImageType:(NSString *)imageType;

@end
