//
//  UIAlertViewControl.m
//  268EDU_Demo
//
//  Created by yzla50010 on 16/5/17.
//  Copyright © 2016年 edu268. All rights reserved.
//

#import "UIAlertViewControl.h"

@implementation UIAlertViewControl

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.backgroundColor = [UIColor clearColor];//把控件设置为透明色
    }
    return self;
}

#pragma mark - 
- (void)alertView:(NSString *)title image:(UIImage *)image confirm:(NSString *)confirm cancel:(NSString *)cancel
{
    // 1. 获取最上面的窗口
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    
    // 2. 把本view类加到窗口中
    [window addSubview:self];
    
    // 3. 设置本类view的尺寸,窗口设置多大,self 就多大
    self.frame = window.frame;
    
    
    UIView *alertView = [[UIView alloc] initWithFrame:CGRectMake(kScreen_width/2-120, kScreen_height/2-80, 240, 150)];
    alertView.tag = 280;

    //    alertView.layer.cornerRadius = 5.0;
    [self addSubview:alertView];
    UILabel *labelAlert = [[UILabel alloc] initWithFrame:CGRectMake(alertView.bounds.size.width/2-40, 20, 80, 21)];
    UIImageView *imageVw = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, alertView.bounds.size.width, alertView.bounds.size.height)];
    imageVw.image = [UIImage imageNamed:@"警告框"];
    [alertView addSubview:imageVw];
    alertView.backgroundColor = [UIColor clearColor];
    labelAlert.text = @"提示";
    labelAlert.textColor = [UIColor whiteColor];
    labelAlert.textAlignment = NSTextAlignmentCenter;
    labelAlert.font = [UIFont systemFontOfSize:18];
    [imageVw addSubview:labelAlert];
    
    UILabel *message = [[UILabel alloc] initWithFrame:CGRectMake(alertView.bounds.size.width/2-100, 50, 200, 21)];
    message.text = @"是否保存本次练习并退出?";
    message.textColor = [UIColor whiteColor];
    message.tag = 281;
    message.textAlignment = NSTextAlignmentCenter;
    message.font = [UIFont systemFontOfSize:15];
    [imageVw addSubview:message];
    
    
    NSArray *yesOrNo = @[@"取消", @"确定"];
    for (NSInteger i = 0; i < 2; i++)
    {
        UIButton *yesOrNoBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        yesOrNoBtn.tag = 285+i;
        yesOrNoBtn.frame = CGRectMake(20*(i+1)+(alertView.bounds.size.width-40-20)/2*i, alertView.bounds.size.height- 44, (alertView.bounds.size.width-40-20)/2, 30);
        [yesOrNoBtn setTitle:yesOrNo[i] forState:UIControlStateNormal];
        [yesOrNoBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        yesOrNoBtn.titleLabel.font = [UIFont systemFontOfSize:18];
        [yesOrNoBtn addTarget:self action:@selector(yesOrNoBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        yesOrNoBtn.backgroundColor = [UIColor darkGrayColor];
        [alertView addSubview:yesOrNoBtn];
        if (i == 0)
            [yesOrNoBtn setBackgroundImage:[UIImage imageNamed:@"取消"] forState:UIControlStateNormal];
        else
            [yesOrNoBtn setBackgroundImage:[UIImage imageNamed:@"确定按钮"] forState:UIControlStateNormal];
    }
}


- (void)alertViewWithBackground:(NSString *)title image:(UIImage *)image confirm:(NSString *)confirm cancel:(NSString *)cancel
{
    UIView *alertView = [[UIView alloc] initWithFrame:CGRectMake(kScreen_width/2-120, kScreen_height/2-80, 240, 150)];
    alertView.tag = 280;
    alertView.hidden = NO;
    //    alertView.layer.cornerRadius = 5.0;
    [self addSubview:alertView];
    UILabel *labelAlert = [[UILabel alloc] initWithFrame:CGRectMake(alertView.bounds.size.width/2-40, 20, 80, 21)];
    UIImageView *imageVw = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, alertView.bounds.size.width, alertView.bounds.size.height)];
    imageVw.image = [UIImage imageNamed:@"警告框"];
    [alertView addSubview:imageVw];
    alertView.backgroundColor = [UIColor clearColor];
    labelAlert.text = @"提示";
    labelAlert.textColor = [UIColor whiteColor];
    labelAlert.textAlignment = NSTextAlignmentCenter;
    labelAlert.font = [UIFont systemFontOfSize:18];
    [imageVw addSubview:labelAlert];
    
    UILabel *message = [[UILabel alloc] initWithFrame:CGRectMake(alertView.bounds.size.width/2-100, 50, 200, 21)];
    message.text = @"是否保存本次练习并退出?";
    message.textColor = [UIColor whiteColor];
    message.tag = 281;
    message.textAlignment = NSTextAlignmentCenter;
    message.font = [UIFont systemFontOfSize:15];
    [imageVw addSubview:message];
    
    
    NSArray *yesOrNo = @[@"取消", @"确定"];
    for (NSInteger i = 0; i < 2; i++)
    {
        UIButton *yesOrNoBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        yesOrNoBtn.tag = 285+i;
        yesOrNoBtn.frame = CGRectMake(20*(i+1)+(alertView.bounds.size.width-40-20)/2*i, alertView.bounds.size.height- 44, (alertView.bounds.size.width-40-20)/2, 30);
        [yesOrNoBtn setTitle:yesOrNo[i] forState:UIControlStateNormal];
        [yesOrNoBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        yesOrNoBtn.titleLabel.font = [UIFont systemFontOfSize:18];
        [yesOrNoBtn addTarget:self action:@selector(yesOrNoBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        yesOrNoBtn.backgroundColor = [UIColor darkGrayColor];
        [alertView addSubview:yesOrNoBtn];
        if (i == 0)
            [yesOrNoBtn setBackgroundImage:[UIImage imageNamed:@"取消"] forState:UIControlStateNormal];
        else
            [yesOrNoBtn setBackgroundImage:[UIImage imageNamed:@"确定按钮"] forState:UIControlStateNormal];
    }
}

@end
