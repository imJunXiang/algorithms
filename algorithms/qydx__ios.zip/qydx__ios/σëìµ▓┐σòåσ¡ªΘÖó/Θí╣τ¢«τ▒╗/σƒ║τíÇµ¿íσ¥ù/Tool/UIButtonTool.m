//
//  UIButtonTool.m
//  268EDU_Demo
//
//  Created by EDU268 on 15/10/29.
//  Copyright © 2015年 edu268. All rights reserved.
//

#import "UIButtonTool.h"

@implementation UIButtonTool

+ (UIButton *)buttonTitle:(NSString *)title andImage:(UIImage *)image andColor:(UIColor *)color andFrame:(CGRect)rect
{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitle:title forState:UIControlStateNormal];
    button.backgroundColor = color;
    [button setImage:image forState:UIControlStateNormal];
    button.frame = rect;
    return button;
}
@end
