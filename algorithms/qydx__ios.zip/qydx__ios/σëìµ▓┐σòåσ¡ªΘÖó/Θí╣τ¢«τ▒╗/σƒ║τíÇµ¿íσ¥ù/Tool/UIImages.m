//
//  UIImages.m
//  268EDU_Demo
//
//  Created by EDU268 on 15/10/29.
//  Copyright © 2015年 edu268. All rights reserved.
//

#import "UIImages.h"

@implementation UIImages

+ (UIImage *)imageName:(NSString *)imageName andImageType:(NSString *)imageType
{
    NSString *path = [[NSBundle mainBundle] pathForResource:imageName ofType:imageType];
    UIImage *image = [UIImage imageWithContentsOfFile:path];
    
    return image;
}

@end
