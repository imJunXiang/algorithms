//
//  UIAlertViewControl.h
//  268EDU_Demo
//
//  Created by yzla50010 on 16/5/17.
//  Copyright © 2016年 edu268. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIAlertViewControl : UIView

- (void)alertView:(NSString *)title image:(UIImage *)image confirm:(NSString *)confirm cancel:(NSString *)cancel;

- (void)alertViewWithBackground:(NSString *)title image:(UIImage *)image confirm:(NSString *)confirm cancel:(NSString *)cancel;
@end
