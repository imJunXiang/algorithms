//
//  BackgroundSwitch.h
//  268EDU_Demo
//
//  Created by yzla50010 on 16/6/22.
//  Copyright © 2016年 edu268. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MJExtension.h>

@interface BackgroundSwitch : NSObject

@property (nonatomic, copy) NSString *verifyExam;// 考试开关
@property (nonatomic, copy) NSString *verifyCourseLive;// 直播开关
@property (nonatomic, copy) NSString *verifyLogin; //登录开关
@property (nonatomic, copy) NSString *verifyTranspond; //分享转发开关
@property (nonatomic, copy) NSString *verifyLimitLogin; //限制登录开关
@property (nonatomic, copy) NSString *verifySensitive; //开启敏感词过滤
@property (nonatomic, copy) NSString *verifyCourse; //购课赠送优惠券开关
@property (nonatomic, copy) NSString *verifyGro; //GRO开关
@property (nonatomic, copy) NSString *yee; //易宝支付开关
@property (nonatomic, copy) NSDictionary *verifyShare; // 分享注册赠送优惠券开关; //
@property (nonatomic, copy) NSString *verifyTeacherMien; //教师风采开关
@property (nonatomic, copy) NSString *verifyPractice; //课程随堂练习开关
@property (nonatomic, copy) NSString *verifyRegister; //注册开关
@property (nonatomic, copy) NSString *verifyAlipay; //支付宝支付开关
@property (nonatomic, copy) NSString *verifyRegEmailCode; //注册邮箱验证码开关
@property (nonatomic, copy) NSString *verifykq; //快钱支付开关
@property (nonatomic, copy) NSString *verifywx; //微信支付开关
@property (nonatomic, copy) NSString *verifyTeacherArticle; //教师文章开关
@property (nonatomic, copy) NSString *verifyRegMobileCode; //注册手机验证码开关
@property (nonatomic, copy) NSString *verifySns; //社区开关
@property (nonatomic, copy) NSString *visitorsToSeeTheCourse; //游客观看试看课程
@property (nonatomic, copy) NSString *verifyCourseDiscuss; //课程评论开关





@end
