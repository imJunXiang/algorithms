//
//  UILabelTool.m
//  268EDU_Demo
//
//  Created by EDU268 on 15/10/29.
//  Copyright © 2015年 edu268. All rights reserved.
//

#import "UILabelTool.h"

@implementation UILabelTool

+ (UILabel *)labelText:(NSString *)text andBackground:(UIColor *)color andSize:(CGFloat)size andFrame:(CGRect)frame
{
    UILabel *label = [[UILabel alloc] initWithFrame:frame];
    label.text = text;
    label.backgroundColor = color;
    label.font = [UIFont systemFontOfSize:size];
    return label;
}
@end
