//
//  Button_Model.m
//  268EDU_Demo
//
//  Created by EDU268 on 15/10/28.
//  Copyright © 2015年 edu268. All rights reserved.
//

#import "Button_Model.h"

@implementation Button_Model

- (UIButton *)creationTabBtnWithImageName:(NSString *)imageName andTitle:(NSString *)titleName andIndex:(int)index
{
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:imageName]];
    imageView.frame = CGRectMake((kScreen_width/index-25)/2, 5, 25, 25);
    [self addSubview:imageView];
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 28, kScreen_width/4, 14)];
    
    label.textAlignment = NSTextAlignmentCenter;
    label.text = titleName;
    label.textColor = [UIColor colorWithRed:0.49f green:0.49f blue:0.49f alpha:1.00f];
    label.font = [UIFont systemFontOfSize:11];
    [self addSubview:label];
    
    return self;
}



/*
 
 NSString *path = [[NSBundle mainBundle] pathForResource:@”icon” ofType:@”png”];
 UIImage *image = [UIImage imageWithContentsOfFile:path];
 
 以及：
 
 [objc] view plaincopy在CODE上查看代码片派生到我的代码片
 NSString *filePath = [[NSBundle mainBundle] pathForResource:fileName ofType:“png”];
 NSData *image = [NSData dataWithContentsOfFile:filePath];
 UIImage *image = [UIImage imageWithData:image];
 */

@end
