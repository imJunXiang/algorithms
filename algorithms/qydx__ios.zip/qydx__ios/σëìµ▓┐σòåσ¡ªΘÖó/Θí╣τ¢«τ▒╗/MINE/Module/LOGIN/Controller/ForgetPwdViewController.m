//
//  ForgetPassViewController.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/2.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "ForgetPwdViewController.h"

@interface ForgetPwdViewController ()
@property (nonatomic, strong) UITextField *accountTf;
@property (nonatomic, strong) UITextField *pwdTf;
@property (nonatomic, strong) UITextField *codeTf;
@property (nonatomic, strong) UIButton *sendBtn;
@property (nonatomic, strong) NSTimer *codeTimer;
@property (nonatomic, assign) NSInteger codeCount;
@property (nonatomic, strong) UIButton *saveBtn;
@end

@implementation ForgetPwdViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"重置密码";
    self.codeCount = 59;
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSeparateLineTop];
    
    UIView *accoutV = [self buildInputView:@"用户" title:@"请输入登录号码"];
    [self.view addSubview:accoutV];
    
    UIView *codeV = [self buildInputView:@"验证码" title:@"请输入验证码"];
    [self.view addSubview:codeV];
    
    UIView *passV = [self buildInputView:@"密码" title:@"输入新的登录密码"];
    [self.view addSubview:passV];
    
    UIButton *sendBtn = [[UIButton alloc] init];
    [sendBtn setTitleColor:[UIColor appBlueColor] forState:UIControlStateNormal];
    [sendBtn setTitle:@"发送验证码" forState:UIControlStateNormal];
    sendBtn.titleLabel.font = [UIFont systemFontOfSize:16];
    sendBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
    [codeV addSubview:sendBtn];
    self.sendBtn = sendBtn;
    [sendBtn addTarget:self action:@selector(sendCodeClick) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton *passShowBtn = [[UIButton alloc] init];
    [passShowBtn setBackgroundImage:[UIImage imageNamed:@"隐藏"] forState:UIControlStateNormal];
    [passShowBtn setBackgroundImage:[UIImage imageNamed:@"显示"] forState:UIControlStateSelected];
    [passShowBtn addTarget:self action:@selector(passShowSwitch:) forControlEvents:UIControlEventTouchUpInside];
    [passV addSubview:passShowBtn];
    
    UIButton *saveBtn = [[UIButton alloc] init];
    [saveBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [saveBtn setBackgroundImage:[UIImage imageNamed:@"lan"] forState:UIControlStateNormal];
    [saveBtn setBackgroundImage:[UIImage imageNamed:@"hui"] forState:UIControlStateDisabled];
    saveBtn.enabled = NO;
    saveBtn.titleLabel.font = [UIFont systemFontOfSize:15];
    [saveBtn setTitle:@"提交" forState:UIControlStateNormal];
    saveBtn.sd_cornerRadius = @(23);
    [self.view addSubview:saveBtn];
    [saveBtn addTarget:self action:@selector(saveClick) forControlEvents:UIControlEventTouchUpInside];
    self.saveBtn = saveBtn;
    
    accoutV.sd_layout
    .topSpaceToView(self.view, 30)
    .leftSpaceToView(self.view, 15)
    .rightSpaceToView(self.view, 15)
    .heightIs(44);
    
    codeV.sd_layout
    .topSpaceToView(accoutV, 30)
    .leftSpaceToView(self.view, 15)
    .rightSpaceToView(self.view, 15)
    .heightIs(44);
    
    passV.sd_layout
    .topSpaceToView(codeV, 30)
    .leftSpaceToView(self.view, 15)
    .rightSpaceToView(self.view, 15)
    .heightIs(44);
    
    sendBtn.sd_layout
    .centerYEqualToView(codeV)
    .rightSpaceToView(codeV, 15)
    .widthIs(90)
    .heightIs(20);
    
    passShowBtn.sd_layout
    .centerYEqualToView(passV)
    .rightSpaceToView(passV, 15)
    .widthIs(40)
    .heightIs(20);
    
    saveBtn.sd_layout
    .topSpaceToView(passV, 70)
    .centerXEqualToView(self.view)
    .widthIs(170)
    .heightIs(46);
}

- (void)tfChange {
    if (self.accountTf.text.length>0 && self.codeTf.text.length>0 && self.pwdTf.text.length>0) {
        self.saveBtn.enabled = YES;
    } else {
        self.saveBtn.enabled = NO;
    }
}

- (void)sendCodeClick {
    if (self.accountTf.text.length<=0) {
        [MBProgressHUD showError:@"请填写绑定的手机号"];
        return;
    }
    NSDictionary *params = @{@"mobile": self.accountTf.text};
    [HWHttpTool postWeb:[ApiConst resetpasswordVerifyCodeGet] params:params success:^(id json) {
        [self.codeTimer fire];
        [MBProgressHUD showSuccess:@"验证码已发送"];
    }];
}

- (void)saveClick {
    if (self.accountTf.text.length<=0) {
        [MBProgressHUD showError:@"请填写绑定的手机号"];
        return;
    }
    if (self.pwdTf.text.length<6||self.pwdTf.text.length>20) {
        [MBProgressHUD showError:@"密码长度为6-20位"];
        return;
    }
    NSDictionary *params = @{@"mobile": self.accountTf.text, @"verifyCode": self.codeTf.text, @"password": self.pwdTf.text};
    [HWHttpTool postWeb:[ApiConst passwordReset] params:params success:^(id json) {
        NSDictionary *data = json[@"result"];
        [MBProgressHUD showSuccess:@"密码重置成功"];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(HUB_TIME * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self.navigationController popViewControllerAnimated:YES];
        });
    }];
}

- (void)passShowSwitch:(UIButton *)button {
    button.selected = !button.selected;
    if (button.selected) { // 按下去了就是明文
        NSString *tempPwdStr = self.pwdTf.text;
        self.pwdTf.text = @""; // 这句代码可以防止切换的时候光标偏移
        self.pwdTf.secureTextEntry = NO;
        self.pwdTf.text = tempPwdStr;
    } else { // 暗文
        NSString *tempPwdStr = self.pwdTf.text;
        self.pwdTf.text = @"";
        self.pwdTf.secureTextEntry = YES;
        self.pwdTf.text = tempPwdStr;
    }
}

- (UIView *)buildInputView:(NSString *)icon title:(NSString *)title {
    UIView *backV = [[UIView alloc] init];
    backV.backgroundColor = [UIColor colorWithMacHexString:@"#f0f0f0"];
    backV.sd_cornerRadius = @(2);
    
    UIImageView *iconImgV = [[UIImageView alloc] init];
    iconImgV.image = [UIImage imageNamed:icon];
    [backV addSubview:iconImgV];
    
    UITextField *nameTf = [[UITextField alloc] init];
    nameTf.font = [UIFont systemFontOfSize:16];
    nameTf.backgroundColor = [UIColor clearColor];
    nameTf.placeholder = title;
    [backV addSubview:nameTf];
    [nameTf addTarget:self action:@selector(tfChange) forControlEvents:UIControlEventEditingChanged];
    
    if ([icon isEqualToString:@"用户"]) {
        self.accountTf = nameTf;
    }
    
    if ([icon isEqualToString:@"验证码"]) {
        self.codeTf = nameTf;
        self.codeTf.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
    }
    
    if ([icon isEqualToString:@"密码"]) {
        self.pwdTf = nameTf;
        self.pwdTf.secureTextEntry = YES;
    }
    
    iconImgV.sd_layout
    .centerYEqualToView(backV)
    .leftSpaceToView(backV, 15)
    .widthIs(14)
    .heightIs(16);
    
    nameTf.sd_layout
    .topSpaceToView(backV, 0)
    .leftSpaceToView(iconImgV, 15)
    .rightSpaceToView(backV, 55)
    .bottomSpaceToView(backV, 0);
    return backV;
}

- (NSTimer *)codeTimer
{
    if (!_codeTimer)
    {
        _codeTimer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(codeTimerUpdate) userInfo:nil repeats:YES];
    }
    return _codeTimer;
}

- (void)codeTimerUpdate {
    if ([_codeTimer isValid] && _codeCount <= 0)
    {
        [_codeTimer invalidate];
        _codeTimer = nil;
        _codeCount = 59;
        return;
    }
    _codeCount --;
    
    NSString *title = @"";
    if (_codeCount <= 0 || _codeCount > 60)
    {
        self.sendBtn.enabled = YES;
        title = @"获取验证码";
    }
    else
    {
        self.sendBtn.enabled = NO;
        title = [NSString stringWithFormat:@"%ld 秒", (long)_codeCount];
    }
    [self.sendBtn setTitle:title forState:UIControlStateNormal];
}

@end
