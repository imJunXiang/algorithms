//
//  LoginIndexViewController.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/2.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "LoginIndexViewController.h"
#import "ApplyIndexViewController.h"
#import "ForgetPwdViewController.h"
#import "UIWindow+Extension.h"
#import "BLMainViewController.h"

@interface LoginIndexViewController ()
@property (nonatomic, strong) UITextField *accountTf;
@property (nonatomic, strong) UITextField *pwdTf;
@end

@implementation LoginIndexViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    [self buildMainUI];
}

#pragma mark - DATA
#pragma mark - ACTION
- (void)loginClick {
    if (self.accountTf.text.length<=0 || self.pwdTf.text.length<=0) {
        [MBProgressHUD showError:@"请输入	账号/密码"];
        return;
    }
    
    NSDictionary *params = @{@"account": self.accountTf.text, @"password": self.pwdTf.text};
    [HWHttpTool postWeb:[ApiConst userAppLogin] params:params success:^(id json) {
        [GLOBAL_CACHE setString:json[@"result"] forKey:SESSION_ID];
        UIWindow *window = [UIApplication sharedApplication].keyWindow;
        BLMainViewController *vc = [[BLMainViewController alloc] init];
        window.rootViewController = vc;
    }];
}

- (void)applyClick {
    ApplyIndexViewController *vc = [[ApplyIndexViewController alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)forgetClick {
    ForgetPwdViewController *vc = [[ForgetPwdViewController alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)passShowSwitch:(UIButton *)button {
    button.selected = !button.selected;
    if (button.selected) { // 按下去了就是明文
        NSString *tempPwdStr = self.pwdTf.text;
        self.pwdTf.text = @""; // 这句代码可以防止切换的时候光标偏移
        self.pwdTf.secureTextEntry = NO;
        self.pwdTf.text = tempPwdStr;
    } else { // 暗文
        NSString *tempPwdStr = self.pwdTf.text;
        self.pwdTf.text = @"";
        self.pwdTf.secureTextEntry = YES;
        self.pwdTf.text = tempPwdStr;
    }
}
#pragma mark - UI
- (void)buildMainUI {
    self.navigationItem.title = @"登录";
    self.view.backgroundColor = [UIColor appBackGroundColor];
    UIImageView *iconImgV = [[UIImageView alloc] init];
    iconImgV.image = [UIImage imageNamed:@"2"];
    iconImgV.sd_cornerRadius = @(37);
    [self.view addSubview:iconImgV];
    
    UILabel *nameLb = [[UILabel alloc] init];
    nameLb.textColor = [UIColor appTextColor];
    nameLb.font = [UIFont systemFontOfSize:21];
    nameLb.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:nameLb];
    nameLb.text = @"前沿商学院";
    
    UIView *accoutV = [self buildInputView:@"用户" title:@"登录账号"];
    [self.view addSubview:accoutV];
    
    UIView *passV = [self buildInputView:@"密码" title:@"登录密码"];
    [self.view addSubview:passV];
    
    UIButton *passShowBtn = [[UIButton alloc] init];
    [passShowBtn setBackgroundImage:[UIImage imageNamed:@"隐藏"] forState:UIControlStateNormal];
    [passShowBtn setBackgroundImage:[UIImage imageNamed:@"显示"] forState:UIControlStateSelected];
    [passShowBtn addTarget:self action:@selector(passShowSwitch:) forControlEvents:UIControlEventTouchUpInside];
    [passV addSubview:passShowBtn];
    
    UIButton *loginBtn = [[UIButton alloc] init];
    [loginBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [loginBtn setTitle:@"登录" forState:UIControlStateNormal];
    [loginBtn addTarget:self action:@selector(loginClick) forControlEvents:UIControlEventTouchUpInside];
    loginBtn.sd_cornerRadius = @(2);
    [self.view addSubview:loginBtn];
    
    UIButton *forgetBtn = [[UIButton alloc] init];
    [forgetBtn setTitleColor:[UIColor colorWithMacHexString:@"#bfbfbf"] forState:UIControlStateNormal];
    forgetBtn.titleLabel.font = [UIFont systemFontOfSize:12];
    [forgetBtn setTitle:@"忘记密码" forState:UIControlStateNormal];
    forgetBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
    [forgetBtn addTarget:self action:@selector(forgetClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:forgetBtn];
    
    UIButton *applyBtn = [[UIButton alloc] init];
    [applyBtn setTitleColor:[UIColor colorWithMacHexString:@"#bfbfbf"] forState:UIControlStateNormal];
    applyBtn.titleLabel.font = [UIFont systemFontOfSize:15];
    [applyBtn setTitle:@"申请试用" forState:UIControlStateNormal];
    [applyBtn addTarget:self action:@selector(applyClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:applyBtn];
    
    iconImgV.sd_layout
    .centerXEqualToView(self.view)
    .topSpaceToView(self.view, 40)
    .widthIs(74)
    .heightIs(74);
    
    nameLb.sd_layout
    .topSpaceToView(iconImgV, 20)
    .leftSpaceToView(self.view, 20)
    .rightSpaceToView(self.view, 20)
    .heightIs(20);
    
    accoutV.sd_layout
    .topSpaceToView(nameLb, 25)
    .leftSpaceToView(self.view, 15)
    .rightSpaceToView(self.view, 15)
    .heightIs(44);
    
    passV.sd_layout
    .topSpaceToView(accoutV, 15)
    .leftSpaceToView(self.view, 15)
    .rightSpaceToView(self.view, 15)
    .heightIs(44);
    
    passShowBtn.sd_layout
    .centerYEqualToView(passV)
    .rightSpaceToView(passV, 15)
    .widthIs(40)
    .heightIs(20);
    
    loginBtn.sd_layout
    .topSpaceToView(passV, 36)
    .leftSpaceToView(self.view, 15)
    .rightSpaceToView(self.view, 15)
    .heightIs(40);
    
    forgetBtn.sd_layout
    .bottomSpaceToView(loginBtn, 10)
    .rightSpaceToView(self.view, 40)
    .widthIs(120)
    .heightIs(12);
    
    applyBtn.sd_layout
    .bottomSpaceToView(self.view, 100)
    .centerXEqualToView(self.view)
    .widthIs(120)
    .heightIs(14);
    
    [loginBtn updateLayout];
    //Gradient 0 fill for 圆角矩形 5 拷贝 3
    CAGradientLayer *gradientLayer0 = [[CAGradientLayer alloc] init];
    gradientLayer0.frame = loginBtn.bounds;
    gradientLayer0.colors = @[
                              (id)[UIColor colorWithRed:108.0f/255.0f green:201.0f/255.0f blue:255.0f/255.0f alpha:1.0f].CGColor,
                              (id)[UIColor colorWithRed:93.0f/255.0f green:101.0f/255.0f blue:255.0f/255.0f alpha:1.0f].CGColor];
    gradientLayer0.locations = @[@0, @1];
    [gradientLayer0 setStartPoint:CGPointMake(0, 1)];
    [gradientLayer0 setEndPoint:CGPointMake(1, 1)];
    [loginBtn.layer addSublayer:gradientLayer0];
}

- (UIView *)buildInputView:(NSString *)icon title:(NSString *)title {
    UIView *backV = [[UIView alloc] init];
    backV.backgroundColor = [UIColor colorWithMacHexString:@"#f0f0f0"];
    backV.sd_cornerRadius = @(2);
    
    UIImageView *iconImgV = [[UIImageView alloc] init];
    iconImgV.image = [UIImage imageNamed:icon];
    [backV addSubview:iconImgV];
    
    UITextField *nameTf = [[UITextField alloc] init];
    nameTf.font = [UIFont systemFontOfSize:16];
    nameTf.backgroundColor = [UIColor clearColor];
    nameTf.placeholder = title;
    [backV addSubview:nameTf];
    
    if ([title isEqualToString:@"登录账号"]) {
        self.accountTf = nameTf;
    
    } else {
        self.pwdTf = nameTf;
        self.pwdTf.secureTextEntry = YES;
    }
    
    iconImgV.sd_layout
    .centerYEqualToView(backV)
    .leftSpaceToView(backV, 15)
    .widthIs(14)
    .heightIs(16);
    
    nameTf.sd_layout
    .topSpaceToView(backV, 0)
    .leftSpaceToView(iconImgV, 15)
    .rightSpaceToView(backV, 55)
    .bottomSpaceToView(backV, 0);
    return backV;
}

@end
