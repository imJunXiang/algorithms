//
//  WitnessCityView.m
//  前沿商学院
//
//  Created by 邓壮壮 on 2017/6/20.
//  Copyright © 2017年 edu268. All rights reserved.
//

#import "WitnessCityView.h"

@interface WitnessCityView()<UIPickerViewDelegate, UIPickerViewDataSource>
@property (nonatomic, strong) NSArray *cityArr;
@property(nonatomic,assign) NSInteger proIndex;
@property (nonatomic, strong) NSDictionary *model;
@end

@implementation WitnessCityView

- (instancetype)initWithFrame:(CGRect)frame cityArr:(NSArray *)cityArr {
    self = [super initWithFrame:frame];
    self.cityArr = cityArr;
    self.time = 1.0;
    UITapGestureRecognizer *tapGes = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(closeClickAction)];
    
    UIView *maskView = [[UIView alloc] init];
    maskView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.3];
    [self addSubview:maskView];
    self.maskView = maskView;
    [maskView addGestureRecognizer:tapGes];
    
    UIView *backView = [[UIView alloc] init];
    backView.backgroundColor = [UIColor whiteColor];
    [maskView addSubview:backView];
    self.backView = backView;
    
    UIPickerView *cityView = [[UIPickerView alloc] init];
    cityView.delegate = self;
    cityView.dataSource = self;
    [backView addSubview:cityView];
    
    UIButton *closeBtn = [[UIButton alloc] init];
    [closeBtn setTitle:@"完成" forState:UIControlStateNormal];
    [closeBtn setTitleColor:[UIColor appBlueColor] forState:UIControlStateNormal];
    closeBtn.sd_cornerRadius = @(2);
    closeBtn.titleLabel.font = [UIFont systemFontOfSize:12];
    closeBtn.layer.borderColor = [UIColor appBlueColor].CGColor;
    closeBtn.layer.borderWidth = 1;
    [closeBtn addTarget:self action:@selector(closeClickAction) forControlEvents:UIControlEventTouchUpInside];
    [backView addSubview:closeBtn];
    
    UIButton *resetBtn = [[UIButton alloc] init];
    [resetBtn setTitle:@"重选" forState:UIControlStateNormal];
    [resetBtn setTitleColor:[UIColor appBlueColor] forState:UIControlStateNormal];
    resetBtn.sd_cornerRadius = @(2);
    resetBtn.titleLabel.font = [UIFont systemFontOfSize:12];
    resetBtn.layer.borderColor = [UIColor appBlueColor].CGColor;
    resetBtn.layer.borderWidth = 1;
    [resetBtn addTarget:self action:@selector(resetClickAction) forControlEvents:UIControlEventTouchUpInside];
    [backView addSubview:resetBtn];
    
    
    maskView.sd_layout.spaceToSuperView(UIEdgeInsetsMake(0, 0, 0, 0));
    
    backView.sd_layout
    .leftSpaceToView(maskView, 0)
    .rightSpaceToView(maskView, 0)
    .topSpaceToView(maskView, 0)
    .heightIs(300);
    
    closeBtn.sd_layout
    .rightSpaceToView(backView, 10)
    .topSpaceToView(backView, 10)
    .widthIs(50)
    .heightIs(25);
    
    resetBtn.sd_layout
    .leftSpaceToView(backView, 10)
    .topSpaceToView(backView, 10)
    .widthIs(50)
    .heightIs(25);
    
    cityView.sd_layout.spaceToSuperView(UIEdgeInsetsMake(0, 0, 0, 0));
    
    // 执行动画
    [UIView animateWithDuration:self.time animations:^{
        backView.sd_layout.bottomSpaceToView(maskView, 0);
        [backView updateLayout];
    }];
    
    NSMutableDictionary *model = [NSMutableDictionary dictionaryWithDictionary:self.cityArr[0]];
    model[@"type"] = @"1";
    self.model = model;
    
    return self;
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 2;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    if (component==0) {
        return self.cityArr.count;
    } else {
        NSArray *modelArr = self.cityArr[self.proIndex][@"childrenRegion"];
        return modelArr.count;
    }
}

-(NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    if (component==0) {
        NSDictionary *model = self.cityArr[row];
        return model[@"name"];
    }
    NSArray *modelArr = self.cityArr[self.proIndex][@"childrenRegion"];
    NSDictionary *model = modelArr[row];
    return model[@"name"];
}

-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    if (component == 0) {
        //记录当前选中的省会
        _proIndex = [pickerView selectedRowInComponent:0];
        [pickerView reloadComponent:1];
        [pickerView selectRow:0 inComponent:1 animated:YES];
        
        NSMutableDictionary *model = [NSMutableDictionary dictionaryWithDictionary:self.cityArr[self.proIndex]];
        model[@"type"] = @"1";
        self.model = model;
    } else {
        NSMutableDictionary *model = [NSMutableDictionary dictionaryWithDictionary:self.cityArr[self.proIndex]];
        if (row==0) {
            model[@"type"] = @"1";
            self.model = model;
        } else {
            NSMutableDictionary *subModel = [NSMutableDictionary dictionaryWithDictionary:model[@"childrenRegion"][row]];
            subModel[@"type"] = @"2";
            self.model = subModel;
        }
       
    }
}

- (void)resetClickAction {
    // 执行动画
    [UIView animateWithDuration:self.time animations:^{
        self.backView.sd_layout.bottomSpaceToView(self.maskView, -self.backView.height);
        [self.backView updateLayout];
    }];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(self.time * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        self.resetClickBlock();
    });
}

- (void)closeClickAction {
    // 执行动画
    [UIView animateWithDuration:self.time animations:^{
        self.backView.sd_layout.bottomSpaceToView(self.maskView, -self.backView.height);
        [self.backView updateLayout];
    }];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(self.time * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        self.closeClickBlock(self.model);
    });
}

@end
