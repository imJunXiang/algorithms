//
//  ApplyIndexViewController.h
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/2.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "BaseViewController.h"

@interface ApplyIndexViewController : BaseViewController

@end
