//
//  WitnessCityView.h
//  前沿商学院
//
//  Created by 邓壮壮 on 2017/6/20.
//  Copyright © 2017年 edu268. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WitnessCityView : UIView
@property (nonatomic, strong) UIView *backView;
@property (nonatomic, strong) UIView *maskView;
@property (nonatomic, assign) NSInteger time;

@property (nonatomic, copy) void (^closeClickBlock) (NSDictionary *model);
@property (nonatomic, copy) void (^resetClickBlock) ();

- (instancetype)initWithFrame:(CGRect)frame cityArr:(NSArray *)cityArr;
@end
