//
//  ApplyIndexViewController.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/2.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "ApplyIndexViewController.h"
#import "WitnessCityView.h"

@interface ApplyIndexViewController ()
@property (nonatomic, strong) UIScrollView *scrollV;
@property (nonatomic, strong) UITextField *inputTf1;
@property (nonatomic, strong) UITextField *inputTf2;
@property (nonatomic, strong) UITextField *inputTf3;
@property (nonatomic, strong) UITextField *inputTf4;
@property (nonatomic, strong) UITextField *inputTf5;
@end

@implementation ApplyIndexViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"申请试用";
    UIScrollView *scrollV = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, self.view.height)];
    scrollV.backgroundColor = [UIColor appBackGroundColor];
    [self.view addSubview:scrollV];
    self.scrollV = scrollV;
    
    UIView *backV = [[UIView alloc] init];
    backV.backgroundColor = [UIColor whiteColor];
    [scrollV addSubview:backV];
    
    UIView *input1 = [self buildInputView:@"公司" title:@"请输入公司名称"];
    [backV addSubview:input1];
    self.inputTf1 = input1.subviews[1];
    
    UIView *input2 = [self buildInputView:@"用户" title:@"请输入申请人姓名"];
    [backV addSubview:input2];
    self.inputTf2 = input2.subviews[1];
    
    UIView *input3 = [self buildInputView:@"职务" title:@"请输入申请人职务"];
    [backV addSubview:input3];
    self.inputTf3 = input3.subviews[1];
    
    UIView *input4 = [self buildInputView:@"联系方式" title:@"请输入联系方式"];
    [backV addSubview:input4];
    self.inputTf4 = input4.subviews[1];
    
    UIView *input5 = [self buildInputView:@"地址" title:@"公司所在地区"];
    [backV addSubview:input5];
    self.inputTf5 = input5.subviews[1];
    
    UIButton *saveBtn = [[UIButton alloc] init];
    [saveBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [saveBtn setBackgroundImage:[UIImage imageNamed:@"lan"] forState:UIControlStateNormal];
    saveBtn.titleLabel.font = [UIFont systemFontOfSize:15];
    [saveBtn setTitle:@"提交" forState:UIControlStateNormal];
    saveBtn.sd_cornerRadius = @(23);
    [scrollV addSubview:saveBtn];
    [saveBtn addTarget:self action:@selector(saveClick) forControlEvents:UIControlEventTouchUpInside];
    
    [backV addSeparateLineTop];
    
    backV.sd_layout
    .topSpaceToView(scrollV, 0)
    .leftSpaceToView(scrollV, 0)
    .rightSpaceToView(scrollV, 0);
    
    input1.sd_layout
    .topSpaceToView(backV, 30)
    .leftSpaceToView(backV, 15)
    .rightSpaceToView(backV, 15)
    .heightIs(44);
    
    input2.sd_layout
    .topSpaceToView(input1, 30)
    .leftSpaceToView(backV, 15)
    .rightSpaceToView(backV, 15)
    .heightIs(44);
    
    input3.sd_layout
    .topSpaceToView(input2, 30)
    .leftSpaceToView(backV, 15)
    .rightSpaceToView(backV, 15)
    .heightIs(44);
    
    input4.sd_layout
    .topSpaceToView(input3, 30)
    .leftSpaceToView(backV, 15)
    .rightSpaceToView(backV, 15)
    .heightIs(44);
    
    input5.sd_layout
    .topSpaceToView(input4, 30)
    .leftSpaceToView(backV, 15)
    .rightSpaceToView(backV, 15)
    .heightIs(44);
    
    [backV setupAutoHeightWithBottomView:input5 bottomMargin:45];
    
    saveBtn.sd_layout
    .topSpaceToView(backV, 30)
    .centerXEqualToView(scrollV)
    .widthIs(170)
    .heightIs(46);
    
    [scrollV setupAutoHeightWithBottomView:saveBtn bottomMargin:50];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    self.scrollV.height = self.view.height;
}

- (UIView *)buildInputView:(NSString *)icon title:(NSString *)title {
    UIView *backV = [[UIView alloc] init];
    backV.backgroundColor = [UIColor colorWithMacHexString:@"#f0f0f0"];
    backV.sd_cornerRadius = @(2);
    
    UIImageView *iconImgV = [[UIImageView alloc] init];
    iconImgV.image = [UIImage imageNamed:icon];
    [backV addSubview:iconImgV];
    
    UITextField *nameTf = [[UITextField alloc] init];
    nameTf.font = [UIFont systemFontOfSize:16];
    nameTf.backgroundColor = [UIColor clearColor];
    nameTf.placeholder = title;
    [backV addSubview:nameTf];
    
    if ([icon isEqualToString:@"地址"]) {
        UIButton *cityBtn = [UIButton new];
        [nameTf addSubview:cityBtn];
        cityBtn.sd_layout
        .topSpaceToView(nameTf, 0)
        .leftSpaceToView(nameTf, 0)
        .rightSpaceToView(nameTf, 0)
        .bottomSpaceToView(nameTf, 0);
        [cityBtn addTarget:self action:@selector(cityClick) forControlEvents:UIControlEventTouchUpInside];
    }
    
    iconImgV.sd_layout
    .centerYEqualToView(backV)
    .leftSpaceToView(backV, 15)
    .widthIs(14)
    .heightIs(16);
    
    nameTf.sd_layout
    .topSpaceToView(backV, 0)
    .leftSpaceToView(iconImgV, 15)
    .rightSpaceToView(backV, 55)
    .bottomSpaceToView(backV, 0);
    return backV;
}

- (void)cityClick {
    WitnessCityView *cityView = [[WitnessCityView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGTH)];
    [self.view addSubview:cityView];
    Weak(cityView);
    cityView.closeClickBlock = ^(NSDictionary *model) {
        [wArg removeFromSuperview];
        self.inputTf5.text = model[@"name"];
    };
    cityView.resetClickBlock = ^() {
        [wArg removeFromSuperview];
    };
}

- (void)saveClick {
    if (self.inputTf1.text.length<=0) {
        [MBProgressHUD showError:@"请填写公司名称"];
        return;
    }
    
    if (self.inputTf2.text.length<=0 || self.inputTf4.text.length<=0) {
        [MBProgressHUD showError:@"请填写申请人及联系方式"];
        return;
    }
    
    if (self.inputTf5.text.length<=0) {
        [MBProgressHUD showError:@"请填写省份及城市"];
        return;
    }
    
    NSDictionary *params = @{@"companyName": self.inputTf1.text, @"contactName": self.inputTf2.text, @"contactPosition": self.inputTf3.text, @"contact": self.inputTf4.text, @"address": self.inputTf5.text};
    [HWHttpTool getWeb:[ApiConst collectionAppTrialApply] params:params success:^(id json) {
        NSDictionary *data = json[@"result"];
        [MBProgressHUD showSuccess:@"申请已提交，请耐心等待"];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(HUB_TIME * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self.navigationController popViewControllerAnimated:YES];
        });
    }];
}

@end
