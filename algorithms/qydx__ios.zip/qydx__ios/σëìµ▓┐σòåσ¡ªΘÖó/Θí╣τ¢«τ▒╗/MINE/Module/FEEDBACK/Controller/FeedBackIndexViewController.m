//
//  FeedBackIndexViewController.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/3.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "FeedBackIndexViewController.h"
#import "HWTextView.h"

@interface FeedBackIndexViewController ()<UITextViewDelegate>
@property (nonatomic, strong) UITextView *contentV;
@property (nonatomic, strong) UITextField *phoneTf;
@property (nonatomic, strong) UIButton *saveBtn;
@end

@implementation FeedBackIndexViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self buildMainUI];
}

- (void)tfChange {
    if (self.contentV.text.length>0 && self.phoneTf.text.length>0) {
        self.saveBtn.enabled = YES;
    } else {
        self.saveBtn.enabled = NO;
    }
}

- (void)saveClick {
    if (self.contentV.text.length>450) {
        [MBProgressHUD showError:@"最多输入450字"];
        return;
    }
    
    NSDictionary *params = @{@"suggestion": self.contentV.text, @"contact": self.phoneTf.text};
    [HWHttpTool getWeb:[ApiConst collectionAppFeedback] params:params success:^(id json) {
        NSDictionary *data = json[@"result"];
        [MBProgressHUD showSuccess:@"提交成功，感谢您的反馈"];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(HUB_TIME * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self.navigationController popViewControllerAnimated:YES];
        });
    }];
}

- (void)buildMainUI {
    self.navigationItem.title = @"意见反馈";
    self.view.backgroundColor = [UIColor appBackGroundColor];
    
    UIView *backV = [[UIView alloc] init];
    backV.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:backV];
    
    UILabel *titleLb1 = [[UILabel alloc] init];
    titleLb1.textColor = [UIColor appTextColor];
    titleLb1.font = [UIFont systemFontOfSize:16 weight:400];
    titleLb1.textAlignment = NSTextAlignmentLeft;
    [backV addSubview:titleLb1];
    titleLb1.text = @"反馈信息";
    
    UIView *sepV1 = [UIView createSeparateLine];
    [backV addSubview:sepV1];
    
    UILabel *titleLb2 = [[UILabel alloc] init];
    titleLb2.textColor = [UIColor appTextColor];
    titleLb2.font = [UIFont systemFontOfSize:14];
    titleLb2.textAlignment = NSTextAlignmentLeft;
    [backV addSubview:titleLb2];
    titleLb2.text = @"请写下您的反馈内容：";
    
    UITextView *contentV = [[UITextView alloc] init];
    contentV.backgroundColor = [UIColor colorWithMacHexString:@"#f2f4f7"];
    contentV.sd_cornerRadius = @(2);
    [backV addSubview:contentV];
    
    // _placeholderLabel
    UILabel *placeHolderLabel = [[UILabel alloc] init];
    placeHolderLabel.text = @"最多可输入450字，十分感谢您的反馈。";
    placeHolderLabel.numberOfLines = 0;
    placeHolderLabel.textColor = [UIColor appLightTextColor];
    [placeHolderLabel sizeToFit];
    [contentV addSubview:placeHolderLabel];
    // same font
    contentV.font = [UIFont systemFontOfSize:13.f];
    placeHolderLabel.font = [UIFont systemFontOfSize:13.f];
    [contentV setValue:placeHolderLabel forKey:@"_placeholderLabel"];
    contentV.delegate = self;
    self.contentV = contentV;

    
    UIView *sepV2 = [UIView createSeparateLine];
    [backV addSubview:sepV2];
    
    UILabel *titleLb3 = [[UILabel alloc] init];
    titleLb3.textColor = [UIColor appTextColor];
    titleLb3.font = [UIFont systemFontOfSize:14];
    titleLb3.textAlignment = NSTextAlignmentLeft;
    [backV addSubview:titleLb3];
    titleLb3.text = @"您的联系方式：";
    
    UITextField *phoneTf = [[UITextField alloc] init];
    phoneTf.backgroundColor = [UIColor colorWithMacHexString:@"#f2f4f7"];
    phoneTf.sd_cornerRadius = @(2);
    phoneTf.keyboardType = UIKeyboardTypePhonePad;
    phoneTf.placeholder = @"请输入QQ/邮箱/手机号";
    [phoneTf setValue:[UIFont boldSystemFontOfSize:12] forKeyPath:@"_placeholderLabel.font"];
    [backV addSubview:phoneTf];
    phoneTf.leftView = [[UIView alloc] init];
    phoneTf.leftView.width = 10;
    phoneTf.leftViewMode = UITextFieldViewModeAlways;
    [phoneTf addTarget:self action:@selector(tfChange) forControlEvents:UIControlEventEditingChanged];
    self.phoneTf = phoneTf;
    
    UIButton *saveBtn = [[UIButton alloc] init];
    [saveBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [saveBtn setBackgroundImage:[UIImage imageNamed:@"lan"] forState:UIControlStateNormal];
    [saveBtn setBackgroundImage:[UIImage imageNamed:@"hui"] forState:UIControlStateDisabled];
    saveBtn.enabled = NO;
    saveBtn.titleLabel.font = [UIFont systemFontOfSize:15];
    [saveBtn setTitle:@"提交" forState:UIControlStateNormal];
    saveBtn.sd_cornerRadius = @(23);
    [self.view addSubview:saveBtn];
    self.saveBtn = saveBtn;
    [saveBtn addTarget:self action:@selector(saveClick) forControlEvents:UIControlEventTouchUpInside];
    
    backV.sd_layout
    .topSpaceToView(self.view, 0)
    .leftSpaceToView(self.view, 0)
    .rightSpaceToView(self.view, 0);
    
    titleLb1.sd_layout
    .topSpaceToView(backV, 15)
    .leftSpaceToView(backV, 15)
    .rightSpaceToView(backV, 15)
    .heightIs(15);
    
    sepV1.sd_layout
    .topSpaceToView(titleLb1, 15)
    .leftSpaceToView(backV, 15)
    .rightSpaceToView(backV, 15)
    .heightIs(1);
    
    titleLb2.sd_layout
    .topSpaceToView(sepV1, 15)
    .leftSpaceToView(backV, 15)
    .rightSpaceToView(backV, 15)
    .heightIs(14);
    
    contentV.sd_layout
    .topSpaceToView(titleLb2, 15)
    .leftSpaceToView(backV, 15)
    .rightSpaceToView(backV, 15)
    .heightIs(90);
    
    sepV2.sd_layout
    .topSpaceToView(contentV, 15)
    .leftSpaceToView(backV, 15)
    .rightSpaceToView(backV, 15)
    .heightIs(1);
    
    titleLb3.sd_layout
    .topSpaceToView(sepV2, 15)
    .leftSpaceToView(backV, 15)
    .rightSpaceToView(backV, 15)
    .heightIs(14);
    
    phoneTf.sd_layout
    .topSpaceToView(titleLb3, 15)
    .leftSpaceToView(backV, 15)
    .rightSpaceToView(backV, 15)
    .heightIs(40);
    
    [backV setupAutoHeightWithBottomView:phoneTf bottomMargin:15];
    
    saveBtn.sd_layout
    .topSpaceToView(backV, 66)
    .centerXEqualToView(self.view)
    .widthIs(170)
    .heightIs(46);
}

- (void)textViewDidChange:(UITextView *)textView {
    [self tfChange];
}

@end
