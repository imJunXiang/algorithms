//
//  ModifyEmailViewController.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/3.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "ModifyEmailViewController.h"

@interface ModifyEmailViewController ()
@property (nonatomic, strong) UIButton *saveBtn;
@property (nonatomic, strong) UITextField *emailTf;
@end

@implementation ModifyEmailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"修改邮箱";
    self.view.backgroundColor = [UIColor appBackGroundColor];
    UIView *emailV = [self buildInput:@"修改邮箱：" inputTitle:@"请输入要修改的邮箱"];
    [self.view addSubview:emailV];
    
    UIButton *saveBtn = [[UIButton alloc] init];
    [saveBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [saveBtn setBackgroundImage:[UIImage imageNamed:@"hui"] forState:UIControlStateDisabled];
    [saveBtn setBackgroundImage:[UIImage imageNamed:@"lan"] forState:UIControlStateNormal];
    saveBtn.titleLabel.font = [UIFont systemFontOfSize:15];
    [saveBtn setTitle:@"提交" forState:UIControlStateNormal];
    saveBtn.sd_cornerRadius = @(23);
    saveBtn.enabled = NO;
    [self.view addSubview:saveBtn];
    self.saveBtn = saveBtn;
    [saveBtn addTarget:self action:@selector(saveClick) forControlEvents:UIControlEventTouchUpInside];
    
    emailV.sd_layout
    .topSpaceToView(self.view, 0)
    .leftSpaceToView(self.view, 0)
    .rightSpaceToView(self.view, 0)
    .heightIs(100);
    
    saveBtn.sd_layout
    .bottomSpaceToView(self.view, 230*HEIGHT_RADIO)
    .centerXEqualToView(self.view)
    .widthIs(170)
    .heightIs(46);
}

- (void)saveClick {
    NSDictionary *params = @{@"email": self.emailTf.text};
    [HWHttpTool postWeb:[ApiConst userAppEmailModify] params:params success:^(id json) {
        [MBProgressHUD showSuccess:@"修改成功"];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(HUB_TIME * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self.navigationController popViewControllerAnimated:YES];
        });
    }];
}

- (void)tfChange {
    if (self.emailTf.text.length>0) {
        self.saveBtn.enabled = YES;
    } else {
        self.saveBtn.enabled = NO;
    }
}

- (UIView *)buildInput:(NSString *)title inputTitle:(NSString *)inputTitle {
    UIView *backV = [[UIView alloc] init];
    backV.backgroundColor = [UIColor whiteColor];
    
    UILabel *titleLb = [[UILabel alloc] init];
    titleLb.textColor = [UIColor appTextColor];
    titleLb.font = [UIFont systemFontOfSize:14];
    titleLb.textAlignment = NSTextAlignmentLeft;
    [backV addSubview:titleLb];
    titleLb.text = title;
    
    UITextField *pwdTf = [[UITextField alloc] init];
    pwdTf.backgroundColor = [UIColor colorWithMacHexString:@"#f2f4f7"];
    pwdTf.sd_cornerRadius = @(2);
    pwdTf.placeholder = inputTitle;
    pwdTf.leftView = [[UIView alloc] init];
    pwdTf.leftView.width = 10;
    pwdTf.clearsOnBeginEditing = YES;
    pwdTf.leftViewMode = UITextFieldViewModeAlways;
    [pwdTf setValue:[UIFont boldSystemFontOfSize:12] forKeyPath:@"_placeholderLabel.font"];
    [backV addSubview:pwdTf];
    [pwdTf addTarget:self action:@selector(tfChange) forControlEvents:UIControlEventEditingChanged];
    self.emailTf = pwdTf;
    
    
    [backV addSeparateLineTop];
    
    titleLb.sd_layout
    .topSpaceToView(backV, 15)
    .leftSpaceToView(backV, 15)
    .rightSpaceToView(backV, 15)
    .heightIs(14);
    
    pwdTf.sd_layout
    .topSpaceToView(titleLb, 15)
    .leftSpaceToView(backV, 15)
    .rightSpaceToView(backV, 15)
    .heightIs(40);
    
    return backV;
}

@end
