//
//  UserInfoHeaderView.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/2.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "UserInfoIndexHeaderView.h"

@implementation UserInfoIndexHeaderView

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        UIButton *iconBtn = [[UIButton alloc] init];
        iconBtn.sd_cornerRadius = @(40);
        [self addSubview:iconBtn];
        self.iconBtn = iconBtn;
        
        UIImageView *iconImgV = [[UIImageView alloc] init];
        iconImgV.image = [UIImage imageNamed:@"mine_1"];
        [self addSubview:iconImgV];
        
        UIView *sepV = [[UIView alloc] init];
        sepV.backgroundColor = [UIColor appBackGroundColor];
        [self addSubview:sepV];
        
        iconBtn.sd_layout
        .centerXEqualToView(self)
        .centerYEqualToView(self)
        .widthIs(80)
        .heightIs(80);
        
        iconImgV.sd_layout
        .topSpaceToView(iconBtn, -18)
        .leftSpaceToView(iconBtn, -18)
        .widthIs(18)
        .heightIs(18);
        
        sepV.sd_layout
        .topSpaceToView(iconBtn, 20)
        .leftSpaceToView(self, 0)
        .rightSpaceToView(self, 0)
        .heightIs(10);
    }
    return self;
}

@end
