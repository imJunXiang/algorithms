//
//  UserInfoIndexViewController.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/2.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "UserInfoIndexViewController.h"
#import "UserInfoIndexCell.h"
#import "UserInfoIndexHeaderView.h"
#import "ModifyPwdViewController.h"
#import "ModifyEmailViewController.h"

@interface UserInfoIndexViewController ()<UITableViewDelegate, UITableViewDataSource, UIImagePickerControllerDelegate, UINavigationControllerDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) UserInfoIndexHeaderView *headerV;
@property (nonatomic, strong) NSMutableDictionary *userInfoModel;
@end

@implementation UserInfoIndexViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self buildTableView];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self loadData];
}

#pragma mark - DATA
- (void)loadData {
    NSDictionary *params = @{};
    [HWHttpTool postWeb:[ApiConst userAppInfo] params:params success:^(id json) {
        NSDictionary *data = json[@"result"];
        [self.headerV.iconBtn sd_setImageWithURL:[data[@"avatar"] getURL] forState:UIControlStateNormal];
        self.userInfoModel = [NSMutableDictionary dictionaryWithDictionary:data];
        [self.tableView reloadData];
    }];
}

- (void)setSexData {
    NSDictionary *params = @{@"sex": self.userInfoModel[@"sex"]};
    [HWHttpTool postWeb:[ApiConst userAppSexModify] params:params success:^(id json) {
        
    }];
    [self.tableView reloadData];
}


#pragma mark - ACTION
- (void)iconClick {
    UIAlertController *alertC = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:(UIAlertControllerStyleActionSheet)];
    
    UIAlertAction *action1 = [UIAlertAction actionWithTitle:@"拍照" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action){
        if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
            UIImagePickerController *picker = [[UIImagePickerController alloc] init];
            picker.delegate = self;//设置UIImagePickerController的代理，同时要遵循UIImagePickerControllerDelegate，UINavigationControllerDelegate协议
            picker.allowsEditing = YES;//设置拍照之后图片是否可编辑，如果设置成可编辑的话会在代理方法返回的字典里面多一些键值。PS：如果在调用相机的时候允许照片可编辑，那么用户能编辑的照片的位置并不包括边角。
            picker.sourceType = UIImagePickerControllerSourceTypeCamera;//UIImagePicker选择器的数据来源，UIImagePickerControllerSourceTypeCamera说明数据来源于摄像头
            [self presentViewController:picker animated:YES completion:nil];
        } else{
            //如果当前设备没有摄像头
            [MBProgressHUD showError:@"哎呀，当前设备没有摄像头。"];
        }
    }];
    
    UIAlertAction *action2 = [UIAlertAction actionWithTitle:@"从相册选择" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]) {
            UIImagePickerController *picker = [[UIImagePickerController alloc]init];
            picker.delegate = self;
            picker.allowsEditing = YES;//是否可以对原图进行编辑
            
            //设置图片选择器的数据来源为 手机相册
            picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
            [self presentViewController:picker animated:YES completion:nil];
        } else {
            [MBProgressHUD showError:@"图片库不可用"];
        }
    }];
    
    UIAlertAction *action3 = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
    }];
    [alertC addAction:action1];
    [alertC addAction:action2];
    [alertC addAction:action3];
    [self presentViewController:alertC animated:YES completion:nil];
}

#pragma mark - UI
- (NSString *)getSexStr:(NSString *)sex {
    if ([[NSString stringWithObject:sex] isEqualToString:@"1"]) {
        return @"男";
    }
    if ([[NSString stringWithObject:sex] isEqualToString:@"2"]) {
        return @"女";
    }
    return @"";
}

- (void)buildTableView {
    self.navigationItem.title = @"个人信息";
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGTH) style:UITableViewStyleGrouped];
    self.tableView.backgroundColor = [UIColor appBackGroundColor];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.showsHorizontalScrollIndicator = NO;
    [self.view addSubview:self.tableView];
    
    UserInfoIndexHeaderView *headerV = [[UserInfoIndexHeaderView alloc] init];
    headerV.height = 125;
    self.tableView.tableHeaderView = headerV;
    self.headerV = headerV;
    [headerV.iconBtn addTarget:self action:@selector(iconClick) forControlEvents:UIControlEventTouchUpInside];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section==0) {
        return 3;
    }
    if (section==1) {
        return 2;
    }
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UserInfoIndexCell *cell = [UserInfoIndexCell cellWithTableView:tableView];
    if (indexPath.section==0) {
        if (indexPath.row==0) {
            cell.titleLb.text = @"名称：";
            cell.nameLb.text = self.userInfoModel[@"name"];
            cell.arrowImgV.hidden = YES;
        }
        if (indexPath.row==1) {
            cell.titleLb.text = @"性别：";
            cell.nameLb.text = [self getSexStr:self.userInfoModel[@"sex"]];
        }
        if (indexPath.row==2) {
            cell.titleLb.text = @"部门：";
            cell.nameLb.text = self.userInfoModel[@""];
            cell.arrowImgV.hidden = YES;
            cell.sepV.hidden = YES;
        }
    }
    if (indexPath.section==1) {
        if (indexPath.row==0) {
            cell.titleLb.text = @"电话：";
            cell.nameLb.text = self.userInfoModel[@"phone"];
            cell.arrowImgV.hidden = YES;
        }
        if (indexPath.row==1) {
            cell.titleLb.text = @"邮箱：";
            cell.nameLb.text = self.userInfoModel[@"email"];
            cell.sepV.hidden = YES;
        }
    }
    if (indexPath.section==2) {
        if (indexPath.row==0) {
            cell.titleLb.text = @"修改密码";
            cell.sepV.hidden = YES;
        }
    }
    return cell;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UIView *headerV = [[UIView alloc] init];
    headerV.backgroundColor = [UIColor clearColor];
    return headerV;
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    UIView *headerV = [[UIView alloc] init];
    headerV.backgroundColor = [UIColor clearColor];
    return headerV;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 10;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 0.1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 45;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section==0) {
        if (indexPath.row==1) {
            UIAlertController *alertC = [UIAlertController alertControllerWithTitle:nil message:@"请选择您的性别" preferredStyle:(UIAlertControllerStyleActionSheet)];
            
            UIAlertAction *action1 = [UIAlertAction actionWithTitle:@"男" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action){
                [self.userInfoModel setObject:@"1" forKey:@"sex"];
                [self setSexData];
            }];
            
            UIAlertAction *action2 = [UIAlertAction actionWithTitle:@"女" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                [self.userInfoModel setObject:@"2" forKey:@"sex"];
                [self setSexData];
            }];
            
            UIAlertAction *action3 = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            }];
            [alertC addAction:action1];
            [alertC addAction:action2];
            [alertC addAction:action3];
            [self presentViewController:alertC animated:YES completion:nil];
        }
    }
    if (indexPath.section==1) {
        if (indexPath.row==1) {
            ModifyEmailViewController *vc = [[ModifyEmailViewController alloc] init];
            [self.navigationController pushViewController:vc animated:YES];
        }
    }
    if (indexPath.section==2) {
        ModifyPwdViewController *vc = [[ModifyPwdViewController alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
    }
}

#pragma mark - 拍照/选择图片结束
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    
    UIImage *image = [info objectForKey:UIImagePickerControllerEditedImage];//编辑后的图片
    
    //设置image的尺寸
    
    CGSize imagesize = image.size;
    
    imagesize.height = 200;
    
    imagesize.width = 200;
    
    //对图片大小进行压缩--
    
    image = [self imageWithImage:image scaledToSize:imagesize];
    
    NSData *imageData = UIImageJPEGRepresentation(image,0.008);
    
    UIImage *compressionImage = [UIImage imageWithData:imageData];
    if (picker.sourceType == UIImagePickerControllerSourceTypeCamera)
    {
        UIImageWriteToSavedPhotosAlbum(compressionImage, nil, nil, nil);//把图片存到图片库
        
        self.headerV.iconBtn.imageView.image = compressionImage;
    }
    
    else
    {
        self.headerV.iconBtn.imageView.image = compressionImage;
        
    }
    
    
    [self saveImage:imageData];
    
    [picker dismissViewControllerAnimated:YES completion:nil];
}



//对图片尺寸进行压缩--

-(UIImage*)imageWithImage:(UIImage*)image scaledToSize:(CGSize)newSize

{
    
    // Create a graphics image context
    
    UIGraphicsBeginImageContext(newSize);
    
    
    // Tell the old image to draw in this new context, with the desired
    
    // new size
    
    [image drawInRect:CGRectMake(0,0,newSize.width,newSize.height)];
    
    
    // Get the new image from the context
    
    UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
    
    
    // End the context
    
    UIGraphicsEndImageContext();
    
    
    // Return the new image.
    
    return newImage;
    
}


- (void) saveImage:(NSData *)currentImage {
    AFHTTPSessionManager *mgr = [AFHTTPSessionManager manager];
    
    // Https证书
    //        [self httpsCerConfig:mgr];
    
    mgr.requestSerializer.timeoutInterval = 8.f;
    mgr.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/html", @"text/plain", @"text/json", nil];
    NSDate *date = [NSDate dateWithTimeIntervalSinceNow:0];
    NSTimeInterval dateIn=[date timeIntervalSince1970];
    // 设置请求头部
    [mgr.requestSerializer setValue:APP_VERSION forHTTPHeaderField:@"DAXUE-VERSION"];
    [mgr.requestSerializer setValue:@"IOS" forHTTPHeaderField:@"DAXUE-PLATFORM"];
    [mgr.requestSerializer setValue:@"com.qydx.www" forHTTPHeaderField:@"DAXUE-PACKAGE"];
    [mgr.requestSerializer setValue:[NSString stringWithFormat:@"%0.f", dateIn] forHTTPHeaderField:@"DAXUE-TIMESTAMP"];
    
    if ([GLOBAL_CACHE hasCacheForKey:SESSION_ID]) {
        NSMutableString *cookieString = [[NSMutableString alloc] init];
        [cookieString appendFormat:@"JSESSIONID=%@;", [GLOBAL_CACHE stringForKey:SESSION_ID]];
        [mgr.requestSerializer setValue:cookieString forHTTPHeaderField:@"Cookie"];
    }
    [mgr POST:[ApiConst userUpload] parameters:nil constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        formatter.dateFormat = @"yyyyMMddHHmmss";
        NSString *fileName = [NSString stringWithFormat:@"%@.png",[formatter stringFromDate:[NSDate date]]];
        //二进制文件，接口key值，文件路径，图片格式
        [formData appendPartWithFileData:currentImage name:@"file" fileName:fileName mimeType:@"image/jpg/png/jpeg"];
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [MBProgressHUD showSuccess:@"修改头像成功"];
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
    }];
}
    

#pragma mark - 取消拍照/选择图片
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [picker dismissViewControllerAnimated:YES completion:nil];
}

@end
