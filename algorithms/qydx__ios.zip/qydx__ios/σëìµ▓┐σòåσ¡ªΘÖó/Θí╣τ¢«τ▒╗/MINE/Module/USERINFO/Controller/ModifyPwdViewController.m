//
//  ModifyPwdViewController.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/3.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "ModifyPwdViewController.h"

@interface ModifyPwdViewController ()
@property (nonatomic, strong) UITextField *inputTf1;
@property (nonatomic, strong) UITextField *inputTf2;
@property (nonatomic, strong) UITextField *inputTf3;
@property (nonatomic, strong) UIButton *saveBtn;
@end

@implementation ModifyPwdViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"修改密码";
    self.view.backgroundColor = [UIColor appBackGroundColor];
    UIView *oldV = [self buildInput:@"原密码：" inputTitle:@"请输入账号原密码"];
    [self.view addSubview:oldV];
    self.inputTf1 = oldV.subviews[1];
    
    UIView *newV = [self buildInput:@"新密码：" inputTitle:@"请输入账号新密码"];
    [self.view addSubview:newV];
    self.inputTf2 = newV.subviews[1];
    
    UIView *sureV = [self buildInput:@"确认新密码：" inputTitle:@"请再次输入账号新密码确认"];
    [self.view addSubview:sureV];
    self.inputTf3 = sureV.subviews[1];
    
    UIButton *saveBtn = [[UIButton alloc] init];
    [saveBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [saveBtn setBackgroundImage:[UIImage imageNamed:@"hui"] forState:UIControlStateDisabled];
    [saveBtn setBackgroundImage:[UIImage imageNamed:@"lan"] forState:UIControlStateNormal];
    saveBtn.enabled = NO;
    saveBtn.titleLabel.font = [UIFont systemFontOfSize:15];
    [saveBtn setTitle:@"提交" forState:UIControlStateNormal];
    saveBtn.sd_cornerRadius = @(23);
    [self.view addSubview:saveBtn];
    self.saveBtn = saveBtn;
    [saveBtn addTarget:self action:@selector(saveClick) forControlEvents:UIControlEventTouchUpInside];
    
    oldV.sd_layout
    .topSpaceToView(self.view, 0)
    .leftSpaceToView(self.view, 0)
    .rightSpaceToView(self.view, 0)
    .heightIs(100);
    
    newV.sd_layout
    .topSpaceToView(oldV, 0)
    .leftSpaceToView(self.view, 0)
    .rightSpaceToView(self.view, 0)
    .heightIs(100);
    
    sureV.sd_layout
    .topSpaceToView(newV, 0)
    .leftSpaceToView(self.view, 0)
    .rightSpaceToView(self.view, 0)
    .heightIs(100);
    
    saveBtn.sd_layout
    .topSpaceToView(sureV, 48)
    .centerXEqualToView(self.view)
    .widthIs(170)
    .heightIs(46);
}

- (void)tfChange {
    if (self.inputTf1.text.length>0 && self.inputTf2.text.length>0 && self.inputTf3.text.length>0) {
        self.saveBtn.enabled = YES;
    } else {
        self.saveBtn.enabled = NO;
    }
}

- (void)saveClick {
    if (self.inputTf2.text.length<6||self.inputTf2.text.length>20) {
        [MBProgressHUD showError:@"密码长度为6-20位"];
        return;
    }
    
    if (![self.inputTf2.text isEqualToString:self.inputTf3.text]) {
        [MBProgressHUD showError:@"密码不一致"];
        return;
    }
    
    NSDictionary *params = @{@"password_old": self.inputTf1.text, @"password": self.inputTf2.text};
    [HWHttpTool postWeb:[ApiConst userAppPasswordModify] params:params success:^(id json) {
        [MBProgressHUD showSuccess:@"密码修改成功"];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(HUB_TIME * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self.navigationController popViewControllerAnimated:YES];
        });
    }];
}

- (UIView *)buildInput:(NSString *)title inputTitle:(NSString *)inputTitle {
    UIView *backV = [[UIView alloc] init];
    backV.backgroundColor = [UIColor whiteColor];
    
    UILabel *titleLb = [[UILabel alloc] init];
    titleLb.textColor = [UIColor appTextColor];
    titleLb.font = [UIFont systemFontOfSize:14];
    titleLb.textAlignment = NSTextAlignmentLeft;
    [backV addSubview:titleLb];
    titleLb.text = title;
    
    UITextField *pwdTf = [[UITextField alloc] init];
    pwdTf.backgroundColor = [UIColor colorWithMacHexString:@"#f2f4f7"];
    pwdTf.sd_cornerRadius = @(2);
    pwdTf.placeholder = inputTitle;
    pwdTf.leftView = [[UIView alloc] init];
    pwdTf.leftView.width = 10;
    pwdTf.leftViewMode = UITextFieldViewModeAlways;
    [pwdTf setValue:[UIFont boldSystemFontOfSize:12] forKeyPath:@"_placeholderLabel.font"];
    [backV addSubview:pwdTf];
    pwdTf.secureTextEntry = YES;
    [pwdTf addTarget:self action:@selector(tfChange) forControlEvents:UIControlEventEditingChanged];
    
    [backV addSeparateLineTop];
    
    titleLb.sd_layout
    .topSpaceToView(backV, 15)
    .leftSpaceToView(backV, 15)
    .rightSpaceToView(backV, 15)
    .heightIs(14);
    
    pwdTf.sd_layout
    .topSpaceToView(titleLb, 15)
    .leftSpaceToView(backV, 15)
    .rightSpaceToView(backV, 15)
    .heightIs(40);
    
    return backV;
}

@end
