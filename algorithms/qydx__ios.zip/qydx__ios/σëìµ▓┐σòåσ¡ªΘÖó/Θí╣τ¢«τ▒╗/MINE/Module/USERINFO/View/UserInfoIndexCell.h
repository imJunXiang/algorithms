//
//  UserInfoIndexCell.h
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/2.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UserInfoIndexCell : UITableViewCell
+ (instancetype)cellWithTableView:(UITableView *)tableView;
@property (nonatomic, strong) UILabel *titleLb;
@property (nonatomic, strong) UILabel *nameLb;
@property (nonatomic, strong) UIImageView *arrowImgV;
@property (nonatomic, strong) UIView *sepV;
@end
