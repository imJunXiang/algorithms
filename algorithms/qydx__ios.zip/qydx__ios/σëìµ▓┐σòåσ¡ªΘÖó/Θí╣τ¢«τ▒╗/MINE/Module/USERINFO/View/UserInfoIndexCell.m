//
//  UserInfoIndexCell.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/2.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "UserInfoIndexCell.h"

@implementation UserInfoIndexCell

+ (instancetype)cellWithTableView:(UITableView *)tableView
{
    NSString *cellID = @"UserInfoIndexCell";
    UserInfoIndexCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell == nil) {
        cell = [[UserInfoIndexCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
    }
    
    return cell;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    [self buildView];
    return self;
}

- (void)buildView {
    UILabel *titleLb = [[UILabel alloc] init];
    titleLb.textColor = [UIColor appTextColor];
    titleLb.font = [UIFont systemFontOfSize:15];
    titleLb.textAlignment = NSTextAlignmentLeft;
    [self addSubview:titleLb];
    self.titleLb = titleLb;
    
    UILabel *nameLb = [[UILabel alloc] init];
    nameLb.textColor = [UIColor appGrayTextColor];
    nameLb.font = [UIFont systemFontOfSize:15];
    nameLb.textAlignment = NSTextAlignmentLeft;
    [self addSubview:nameLb];
    self.nameLb = nameLb;
    
    self.arrowImgV = [self addArrowImgView];
    self.sepV = [self addSeparateLineMargin];
    
    titleLb.sd_layout
    .centerYEqualToView(self)
    .leftSpaceToView(self, 15)
    .heightIs(15);
    [titleLb setSingleLineAutoResizeWithMaxWidth:100];
    
    nameLb.sd_layout
    .centerYEqualToView(self)
    .leftSpaceToView(titleLb, 20)
    .rightSpaceToView(self, 35)
    .heightIs(18);
}

@end
