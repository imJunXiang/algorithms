//
//  MyAboutViewController.m
//  268EDU_Demo
//
//  Created by yzla50010 on 16/3/18.
//  Copyright © 2016年 edu268. All rights reserved.
//

#import "MyAboutViewController.h"
#import "UIWindow+Extension.h"
#import "BackgroundSwitch.h"
#import "MBProgressHUD+MJ.h"
#import "WelcomeViewController.h"

@interface MyAboutViewController ()
@property (weak, nonatomic) IBOutlet UIButton *phoneBtn;
@end

@implementation MyAboutViewController
{
    
    NSString * shreURL;
    NSString * sharePictureURL;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = @"关于我们";
    self.edgesForExtendedLayout = UIRectEdgeNone;
    self.view.backgroundColor = [UIColor whiteColor];
    
    // 版本号
    NSString *version = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    self.versionLB.text = [NSString stringWithFormat:@"v %@", version];
    
    // NSForegroundColorAttributeName
    NSDictionary *attrDict1 = @{ NSForegroundColorAttributeName: [UIColor blackColor] };
    NSDictionary *attrDict2 = @{ NSForegroundColorAttributeName: [UIColor appBlueColor] };
    
    NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc] initWithString: @"客服电话: " attributes: attrDict1];
    [attributedText appendAttributedString:[[NSMutableAttributedString alloc] initWithString: @"400-856-8999" attributes: attrDict2]];
    
    [self.phoneBtn setAttributedTitle:attributedText forState:UIControlStateNormal];
}
- (IBAction)phoneClick:(id)sender {
    PhoneCall(@"400-856-8999");
}

- (IBAction)welcomeBtnClick
{
    [UIView setStaticGuidePage];
}



@end
