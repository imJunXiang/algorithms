//
//  SettingIndexViewController.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/3.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "SettingIndexViewController.h"
#import "MyAboutViewController.h"

@interface SettingIndexViewController ()
@property (nonatomic, strong) UILabel *sizeLb;
@end

@implementation SettingIndexViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor appBackGroundColor];
    [self buildMainUI];
    [self initData];
}

- (void)initData {
    self.sizeLb.text = [self getImgSize];
}

- (void)logoutClick {
    [GLOBAL_CACHE removeCacheForKey:SESSION_ID];
    [[UIApplication sharedApplication].keyWindow switchRootViewController];
}

- (void)aboutClick {
    MyAboutViewController *vc = [[MyAboutViewController alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)clearImg {
    [[SDImageCache sharedImageCache] cleanDisk];
    [[SDImageCache sharedImageCache] clearDisk];
    [[SDImageCache sharedImageCache] clearMemory];
    [self initData];
}

//计算图片缓存大小

- (NSString *)getImgSize
{
    CGFloat size = [[SDImageCache sharedImageCache] getSize];
    
    NSString *message = [NSString stringWithFormat:@"%.2fB", size];

    if (size > (1024 * 1024))
    {
        size = size / (1024 * 1024);
        message = [NSString stringWithFormat:@"%.2fM", size];
    }
    else if (size > 1024)
    {
        size = size / 1024;
        
        message = [NSString stringWithFormat:@"%.2fKB", size];
    }
    return message;
}

- (void)buildMainUI {
    self.navigationItem.title = @"软件设置";
    UIButton *cell1 = [self buildCell:@"清理缓存"];
    [cell1 addTarget:self action:@selector(clearImg) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:cell1];
    
    UILabel *sizeLb = [[UILabel alloc] init];
    sizeLb.textColor = [UIColor appLightTextColor];
    sizeLb.font = [UIFont systemFontOfSize:12];
    sizeLb.textAlignment = NSTextAlignmentRight;
    [cell1 addSubview:sizeLb];
    self.sizeLb = sizeLb;
    
    UIButton *cell2 = [self buildCell:@"关于我们"];
    [cell2 addTarget:self action:@selector(aboutClick) forControlEvents:UIControlEventTouchUpInside];
    [cell2 addArrowImgView];
    [self.view addSubview:cell2];
    
    
    UIButton *saveBtn = [[UIButton alloc] init];
    [saveBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    saveBtn.backgroundColor = [UIColor appLightTextColor];
    saveBtn.titleLabel.font = [UIFont systemFontOfSize:15];
    [saveBtn setTitle:@"退出登录" forState:UIControlStateNormal];
    saveBtn.sd_cornerRadius = @(23);
    [self.view addSubview:saveBtn];
    
    [saveBtn addTarget:self action:@selector(logoutClick) forControlEvents:UIControlEventTouchUpInside];

    
    cell1.sd_layout
    .topSpaceToView(self.view, 10)
    .leftSpaceToView(self.view, 0)
    .rightSpaceToView(self.view, 0)
    .heightIs(45);
    
    sizeLb.sd_layout
    .topSpaceToView(cell1, 0)
    .bottomSpaceToView(cell1, 0)
    .rightSpaceToView(cell1, 15)
    .widthIs(120);
    
    cell2.sd_layout
    .topSpaceToView(cell1, 10)
    .leftSpaceToView(self.view, 0)
    .rightSpaceToView(self.view, 0)
    .heightIs(45);
    
    saveBtn.sd_layout
    .bottomSpaceToView(self.view, 190*HEIGHT_RADIO)
    .centerXEqualToView(self.view)
    .widthIs(170)
    .heightIs(46);
}

- (UIButton *)buildCell:(NSString *)name {
    UIButton *backV = [[UIButton alloc] init];
    backV.backgroundColor = [UIColor whiteColor];
    
    UILabel *nameLb = [[UILabel alloc] init];
    nameLb.textColor = [UIColor appTextColor];
    nameLb.font = [UIFont systemFontOfSize:15];
    nameLb.textAlignment = NSTextAlignmentLeft;
    [backV addSubview:nameLb];
    nameLb.text = name;
    
    nameLb.sd_layout
    .centerYEqualToView(backV)
    .leftSpaceToView(backV, 15)
    .widthIs(120)
    .heightIs(15);
    return backV;
}

@end
