//
//  MyAboutViewController.h
//  268EDU_Demo
//
//  Created by yzla50010 on 16/3/18.
//  Copyright © 2016年 edu268. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyAboutViewController : BaseViewController
@property (weak, nonatomic) IBOutlet UILabel *versionLB;

@end
