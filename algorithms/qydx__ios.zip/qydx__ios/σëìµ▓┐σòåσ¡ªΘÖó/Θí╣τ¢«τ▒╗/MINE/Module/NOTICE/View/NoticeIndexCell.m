//
//  NoticeIndexCell.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/6/30.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "NoticeIndexCell.h"

@implementation NoticeIndexCell

- (void)setModel:(NoticeIndexModel *)model {
    _model = model;
    self.nameLb.text = model.title;
    self.desLb.text = [NSString flattenHTML:model.content];
    self.dateLb.text = [NSDate dateWithOriginal:model.createtime format:@"yyyy-MM-dd"];
    if (model.readNoticeId!=nil) {
        self.redV.hidden = YES;
    } else {
        self.redV.hidden = NO;
    }
}

+ (instancetype)cellWithTableView:(UITableView *)tableView
{
    NSString *cellID = @"NoticeIndexCell";
    NoticeIndexCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell == nil) {
        cell = [[NoticeIndexCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
    }
    
    return cell;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    [self buildView];
    return self;
}

- (void)buildView {
    UIImageView *iconImgV = [[UIImageView alloc] init];
    iconImgV.image = [UIImage imageNamed:@"chat"];
    iconImgV.sd_cornerRadius = @(2);
    [self addSubview:iconImgV];
    self.iconImgV = iconImgV;
    
    UIView *redV = [[UIView alloc] init];
    redV.backgroundColor = [UIColor redColor];
    [self addSubview:redV];
    redV.sd_cornerRadius = @(4);
    self.redV = redV;
    
    UILabel *nameLb = [[UILabel alloc] init];
    nameLb.textColor = [UIColor appTextColor];
    nameLb.font = [UIFont systemFontOfSize:14];
    nameLb.textAlignment = NSTextAlignmentLeft;
    [self addSubview:nameLb];
    self.nameLb = nameLb;
    
    UILabel *desLb = [[UILabel alloc] init];
    desLb.textColor = [UIColor appGrayTextColor];
    desLb.font = [UIFont systemFontOfSize:12];
    desLb.textAlignment = NSTextAlignmentLeft;
    desLb.numberOfLines = 0;
    [self addSubview:desLb];
    self.desLb = desLb;
    
    UILabel *dateLb = [[UILabel alloc] init];
    dateLb.textColor = [UIColor appLightTextColor];
    dateLb.font = [UIFont systemFontOfSize:12];
    dateLb.textAlignment = NSTextAlignmentLeft;
    [self addSubview:dateLb];
    self.dateLb = dateLb;
    
    UIView *lineView = [[UIView alloc] init];
    lineView.backgroundColor = [UIColor colorWithMacHexString:@"#e8e8e8"];
    [self addSubview:lineView];
    lineView.sd_layout
    .leftSpaceToView(self, 77)
    .rightSpaceToView(self, 0)
    .bottomSpaceToView(self, 0)
    .heightIs(1);
    
    iconImgV.sd_layout
    .topSpaceToView(self, 15)
    .leftSpaceToView(self, 15)
    .widthIs(47)
    .heightIs(47);
    
    redV.sd_layout
    .bottomSpaceToView(iconImgV, -5)
    .widthIs(8)
    .leftSpaceToView(iconImgV, -5)
    .heightIs(8);
    
    nameLb.sd_layout
    .topSpaceToView(self, 15)
    .leftSpaceToView(iconImgV, 15)
    .rightSpaceToView(self, 15)
    .heightIs(14);
    
    desLb.sd_layout
    .topSpaceToView(nameLb, 15)
    .leftSpaceToView(iconImgV, 15)
    .rightSpaceToView(self, 15)
    .heightIs(32);
    
    dateLb.sd_layout
    .topSpaceToView(desLb, 10)
    .leftSpaceToView(iconImgV, 15)
    .rightSpaceToView(self, 15)
    .heightIs(10);
}

@end
