//
//  NoticeIndexCell.h
//  前沿商学院
//
//  Created by MisterDeng on 2018/6/30.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NoticeIndexModel.h"

@interface NoticeIndexCell : UITableViewCell
+ (instancetype)cellWithTableView:(UITableView *)tableView;
@property (nonatomic, strong) UIImageView *iconImgV;
@property (nonatomic, strong) UILabel *nameLb;
@property (nonatomic, strong) UILabel *desLb;
@property (nonatomic, strong) UILabel *dateLb;
@property (nonatomic, strong) UIView *redV;
@property (nonatomic, strong) NoticeIndexModel *model;
@end
