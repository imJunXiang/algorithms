//
//  NoticeIndexModel.h
//  前沿商学院
//
//  Created by MisterDeng on 2018/8/17.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NoticeIndexModel : NSObject
@property (nonatomic, copy) NSString *content;
@property (nonatomic, copy) NSString *coverImageUrl;
@property (nonatomic, copy) NSString *id;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *createtime;
@property (nonatomic, copy) NSString *type;
@property (nonatomic, copy) NSString *readNoticeId;
@end
