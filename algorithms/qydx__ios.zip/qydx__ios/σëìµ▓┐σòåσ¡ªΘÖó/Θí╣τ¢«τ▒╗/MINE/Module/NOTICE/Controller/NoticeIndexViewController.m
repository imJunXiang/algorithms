//
//  NoticeIndexViewController.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/6/30.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "NoticeIndexViewController.h"
#import "NoticeIndexCell.h"
#import "NoticeDetailViewController.h"
#import "NoticeIndexModel.h"

@interface NoticeIndexViewController ()<UITableViewDataSource, UITableViewDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, assign) NSInteger pageindex;
@property (nonatomic, strong) NSMutableArray *modelArr;
@end

@implementation NoticeIndexViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"企业公告";
    [self buildTableView];
    [self buildEmptyView:0 title:nil];
    [self initData];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    self.tableView.height = self.view.height;
}

#pragma mark - DATA
- (void)initData {
    self.pageindex = 1;
    self.modelArr = [NSMutableArray array];
    [self.tableView.mj_footer resetNoMoreData];
    [self loadData];
}

- (void)loadData {
    Weak(self);
    NSDictionary *params = @{@"pageSize": PAGE_COUNT, @"page": @(self.pageindex)};
    [HWHttpTool getWeb:[ApiConst noticeAppList] params:params success:^(id json) {
        NSDictionary *data = json[@"result"];
        if ([data[@"pages"] integerValue]<=wArg.pageindex) {
            [wArg.tableView.mj_footer endRefreshingWithNoMoreData];
        }
        
        [wArg.modelArr addObjectsFromArray:[NoticeIndexModel mj_objectArrayWithKeyValuesArray:data[@"records"]]];
        [wArg.tableView reloadData];
        [self emptyReload:self.modelArr];
    }];
}
#pragma mark - ACTION
#pragma mark - UI
- (void)buildTableView {
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGTH) style:UITableViewStylePlain];
    self.tableView.backgroundColor = [UIColor appBackGroundColor];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.showsHorizontalScrollIndicator = NO;
    [self.view addSubview:self.tableView];
    
    UIView *headerV = [UIView new];
    headerV.backgroundColor = [UIColor appBackGroundColor];
    headerV.height = 10;
    self.tableView.tableHeaderView = headerV;
    
    Weak(self);
    self.tableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        wArg.pageindex++;
        [wArg loadData];
        [wArg.tableView.mj_footer endRefreshing];
    }];
    
    MJChiBaoZiHeader *header = [MJChiBaoZiHeader headerWithRefreshingBlock:^{
        [wArg loadData];
        [wArg.tableView.mj_header endRefreshing];
    }];
    // 设置header
    self.tableView.mj_header = header;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.modelArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NoticeIndexModel *model = self.modelArr[indexPath.row];
    NoticeIndexCell *cell = [NoticeIndexCell cellWithTableView:tableView];
    cell.model = model;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 110;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NoticeIndexModel *model = self.modelArr[indexPath.row];
    NoticeDetailViewController *vc = [[NoticeDetailViewController alloc] init];
    vc.noticeId = model.id;
    model.readNoticeId = model.id;
    [self.tableView reloadData];
    [self.navigationController pushViewController:vc animated:YES];
}

@end
