//
//  NoticeIndexModel.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/8/17.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "NoticeIndexModel.h"

@implementation NoticeIndexModel
//"content" : "<p>根据可靠消息将会迎来倾盆大雨，就像黄河般滔滔不绝，所以呢然并卵，明天准时上班哈！<br><\/p><p><br><\/p>",
//"coverImageUrl" : "",
//"id" : 1,
//"title" : "今天下大雨，在家办公！！！今天下大雨，在家办公！！！今天下大雨，在家办公！！！今天下大雨，在家办公！！！今天下大雨，在家办公！！！今天下大雨，在家办公！！！今天下大雨，在家办公！！！今天下大雨，在家办公！！！",
//"creater" : "",
//"type" : 0,
//"createtime" : "2018-08-02 17:30:51",
//"viewCount" : "",
//"companyId" : 1

@end
