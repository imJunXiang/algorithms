//
//  NoticeDetailViewController.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/2.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "NoticeDetailViewController.h"

@interface NoticeDetailViewController ()
@property (nonatomic, strong) UIScrollView *scrollV;
@property (nonatomic, strong) UILabel *titleLb;
@property (nonatomic, strong) UILabel *timeLb;
@property (nonatomic, strong) UIWebView *contentWeb;
@end

@implementation NoticeDetailViewController

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    self.scrollV.height = self.view.height;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"公告详情";
    
    UIScrollView *scrollV = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, self.view.height)];
    scrollV.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:scrollV];
    self.scrollV = scrollV;
    
    UILabel *titleLb = [[UILabel alloc] init];
    titleLb.textColor = [UIColor appTextColor];
    titleLb.font = [UIFont systemFontOfSize:16 weight:400];
    titleLb.textAlignment = NSTextAlignmentLeft;
    [scrollV addSubview:titleLb];
    self.titleLb = titleLb;
    
    UILabel *timeLb = [[UILabel alloc] init];
    timeLb.textColor = [UIColor appGrayTextColor];
    timeLb.font = [UIFont systemFontOfSize:12];
    timeLb.textAlignment = NSTextAlignmentLeft;
    [scrollV addSubview:timeLb];
    self.timeLb = timeLb;
    
    UIWebView *contentWeb = [[UIWebView alloc] init];
    contentWeb.scrollView.bounces = NO;
    contentWeb.allowsInlineMediaPlayback = YES;
    [contentWeb.scrollView addObserver:self forKeyPath:@"contentSize" options:NSKeyValueObservingOptionNew context:nil];
    [scrollV addSubview:contentWeb];
    self.contentWeb = contentWeb;
    
    titleLb.sd_layout
    .topSpaceToView(scrollV, 20)
    .leftSpaceToView(scrollV, 15)
    .rightSpaceToView(scrollV, 15)
    .heightIs(20);
    
    timeLb.sd_layout
    .topSpaceToView(titleLb, 10)
    .leftSpaceToView(scrollV, 15)
    .rightSpaceToView(scrollV, 15)
    .heightIs(12);
    
    contentWeb.sd_layout
    .topSpaceToView(timeLb, 15)
    .leftSpaceToView(scrollV, 15)
    .rightSpaceToView(scrollV, 15)
    .autoHeightRatio(1);
    
    [scrollV setupAutoHeightWithBottomView:contentWeb bottomMargin:20];
    
    [self loadData];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context {
    if ([keyPath isEqualToString:@"contentSize"]) {
        CGSize size = [self.contentWeb sizeThatFits:CGSizeZero];
        self.contentWeb.sd_layout.heightIs(size.height);
    }
}

- (void)loadData {
    [HWHttpTool getWeb:[NSString stringWithFormat:@"%@%@", [ApiConst noticeDetail], self.noticeId] params:nil success:^(id json) {
        NSDictionary *data = json[@"result"];
        self.titleLb.text = data[@"title"];
        self.timeLb.text = [NSDate dateWithOriginal:data[@"createtime"] format:@"yyyy年MM月dd日"];
        [self.contentWeb loadHTMLString:data[@"content"] baseURL:nil];
    }];
    
    NSDictionary *params = @{@"noticeId": self.noticeId};
    [HWHttpTool getWeb:[ApiConst noticeRead] params:params success:^(id json) {
        
    }];
}



@end
