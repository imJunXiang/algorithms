//
//  MineIndexViewController.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/6/30.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "MineIndexViewController.h"
#import "MineIndexHeaderView.h"
#import "DiscoverIndexCell.h"
#import "NoticeIndexViewController.h"
#import "UserInfoIndexViewController.h"
#import "SettingIndexViewController.h"
#import "FeedBackIndexViewController.h"

@interface MineIndexViewController ()<UITableViewDelegate, UITableViewDataSource>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSArray *cellModelArr;
@property (nonatomic, strong) MineIndexHeaderView *headerV;
@end

@implementation MineIndexViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initData];
    [self buildTableView];
    [self buildHeaderView];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    self.tableView.height = self.view.height;
    [self loadData];
}

#pragma mark - DATA
- (void)initData {
    self.cellModelArr = @[@{@"icon": @"消息", @"name": @"企业公告"}, @{@"icon": @"设置", @"name": @"软件设置"}, @{@"icon": @"反馈", @"name": @"问题反馈"}];
}

- (void)loadData {
    NSDictionary *params = @{};
    [HWHttpTool postWeb:[ApiConst userAppInfo] params:params success:^(id json) {
        NSDictionary *data = json[@"result"];
        [self.headerV.iconImgV sd_setImageWithURL:[NSURL URLWithString:data[@"avatar"]]];
        self.headerV.nameLb.text = data[@"name"];
        self.headerV.desLb.text = data[@"phone"];
    }];
}
#pragma mark - ACTION
#pragma mark - UI
- (void)buildHeaderView {
    MineIndexHeaderView *headerV = [[MineIndexHeaderView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 90)];
    self.tableView.tableHeaderView = headerV;
    self.headerV = headerV;
    
    Weak(self);
    headerV.clickBlock = ^() {
        UserInfoIndexViewController *vc = [[UserInfoIndexViewController alloc] init];
        [wArg.navigationController pushViewController:vc animated:YES];
    };
}
- (void)buildTableView {
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGTH) style:UITableViewStylePlain];
    self.tableView.backgroundColor = [UIColor appBackGroundColor];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.showsHorizontalScrollIndicator = NO;
    [self.view addSubview:self.tableView];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.cellModelArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *model = self.cellModelArr[indexPath.row];
    DiscoverIndexCell *cell = [DiscoverIndexCell cellWithTableView:tableView];
    cell.model = model;
    if (indexPath.row==2) {
        cell.sepV.hidden = YES;
    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 45;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row==0) {
        NoticeIndexViewController *vc = [[NoticeIndexViewController alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
    }
    if (indexPath.row==1) {
        SettingIndexViewController *vc = [[SettingIndexViewController alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
    }
    if (indexPath.row==2) {
        FeedBackIndexViewController *vc = [[FeedBackIndexViewController alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
    }
}

@end
