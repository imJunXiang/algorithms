//
//  MineIndexHeaderView.h
//  前沿商学院
//
//  Created by MisterDeng on 2018/6/30.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MineIndexHeaderView : UIView
@property (nonatomic, strong) UIImageView *iconImgV;
@property (nonatomic, strong) UILabel *nameLb;
@property (nonatomic, strong) UILabel *desLb;
@property (nonatomic, copy) void (^clickBlock) ();
@end
