//
//  MineIndexHeaderView.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/6/30.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "MineIndexHeaderView.h"

@implementation MineIndexHeaderView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor appBackGroundColor];
        
        UIButton *backV = [[UIButton alloc] init];
        backV.backgroundColor = [UIColor whiteColor];
        [backV addTarget:self action:@selector(iconcClick) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:backV];
        
        UIImageView *iconImgV = [[UIImageView alloc] init];
        iconImgV.sd_cornerRadius = @(30);
        [backV addSubview:iconImgV];
        self.iconImgV = iconImgV;
        
        UILabel *nameLb = [[UILabel alloc] init];
        nameLb.textColor = [UIColor appTextColor];
        nameLb.font = [UIFont systemFontOfSize:15];
        nameLb.textAlignment = NSTextAlignmentLeft;
        [backV addSubview:nameLb];
        self.nameLb = nameLb;
        
        UILabel *desLb = [[UILabel alloc] init];
        desLb.textColor = [UIColor appLightTextColor];
        desLb.font = [UIFont systemFontOfSize:12];
        desLb.textAlignment = NSTextAlignmentLeft;
        [backV addSubview:desLb];
        self.desLb = desLb;
        
        UIView *lineView = [[UIView alloc] init];
        lineView.backgroundColor = [UIColor colorWithMacHexString:@"#e8e8e8"];
        [self addSubview:lineView];
        lineView.sd_layout
        .leftSpaceToView(self, 0)
        .rightSpaceToView(self, 0)
        .topSpaceToView(self, 0)
        .heightIs(0.5);
        
        [backV addArrowImgView];
        
        backV.sd_layout
        .topSpaceToView(self, 0)
        .leftSpaceToView(self, 0)
        .rightSpaceToView(self, 0)
        .bottomSpaceToView(self, 10);
        
        iconImgV.sd_layout
        .centerYEqualToView(backV)
        .leftSpaceToView(backV, 15)
        .widthIs(60)
        .heightIs(60);
        
        nameLb.sd_layout
        .topSpaceToView(backV, 22)
        .leftSpaceToView(iconImgV, 15)
        .rightSpaceToView(backV, 15)
        .heightIs(15);
        
        desLb.sd_layout
        .topSpaceToView(nameLb, 10)
        .leftSpaceToView(iconImgV, 15)
        .rightSpaceToView(backV, 15)
        .heightIs(15);
    }
    return self;
}

- (void)iconcClick {
    if (self.clickBlock!=nil) {
        self.clickBlock();
    }
}

@end
