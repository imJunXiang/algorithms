//
//  StudyPlainIndexCell.h
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/2.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StudyPlainIndexCell : UITableViewCell
+ (instancetype)cellWithTableView:(UITableView *)tableView;
@property (nonatomic, strong) UILabel *nameLb;
@property (nonatomic, strong) UILabel *perLb;
@property (nonatomic, strong) UILabel *timeLb;
@property (nonatomic, strong) UIImageView *handleBtn;

@property (nonatomic, strong) NSDictionary *model;
@end
