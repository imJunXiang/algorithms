//
//  DiscoverIndexViewController.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/6/29.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "StudyPlainIndexViewController.h"
#import "SGPagingView.h"
#import "StudyPlainIndexCell.h"
#import "StudyPlainDetailViewController.h"

@interface StudyPlainIndexViewController ()<UITableViewDelegate, UITableViewDataSource, SGPageTitleViewDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, assign) NSInteger pageindex;
@property (nonatomic, strong) NSMutableArray *modelArr;
@property (nonatomic, assign) NSInteger type;
@end

@implementation StudyPlainIndexViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self buildNavItem];
    [self buildHeaderView];
    [self buildTableView];
    [self buildEmptyView:44 title:nil];
    self.type = 0;
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    self.tableView.height = self.view.height-44;
}

#pragma mark - DATA
- (void)initData {
    self.pageindex = 1;
    self.modelArr = [NSMutableArray array];
    [self.tableView.mj_footer resetNoMoreData];
    [self loadData];
}

- (void)loadData {
    NSDictionary *params = @{@"page": @(self.pageindex), @"pageSize":PAGE_COUNT, @"timeType": @(self.type)};
    [HWHttpTool postWeb:[ApiConst studyPlanAppList] params:params success:^(id json) {
        NSDictionary *data = json[@"result"];
        if ([data[@"pages"] integerValue]<=self.pageindex) {
            [self.tableView.mj_footer endRefreshingWithNoMoreData];
        }
        
        [self.modelArr addObjectsFromArray:data[@"records"]];
        [self.tableView reloadData];
        [self emptyReload:self.modelArr];
    }];
}
#pragma mark - ACTION
- (void)rightItemClick {
    
}
#pragma mark - UI
- (void)buildNavItem {
    self.navigationItem.title = @"学习计划";
}

- (void)buildHeaderView {
    SGPageTitleViewConfigure *configure = [SGPageTitleViewConfigure pageTitleViewConfigure];
    configure.titleFont = [UIFont systemFontOfSize:14];
    configure.titleSelectedFont = [UIFont systemFontOfSize:14];
    configure.titleColor = [UIColor appLightTextColor];
    configure.titleSelectedColor = [UIColor appTextColor];
    configure.indicatorStyle = SGIndicatorStyleFixed;
    configure.indicatorFixedWidth = 30;
    configure.bottomSeparatorColor = [UIColor clearColor];
    
    SGPageTitleView *pageTitleView = [SGPageTitleView pageTitleViewWithFrame:CGRectMake(0, 0, self.view.width, 44) delegate:self titleNames:@[@"全部", @"进行中", @"已过期"] configure:configure];
    [self.view addSubview:pageTitleView];
   
    pageTitleView.indicatorView.image = [UIImage imageNamed:@"dis_1"];
}

- (void)buildTableView {
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 44, SCREEN_WIDTH, self.view.height-44) style:UITableViewStylePlain];
    self.tableView.contentInset = UIEdgeInsetsMake(10, 0, 0, 0);
    self.tableView.backgroundColor = [UIColor appBackGroundColor];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.showsHorizontalScrollIndicator = NO;
    [self.view addSubview:self.tableView];
    
    Weak(self);
    self.tableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        wArg.pageindex++;
        [wArg loadData];
        [wArg.tableView.mj_footer endRefreshing];
    }];
}

#pragma mark - Delegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.modelArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *model = self.modelArr[indexPath.row];
    StudyPlainIndexCell *cell = [StudyPlainIndexCell cellWithTableView:tableView];
    cell.model = model;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 45;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *model = self.modelArr[indexPath.row];
    StudyPlainDetailViewController *vc = [[StudyPlainDetailViewController alloc] init];
    vc.productId = [NSString stringWithObject:model[@"planId"]];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)pageTitleView:(SGPageTitleView *)pageTitleView selectedIndex:(NSInteger)selectedIndex {
    self.type = selectedIndex;
    [self initData];
}


@end

