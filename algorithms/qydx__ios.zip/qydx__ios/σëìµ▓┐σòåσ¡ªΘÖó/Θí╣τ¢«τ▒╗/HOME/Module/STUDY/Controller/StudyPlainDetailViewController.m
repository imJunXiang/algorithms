//
//  DiscoverIndexViewController.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/6/29.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "StudyPlainDetailViewController.h"
#import "SGPagingView.h"
#import "CourseIndexCell.h"
#import "CourseDetailViewController.h"

@interface StudyPlainDetailViewController ()<UITableViewDelegate, UITableViewDataSource, SGPageTitleViewDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSArray *modelArr;

@end

@implementation StudyPlainDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self buildNavItem];
    [self buildHeaderView];
    [self buildTableView];
    [self buildEmptyView:60 title:nil];
    [self loadData];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    self.tableView.height = self.view.height;
}

#pragma mark - DATA
- (void)loadData {
    [HWHttpTool getWeb:[NSString stringWithFormat:@"%@/%@", [ApiConst studyPlanDetail], self.productId] params:nil success:^(id json) {
        NSArray *data = json[@"result"];
        self.modelArr = data;
        [self.tableView reloadData];
        [self emptyReload:self.modelArr];
    }];
}

#pragma mark - ACTION
- (void)rightItemClick {
    
}
#pragma mark - UI
- (void)buildNavItem {
    self.navigationItem.title = @"计划详情";
}

- (void)buildHeaderView {
    
}

- (void)buildTableView {
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, self.view.height) style:UITableViewStylePlain];
    self.tableView.backgroundColor = [UIColor appBackGroundColor];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.showsHorizontalScrollIndicator = NO;
    [self.view addSubview:self.tableView];
    
    UIView *headerV = [[UIView alloc] init];
    headerV.backgroundColor = [UIColor whiteColor];
    UIView *sepV = [UIView createSeparateLine];
    sepV.backgroundColor = [UIColor appBackGroundColor];
    [headerV addSubview:sepV];
    
    UILabel *titleLb = [[UILabel alloc] init];
    titleLb.textColor = [UIColor appTextColor];
    titleLb.font = [UIFont systemFontOfSize:15 weight:400];
    titleLb.textAlignment = NSTextAlignmentLeft;
    [headerV addSubview:titleLb];
    titleLb.text = @"每天上线学习二十分钟";
    
    [headerV addSeparateLineMargin];
    
    sepV.sd_layout
    .topSpaceToView(headerV, 0)
    .leftSpaceToView(headerV, 0)
    .rightSpaceToView(headerV, 0)
    .heightIs(10);
    
    titleLb.sd_layout
    .topSpaceToView(sepV, 15)
    .leftSpaceToView(headerV, 15)
    .rightSpaceToView(headerV, 15)
    .heightIs(20);
    
    headerV.height = 60;
    self.tableView.tableHeaderView = headerV;
}

#pragma mark - Delegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.modelArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *model = self.modelArr[indexPath.row];
    CourseIndexCell *cell = [CourseIndexCell cellWithTableView:tableView];
    cell.model = model;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *model = self.modelArr[indexPath.row];
    CourseDetailViewController *vc = [[CourseDetailViewController alloc] init];
    vc.courseId = [NSString stringWithObject:model[@"courseId"]];
    [self.navigationController pushViewController:vc animated:YES];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 130;
}

- (void)pageTitleView:(SGPageTitleView *)pageTitleView selectedIndex:(NSInteger)selectedIndex {
    
}


@end

