//
//  StudyPlainIndexCell.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/2.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "StudyPlainIndexCell.h"

@implementation StudyPlainIndexCell

- (void)setModel:(NSDictionary *)model {
    _model = model;
    self.nameLb.text = model[@"planTitle"];
    self.timeLb.text = [self getTime];
    if ([self.timeLb.text isEqualToString:@"已过期"]) {
        self.handleBtn.image = [UIImage imageNamed:@"已过期"];
    } else {
        self.handleBtn.image = [UIImage imageNamed:@"进行中拷贝"];
    }
    
    if (model[@"sumDuration"]!=nil && model[@"sumPlayProgress"]!=nil) {
        float p = [model[@"sumPlayProgress"] floatValue];
        float d = [model[@"sumDuration"] floatValue];
        float result = p/d>1?1:p/d;
        self.perLb.text = [NSString stringWithFormat:@"%.f%%", result*100];
    } else {
        self.perLb.text = @"0%";
    }
}

- (NSString *)getTime {
    long aTime = [self getDurationStartTime:self.model[@"cut_off_time"]];
    if (aTime<=0) {
        return @"已过期";
    } else {
        return [NSString stringWithFormat:@"剩余%ld天%.1ld小时", aTime/3600/24, aTime%(3600*24)/(60*60)];
    }
}

/**持续时间*/
- (long)getDurationStartTime:(NSString *)endTime {
    NSDateFormatter *strDateStr = [[NSDateFormatter alloc]init];
    [strDateStr setDateFormat:@"YYYY-MM-dd HH:mm:ss"];
    NSDate *startdate = [NSDate date];
    NSDate *enddate = [strDateStr dateFromString:endTime];
    //时间转时间戳的方法:
    NSTimeInterval aTime = [enddate timeIntervalSinceDate:startdate];
    return (long)aTime;
}

+ (instancetype)cellWithTableView:(UITableView *)tableView
{
    NSString *cellID = @"StudyPlainIndexCell";
    StudyPlainIndexCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell == nil) {
        cell = [[StudyPlainIndexCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
    }
    
    return cell;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    [self buildView];
    return self;
}

- (void)buildView {
    UIImageView *handleBtn = [[UIImageView alloc] init];
    handleBtn.image = [UIImage imageNamed:@"进行中拷贝"];
    [self addSubview:handleBtn];
    self.handleBtn = handleBtn;
    
    UILabel *nameLb = [[UILabel alloc] init];
    nameLb.textColor = [UIColor appTextColor];
    nameLb.font = [UIFont systemFontOfSize:14];
    nameLb.textAlignment = NSTextAlignmentCenter;
    [self addSubview:nameLb];
    self.nameLb = nameLb;
    
    UILabel *perLb = [[UILabel alloc] init];
    perLb.textColor = [UIColor appGrayTextColor];
    perLb.font = [UIFont systemFontOfSize:14];
    perLb.textAlignment = NSTextAlignmentCenter;
    [self addSubview:perLb];
    self.perLb = perLb;
    
    UILabel *timeLb = [[UILabel alloc] init];
    timeLb.textColor = [UIColor appGrayTextColor];
    timeLb.font = [UIFont systemFontOfSize:14];
    timeLb.textAlignment = NSTextAlignmentCenter;
    [self addSubview:timeLb];
    self.timeLb = timeLb;
    
    [self addSeparateLineMargin];
    
    handleBtn.sd_layout
    .centerYEqualToView(self)
    .leftSpaceToView(self, 15)
    .widthIs(14)
    .heightIs(14);
    
    nameLb.sd_layout
    .centerYEqualToView(self)
    .leftSpaceToView(handleBtn, 10)
    .widthIs(145)
    .heightIs(14);
    
    timeLb.sd_layout
    .centerYEqualToView(self)
    .rightSpaceToView(self, 15)
    .widthIs(115)
    .heightIs(14);
    
    perLb.sd_layout
    .centerYEqualToView(self)
    .leftSpaceToView(nameLb, 10)
    .rightSpaceToView(timeLb, 10)
    .heightIs(14);
}

@end
