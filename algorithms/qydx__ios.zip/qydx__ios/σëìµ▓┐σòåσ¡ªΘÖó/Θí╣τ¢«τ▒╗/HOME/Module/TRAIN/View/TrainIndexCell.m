//
//  TrainIndexCell.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/3.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "TrainIndexCell.h"

@implementation TrainIndexCell

+ (instancetype)cellWithTableView:(UITableView *)tableView
{
    NSString *cellID = @"TrainIndexCell";
    TrainIndexCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell == nil) {
        cell = [[TrainIndexCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
    }
    
    return cell;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    [self buildView];
    return self;
}

- (void)buildView {
    UIImageView *iconImgV = [[UIImageView alloc] init];
    iconImgV.sd_cornerRadius = @(4);
    [self addSubview:iconImgV];
    self.iconImgV = iconImgV;
    
    UILabel *nameLb = [[UILabel alloc] init];
    nameLb.textColor = [UIColor appTextColor];
    nameLb.font = [UIFont systemFontOfSize:15 weight:400];
    nameLb.textAlignment = NSTextAlignmentLeft;
    [self addSubview:nameLb];
    self.nameLb = nameLb;
    
    UILabel *desLb = [[UILabel alloc] init];
    desLb.textColor = [UIColor appGrayTextColor];
    desLb.font = [UIFont systemFontOfSize:13];
    desLb.textAlignment = NSTextAlignmentLeft;
    desLb.numberOfLines = 2;
    [self addSubview:desLb];
    self.desLb = desLb;
    
    UIImageView *countImgV = [[UIImageView alloc] init];
    countImgV.image = [UIImage imageNamed:@"发现未选中"];
    [self addSubview:countImgV];
    
    UILabel *countLb = [[UILabel alloc] init];
    countLb.textColor = [UIColor appLightTextColor];
    countLb.font = [UIFont systemFontOfSize:12];
    countLb.textAlignment = NSTextAlignmentLeft;
    [self addSubview:countLb];
    self.countLb = countLb;
    
    [self addSeparateLineMargin];
    
    iconImgV.sd_layout
    .centerYEqualToView(self)
    .leftSpaceToView(self, 15)
    .widthIs(85)
    .heightIs(85);
    
    nameLb.sd_layout
    .topEqualToView(iconImgV)
    .leftSpaceToView(iconImgV, 15)
    .rightSpaceToView(self, 15)
    .heightIs(16);
    
    desLb.sd_layout
    .topSpaceToView(nameLb, 14)
    .leftSpaceToView(iconImgV, 15)
    .rightSpaceToView(self, 15)
    .heightIs(34);
    
    countImgV.sd_layout
    .topSpaceToView(desLb, 12)
    .leftSpaceToView(iconImgV, 15)
    .widthIs(15)
    .heightIs(9);
    
    countLb.sd_layout
    .centerYEqualToView(countImgV)
    .leftSpaceToView(countImgV, 2)
    .rightSpaceToView(self, 15)
    .heightIs(12);

}

@end
