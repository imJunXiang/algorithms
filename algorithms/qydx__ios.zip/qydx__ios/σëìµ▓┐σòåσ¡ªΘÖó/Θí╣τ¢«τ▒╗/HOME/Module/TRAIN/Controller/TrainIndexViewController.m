//
//  TrainIndexViewController.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/7/3.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "TrainIndexViewController.h"
#import "TrainIndexCell.h"
#import "CourseDetailViewController.h"

@interface TrainIndexViewController ()<UITableViewDelegate, UITableViewDataSource>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, assign) NSInteger pageindex;
@property (nonatomic, strong) NSMutableArray *modelArr;
@end

@implementation TrainIndexViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self buildTableView];
    [self buildEmptyView:0 title:nil];
    [self initData];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    self.tableView.height = self.view.height;
}

#pragma mark - DATA
- (void)initData {
    self.pageindex = 1;
    self.modelArr = [NSMutableArray array];
    [self.tableView.mj_footer resetNoMoreData];
    [self loadData];
}

- (void)loadData {
    NSDictionary *params = @{@"page": @(self.pageindex),@"pageSize":PAGE_COUNT};
    [HWHttpTool getWeb:[ApiConst courseQiyeneixunList] params:params success:^(id json) {
        NSDictionary *data = json[@"result"];
        NSArray *modelArr = data[@"records"];
        if (modelArr.count==0) {
            [self.tableView.mj_footer endRefreshingWithNoMoreData];
        } else {
            [self.modelArr addObjectsFromArray:modelArr];
            [self.tableView reloadData];
        }
        [self emptyReload:self.modelArr];
    }];
}

#pragma mark - ACTION
#pragma mark - UI
- (void)buildTableView {
    self.navigationItem.title = @"企业内训";
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGTH) style:UITableViewStylePlain];
    self.tableView.backgroundColor = [UIColor appBackGroundColor];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.showsHorizontalScrollIndicator = NO;
    [self.view addSubview:self.tableView];
    
    UIView *headerV = [UIView new];
    headerV.backgroundColor = [UIColor appBackGroundColor];
    headerV.height = 10;
    self.tableView.tableHeaderView = headerV;
    
    Weak(self);
    self.tableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        wArg.pageindex++;
        [wArg loadData];
        [wArg.tableView.mj_footer endRefreshing];
    }];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.modelArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *model = self.modelArr[indexPath.row];
    TrainIndexCell *cell = [TrainIndexCell cellWithTableView:tableView];
    [cell.iconImgV sd_setImageWithURL:[model[@"cover_image_url"] getURL]];
    cell.nameLb.text = model[@"title"];
    cell.desLb.text = model[@"simple_description"];
    cell.countLb.text = [NSString stringWithFormat:@"%ld人", [model[@"add_view_count"] integerValue]+[model[@"page_view_count"] integerValue]];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 116;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *model = self.modelArr[indexPath.row];
    CourseDetailViewController *vc = [[CourseDetailViewController alloc] init];
    vc.courseId = model[@"id"];
    [self.navigationController pushViewController:vc animated:YES];
}


@end
