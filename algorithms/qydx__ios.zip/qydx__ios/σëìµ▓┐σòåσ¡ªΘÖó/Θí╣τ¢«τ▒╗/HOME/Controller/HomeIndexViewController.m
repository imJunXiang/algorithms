//
//  HomeIndexViewController.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/6/29.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "HomeIndexViewController.h"
#import "HomeIndexHeaderView.h"
#import "HomeIndexStudyCenterCell.h"
#import "HomeIndexModuleHeaderView.h"
#import "StudyPlainIndexViewController.h"
#import "TrainIndexViewController.h"
#import "NoticeIndexViewController.h"
#import "CourseIndexViewController.h"
#import "NoticeDetailViewController.h"

@interface HomeIndexViewController ()<UIScrollViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UICollectionViewDelegate>
@property (strong, nonatomic) UICollectionView *collectionView;
@end

@implementation HomeIndexViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self buildNavItem];
    [self buildCollectionView];
    [self loadData];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    self.collectionView.height = self.view.height;
}

#pragma mark - DATA
- (void)loadData {
    Weak(self);
    NSDictionary *params = @{};
    [HWHttpTool postWeb:[ApiConst advertisingAppList] params:params success:^(id json) {
        NSDictionary *data = json[@"result"];
        [[EGOCache globalCache] setObject:data forKey:@"home_banner"];
        [wArg.collectionView reloadData];
    }];
    
    [HWHttpTool getWeb:[ApiConst companysaasDetail] params:nil success:^(id json) {
        NSDictionary *data = json[@"result"];
        if (data==nil || [data isEqual:@""]) {
            return;
        }
        wArg.navigationItem.title = data[@"simpleName"];
        
        UIButton *leftCustomButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 36, 36)];
        [leftCustomButton sd_setBackgroundImageWithURL:[data[@"logoUrl"] getURL] forState:UIControlStateNormal];
        UIView *leftCustomView = [[UIView alloc] initWithFrame: leftCustomButton.frame];
        leftCustomView.layer.cornerRadius = 18;
        leftCustomView.layer.masksToBounds = YES;
        [leftCustomView addSubview: leftCustomButton];
        UIBarButtonItem * leftButtonItem =[[UIBarButtonItem alloc] initWithCustomView: leftCustomView];
        wArg.navigationItem.leftBarButtonItem = leftButtonItem;
     }];
    
    params = @{@"pageSize": @(2), @"page": @(1)};
    [HWHttpTool getWeb:[ApiConst noticeAppList] params:params success:^(id json) {
        NSDictionary *data = json[@"result"];
        [[EGOCache globalCache] setObject:data[@"records"] forKey:@"home_notice"];
        [wArg.collectionView reloadData];
    }];
}

#pragma mark - ACTION
- (void)leftItemClick {
    
}
- (void)rightItemClick {
    
}
- (void)noticeMoreClick {
    NoticeIndexViewController *vc = [[NoticeIndexViewController alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)noticeDetailClick:(UIButton *)button {
    NSArray *notices = (NSArray *)[[EGOCache globalCache] objectForKey:@"home_notice"];
    NoticeDetailViewController *vc = [[NoticeDetailViewController alloc] init];
    vc.noticeId = notices[button.tag][@"id"];
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - UI
- (void)buildNavItem {
    self.navigationItem.title = @"企业大学";
    self.navigationItem.rightBarButtonItem = [UIBarButtonItem itemWithTarget:self action:@selector(rightItemClick) image:@"下载" highImage:@"下载"];
}
- (void)buildCollectionView
{
    UICollectionViewFlowLayout *flowLayout=[[UICollectionViewFlowLayout alloc] init];
    self.collectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 0, self.view.width, self.view.height) collectionViewLayout:flowLayout];
    
    [self.collectionView registerClass:[HomeIndexStudyCenterCell class] forCellWithReuseIdentifier:@"HomeIndexStudyCenterCell"];
    [self.collectionView registerClass:[HomeIndexHeaderView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"HomeIndexHeaderView"];
    [self.collectionView registerClass:[HomeIndexModuleHeaderView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"HomeIndexModuleHeaderView"];
    
    self.collectionView.dataSource = self;
    self.collectionView.delegate = self;
    self.collectionView.backgroundColor = [UIColor whiteColor];
    self.collectionView.showsVerticalScrollIndicator = NO;
    [self.view addSubview:self.collectionView];
    
    //1.下拉刷新(进入刷新状态就会调用self的headerRereshing)
    __weak typeof (self) weakSelf = self;
    MJChiBaoZiHeader *header = [MJChiBaoZiHeader headerWithRefreshingBlock:^{
        [weakSelf loadData];
        [weakSelf.collectionView.mj_header endRefreshing];
    }];
    // 设置header
    self.collectionView.mj_header = header;
}

#pragma mark - Delegate
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 2;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if (section==0) {
        return 0;
    }
    return 6;
}

//每个UICollectionView展示的内容
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    HomeIndexStudyCenterCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"HomeIndexStudyCenterCell" forIndexPath:indexPath];
    cell.imgV.image = [UIImage imageNamed:[NSString stringWithFormat:@"home_%ld", indexPath.row+1]];
    return cell;
}

//头部显示的内容
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section==0) {
        NSArray *notices = (NSArray *)[[EGOCache globalCache] objectForKey:@"home_notice"];
        HomeIndexHeaderView *headerV = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"HomeIndexHeaderView" forIndexPath:indexPath];
        headerV.bannerV.modelArr = (NSArray *)[[EGOCache globalCache] objectForKey:@"home_banner"];
        headerV.noticeV.modelArr = notices;
        [headerV.noticeV.moreBtn addTarget:self action:@selector(noticeMoreClick) forControlEvents:UIControlEventTouchUpInside];
        for (int i=0; i<notices.count; i++) {
            UIButton *noticeV = headerV.noticeV.noticeBackV.subviews[i];
            noticeV.tag = i;
            [noticeV addTarget:self action:@selector(noticeDetailClick:) forControlEvents:UIControlEventTouchUpInside];
        }
        return headerV;
    }
    
    HomeIndexModuleHeaderView *headerV = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"HomeIndexModuleHeaderView" forIndexPath:indexPath];
    headerV.nameLb.text = @"学习中心";
    return headerV;
}
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        NSArray *notices = (NSArray *)[[EGOCache globalCache] objectForKey:@"home_notice"];
        return CGSizeMake(SCREEN_WIDTH, 180+10+50+30*notices.count);
    }
    return CGSizeMake(SCREEN_WIDTH, 60);
}

//定义每个UICollectionView 的大小
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    CGFloat width = (SCREEN_WIDTH-45)/2;
    return CGSizeMake(width, width/16*9);
}
//定义每个UICollectionView 的组间距
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    if (section==0) {
        return UIEdgeInsetsMake(0, 0, 0, 0);
    }
    return UIEdgeInsetsMake(0, 15, 15, 15);
}
//定义每个UICollectionView 横向的间距
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section {
    return 15;
}
//定义每个UICollectionView 纵向的间距
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section {
    return 15;
}
#pragma mark --UICollectionViewDelegate
//UICollectionView被选中时调用的方法
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section==1) {
        if (indexPath.row==0) {
            CourseIndexViewController *vc = [[CourseIndexViewController alloc] init];
            vc.navigationItem.title = @"我的课程";
            [self.navigationController pushViewController:vc animated:YES];
        }
        if (indexPath.row==1) {
            TrainIndexViewController *vc = [[TrainIndexViewController alloc] init];
            [self.navigationController pushViewController:vc animated:YES];
        }
        if (indexPath.row==2) {
            StudyPlainIndexViewController *vc = [[StudyPlainIndexViewController alloc] init];
            [self.navigationController pushViewController:vc animated:YES];
        }
    }
}


@end
