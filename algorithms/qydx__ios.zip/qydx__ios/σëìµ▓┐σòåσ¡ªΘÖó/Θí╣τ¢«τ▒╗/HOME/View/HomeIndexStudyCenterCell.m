//
//  HomeIndexStudyCenterCell.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/6/29.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "HomeIndexStudyCenterCell.h"

@implementation HomeIndexStudyCenterCell

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        UIImageView *imgV = [[UIImageView alloc] init];
        [self addSubview:imgV];
        self.imgV = imgV;
        
        imgV.sd_layout
        .topSpaceToView(self, 0)
        .leftSpaceToView(self, 0)
        .rightSpaceToView(self, 0)
        .bottomSpaceToView(self, 0);
    }
    return self;
}

@end
