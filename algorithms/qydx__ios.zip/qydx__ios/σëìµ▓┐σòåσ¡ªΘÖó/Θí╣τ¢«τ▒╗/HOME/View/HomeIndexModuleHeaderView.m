//
//  HomeIndexModuleHeaderView.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/6/29.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "HomeIndexModuleHeaderView.h"

@implementation HomeIndexModuleHeaderView
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self buildUI];
    }
    return self;
}

- (void)buildUI {
    UIView *headerV = [[UIView alloc] init];
    headerV.backgroundColor = [UIColor whiteColor];
    [self addSubview:headerV];
    
    UILabel *nameLb = [[UILabel alloc] init];
    nameLb.textColor = [UIColor appBlackColor];
    nameLb.font = [UIFont systemFontOfSize:16 weight:400];
    nameLb.textAlignment = NSTextAlignmentLeft;
    [headerV addSubview:nameLb];
    self.nameLb = nameLb;
    
    [headerV addSeparateLine];
    
    headerV.sd_layout
    .topSpaceToView(self, 0)
    .leftSpaceToView(self, 15)
    .rightSpaceToView(self, 15)
    .heightIs(44);
    
    nameLb.sd_layout
    .centerYEqualToView(headerV)
    .leftSpaceToView(headerV, 0)
    .rightSpaceToView(headerV, 0)
    .heightIs(44);
}
@end
