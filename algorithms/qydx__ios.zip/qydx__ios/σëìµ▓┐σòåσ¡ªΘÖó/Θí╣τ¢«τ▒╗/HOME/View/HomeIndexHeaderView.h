//
//  HomeIndexHeaderView.h
//  前沿商学院
//
//  Created by MisterDeng on 2018/6/29.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HomeIndexBannerView.h"
#import "HomeIndexNoticeView.h"

@interface HomeIndexHeaderView : UICollectionReusableView
@property (nonatomic, strong) HomeIndexBannerView *bannerV;
@property (nonatomic, strong) HomeIndexNoticeView *noticeV;
@end
