//
//  HomeIndexHeaderView.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/6/29.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "HomeIndexHeaderView.h"

@implementation HomeIndexHeaderView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self buildUI];
    }
    return self;
}

- (void)buildUI {
    HomeIndexBannerView *bannerV = [[HomeIndexBannerView alloc] initWithFrame:CGRectMake(0, 0, self.width, 180)];
    [self addSubview:bannerV];
    self.bannerV = bannerV;
    
    HomeIndexNoticeView *noticeV = [[HomeIndexNoticeView alloc] initWithFrame:CGRectMake(0, 180, self.width, 115)];
    [self addSubview:noticeV];
    self.noticeV = noticeV;
    
    UIView *sepView = [[UIView alloc] init];
    sepView.backgroundColor = [UIColor appBackGroundColor];
    [self addSubview:sepView];
    
    sepView.sd_layout
    .bottomSpaceToView(self, 0)
    .leftSpaceToView(self, 0)
    .rightSpaceToView(self, 0)
    .heightIs(10);
}

@end
