//
//  HomeCyclePicCell.m
//  案例
//
//  Created by 邓壮壮 on 2016/11/3.
//  Copyright © 2016年 邓壮壮. All rights reserved.
//

#import "HomeIndexBannerView.h"
#import "SDCycleScrollView.h"

@interface HomeIndexBannerView()<SDCycleScrollViewDelegate>
@property (nonatomic, strong) SDCycleScrollView *cycleScrollView;
@end

@implementation HomeIndexBannerView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor appBackGroundColor];
        self.cycleScrollView = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, 0, self.width, self.height) delegate:self placeholderImage:[UIImage imageNamed:@"占位图"]];
        self.cycleScrollView.backgroundColor = [UIColor whiteColor];
        self.cycleScrollView.pageControlAliment = SDCycleScrollViewPageContolAlimentCenter;
        self.cycleScrollView.autoScrollTimeInterval = 5;
        self.cycleScrollView.pageControlStyle = SDCycleScrollViewPageContolStyleClassic;
        self.cycleScrollView.currentPageDotColor = [UIColor whiteColor]; // 自定义分页控件小圆标颜色
        self.cycleScrollView.pageDotColor = [UIColor colorWithWhite:1 alpha:0.5]; // 自定义分页控件小圆标颜色
        self.cycleScrollView.hidesForSinglePage = YES;
        self.cycleScrollView.layer.masksToBounds = YES;
        [self addSubview:self.cycleScrollView];
    }
    return self;
}

- (void)setModelArr:(NSArray *)modelArr
{
    _modelArr = modelArr;
    NSMutableArray *imgArr = [[NSMutableArray alloc] init];
    for (int i = 0; i < modelArr.count; i++)
    {
        NSURL *url = [NSURL URLWithString:[modelArr[i] objectForKey:@"sourceImageUrl"]];
        [imgArr addObject:url];
    }
    self.cycleScrollView.imageURLStringsGroup = imgArr;
}

- (void)cycleScrollView:(SDCycleScrollView *)cycleScrollView didSelectItemAtIndex:(NSInteger)index
{
    if (self.imgClickBlock!=nil) {
        self.imgClickBlock(self.modelArr[index]);
    }
}

@end
