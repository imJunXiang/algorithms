//
//  HomeIndexNoticeView.m
//  前沿商学院
//
//  Created by MisterDeng on 2018/6/29.
//  Copyright © 2018年 edu268. All rights reserved.
//

#import "HomeIndexNoticeView.h"

@implementation HomeIndexNoticeView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self buildUI];
    }
    return self;
}

- (void)setModelArr:(NSArray *)modelArr {
    _modelArr = modelArr;
    [[self.noticeBackV subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
    for (NSDictionary *model in modelArr) {
        UIButton *noticeCell = [self buildNoticeCell:model[@"title"] dateStr:[NSDate dateWithOriginal:model[@"createtime"] format:@"yyyy/MM/dd"]];
        [self.noticeBackV addSubview:noticeCell];
        
        noticeCell.sd_layout
        .topSpaceToView(self.tempV, 0)
        .leftSpaceToView(self.noticeBackV, 0)
        .rightSpaceToView(self.noticeBackV, 0)
        .heightIs(30);
        self.tempV = noticeCell;
    }
    self.noticeBackV.sd_layout.heightIs(modelArr.count*30);
    self.height = 50+modelArr.count*30;
}

- (void)buildUI {
    UIView *headerV = [[UIView alloc] init];
    headerV.backgroundColor = [UIColor whiteColor];
    [self addSubview:headerV];
    
    UILabel *nameLb = [[UILabel alloc] init];
    nameLb.textColor = [UIColor appBlackColor];
    nameLb.font = [UIFont systemFontOfSize:16 weight:400];
    nameLb.text = @"企业公告";
    nameLb.textAlignment = NSTextAlignmentLeft;
    [headerV addSubview:nameLb];
    
    UIButton *moreBtn = [[UIButton alloc] init];
    [moreBtn setTitleColor:[UIColor appLightTextColor] forState:UIControlStateNormal];
    [moreBtn setTitle:@"查看全部" forState:UIControlStateNormal];
    moreBtn.titleLabel.font = [UIFont systemFontOfSize:10];
    moreBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
    [headerV addSubview:moreBtn];
    self.moreBtn = moreBtn;
    
    UIView *noticeBackV = [[UIView alloc] init];
    [self addSubview:noticeBackV];
    self.noticeBackV = noticeBackV;
    
    self.tempV = noticeBackV;
    
    [headerV addSeparateLine];
    
    headerV.sd_layout
    .topSpaceToView(self, 0)
    .leftSpaceToView(self, 15)
    .rightSpaceToView(self, 15)
    .heightIs(44);
    
    nameLb.sd_layout
    .centerYEqualToView(headerV)
    .leftSpaceToView(headerV, 0)
    .widthIs(120)
    .heightIs(44);
    
    moreBtn.sd_layout
    .centerYEqualToView(headerV)
    .rightSpaceToView(headerV, 0)
    .widthIs(120)
    .heightIs(44);
    
    noticeBackV.sd_layout
    .topSpaceToView(headerV, 5)
    .leftSpaceToView(self, 0)
    .rightSpaceToView(self, 0)
    .heightIs(1);
    
}

- (UIButton *)buildNoticeCell:(NSString *)title dateStr:(NSString *)dateStr {
    UIButton *backV = [[UIButton alloc] init];
    backV.backgroundColor = [UIColor whiteColor];
    
    UIView *iconV = [[UIView alloc] init];
//    iconV.backgroundColor = iconColor;
    iconV.sd_cornerRadius = @(4);
//    [backV addSubview:iconV];
    
    UILabel *nameLb = [[UILabel alloc] init];
    nameLb.textColor = [UIColor appTextColor];
    nameLb.font = [UIFont systemFontOfSize:11];
    nameLb.textAlignment = NSTextAlignmentLeft;
    [backV addSubview:nameLb];
    nameLb.text = title;
    
    UILabel *dateLb = [[UILabel alloc] init];
    dateLb.textColor = [UIColor appLightTextColor];
    dateLb.font = [UIFont systemFontOfSize:11];
    dateLb.textAlignment = NSTextAlignmentRight;
    [backV addSubview:dateLb];
    dateLb.text = dateStr;
    
    iconV.sd_layout
    .centerYEqualToView(backV)
    .leftSpaceToView(backV, 15)
    .widthIs(8)
    .heightIs(8);
    
    dateLb.sd_layout
    .centerYEqualToView(backV)
    .rightSpaceToView(backV, 15)
    .heightIs(20);
    [dateLb setSingleLineAutoResizeWithMaxWidth:200];
    
    nameLb.sd_layout
    .centerYEqualToView(backV)
    .leftSpaceToView(backV, 15)
    .rightSpaceToView(dateLb, 15)
    .heightIs(20);
    
    return backV;
}

@end
